<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class User extends Model
{
     protected $fillable = [
        'name','phone', 'email','image' ,'is_contacted','city_id'
    ];
    public $timestamps = false;

    public function getImageAttribute($value){
        return asset('images/User/'.$value);
    }

     public function setImageAttribute($value)
     {
         if($value && $value!= 'undefined')
         {
             $fileName = 'User_'.rand(11111,99999).'.'.$value->getClientOriginalExtension(); // renameing image
             $destinationPath = public_path('images/User');
             $value->move($destinationPath, $fileName); // uploading file to given path
             $this->attributes['image'] = $fileName;
         }
     }


}
