<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Review extends Authenticatable
{

     protected $fillable = [
        'id' , 'user_id','product_id', 'rating','comment','created_at' 
    ];
 

}
