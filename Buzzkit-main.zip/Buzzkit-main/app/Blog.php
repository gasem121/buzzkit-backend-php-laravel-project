<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Blog extends Model
{
    public $timestamps = false;
    protected $fillable = [
        'name_en','name_ar',
        'added_by',
        'image','details_ar','details_en' ,'status','deleted_at'
    ];

 

    //========================================== Image ================================
    public function getImageAttribute($value){
        return asset('images/Blog/'.$value);
    }

     public function setImageAttribute($value)
     {
         if($value && $value!= 'undefined')
         {
             $fileName = 'Blog_'.rand(11111,99999).'.'.$value->getClientOriginalExtension(); // renameing image
             $destinationPath = public_path('images/Blog');
             $value->move($destinationPath, $fileName); // uploading file to given path
             $this->attributes['image'] = $fileName;
         }
     }





}
