<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Order extends Authenticatable
{

     protected $fillable = [
        'id' , 'user_id','promo_code', 'status','delivery_id','total_price'  , 'location_id' , 'package_id' , 'rating' , 'comment' ,'payment_type','order_paid', 'cancel_reason','branch_id','discount','delivery_cost','tags','shipment_log'
    ];
 

}
