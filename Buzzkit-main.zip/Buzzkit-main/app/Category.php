<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
     protected $fillable = [ 
       'name_en', 'name_ar','image' ,'status' ,'category_id', 'added_by' , 'deleted_at' , 'created_at' , 'updated_at'  
    ];
    public $timestamps = false;

    public function getImageAttribute($value){
        return asset('images/Category/'.$value);
    }

     public function setImageAttribute($value)
     {
         if($value && $value!= 'undefined')
         {
             $fileName = 'Category_'.rand(11111,99999).'.'.$value->getClientOriginalExtension(); // renameing image
             $destinationPath = public_path('images/Category');
             $value->move($destinationPath, $fileName); // uploading file to given path
             $this->attributes['image'] = $fileName;
         }
     }


}
