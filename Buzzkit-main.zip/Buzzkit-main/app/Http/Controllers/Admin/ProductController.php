<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Product;
use App\Category;
use App\Variation;
use App\ProductAttribute;
use App\ProductOffer;
use App\ProductImage;
use App\Attribute;
use App\Cart;
use App\Material;
use App\ProductMaterial;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class ProductController  extends BaseController
{

      public function products(Request $request){


        $products = Product::where('deleted_at',null)->where('is_offer',0)->get();
        
        

        foreach ($products as $product) {
          $variation_text = "";  
              //$product->variations = "";

         $product->category = Category::where('id',$product->category_id)->first()->name_en;
         
         
           $product_attributes = ProductAttribute::where('product_id', $product->id)->get();
             $result = array();

              $count_now = 0;
              foreach ($product_attributes as $product_attribute) {

                  $attribute = Attribute::where('id',$product_attribute->attribute_id)->first();
                   $attribute->variation_name  = Variation::where('id',$attribute->variation_id)->first()->name_en;

                      $variation_text.=  $attribute->variation_name ." : ".$attribute->name_en." ( ".$product_attribute->store_quantity." ) <br />";
                      
                      $count_now+=$product_attribute->store_quantity;
            
                  if(!array_key_exists("a_".$attribute->variation_id,$result)){
                  
                  $result['a_'.$attribute->variation_id] = array();
                  array_push($result['a_'.$attribute->variation_id], $attribute);
                  }else {
                    array_push($result['a_'.$attribute->variation_id], $attribute);
                  }
 
              }
                
              //$product->variation_count= count($product->variations);
              $product->variations = $variation_text;
              $product->at_stock = $count_now;


        }


        return view('Admin.Products.products',compact('products'));
      }
      
      
      
       public function products_choices(Request $request){


        $choices = ProductOffer::where('deleted_at',null)->where('offer_id',$request->offer_id)->get();
    
        foreach($choices as $choice){
            
            $choice->item_count = count(explode("," , $choice));
        
        }
        
        $offer_id = $request->offer_id;
     

        return view('Admin.Products.offer-choices',compact('choices','offer_id'));
      }
      
      
      public function products_choices_items(Request $request){


        $choice = ProductOffer::where('deleted_at',null)->where('id',$request->choice_id)->first();
    
    
        $products =  explode(",",$choice->offer_items);
        $products_fees =  explode(",",$choice->offer_items);
        
        
        $choice->products = Product::select('id','name_ar','name_en')->get();
        
        for($i=0; $i<count($products); $i++){
        
        
            foreach($choice->products as $product){
                    
                    if($products[$i] == $product->id){
                        
                        $product->checked = true;
                        $product->extra_fees = $products_fees[$i];
                        
                        break;
                        
                    }
                    
              }
        
        }
        
            
    

        return view('Admin.Products.offer-choices-items',compact('choice'));
      }


    
     public function offers(Request $request){


        $products = Product::where('deleted_at',null)->where('is_offer',1)->get();

        foreach ($products as $product) {
          $variation_text = "";  

           $product_attributes = ProductAttribute::where('product_id', $product->id)->get();
             $result = array();

              
              foreach ($product_attributes as $product_attribute) {

                  $attribute = Attribute::where('id',$product_attribute->attribute_id)->first();
                   $attribute->variation_name  = Variation::where('id',$attribute->variation_id)->first()->name_en;

                      $variation_text.=  $attribute->variation_name ." : ".$attribute->name_en."<br />";
            
                  if(!array_key_exists("a_".$attribute->variation_id,$result)){
                  
                  $result['a_'.$attribute->variation_id] = array();
                  array_push($result['a_'.$attribute->variation_id], $attribute);
                  }else {
                    array_push($result['a_'.$attribute->variation_id], $attribute);
                  }
 
              }
                
              //$product->variation_count= count($product->variations);
              $product->variations = $variation_text;
              


        }


        return view('Admin.Products.offers',compact('products'));
      }

 
        
  public function edit_choice(Request $request){
        
          $choice = ProductOffer::where('deleted_at',null)->where('id',$request->choice_id)->first();
    
        if($request->isMethod('get')){
        $products =  explode(",",$choice->offer_items);
        $products_fees =  explode(",",$choice->extra_price);
        $choice->products = Product::select('id','name_ar','name_en')->get();
        
        for($i=0; $i<count($products); $i++){
            foreach($choice->products as $product){
                    if($products[$i] == $product->id){
                        $product->checked = true;
                        $product->extra_fees = $products_fees[$i];
                        break;
                    }
              }
        }
    
             
            $offer_id=$request->offer_id;
         return view('Admin.Products.edit-choice',compact('offer_id','choice'));
       }
            
            
          $items="";
          $items_fees="";
          
          
          for($i=0; $i<count($request->ids); $i++){
              
              if($i>0){
                  $items.=",";
                  $items_fees.=",";
              }
              
              $items.=$request->ids[$i];
              
              if(!$request['fees_'.$request->ids[$i]]){
                  $request['fees_'.$request->ids[$i]] = 0;
              }
              
              $items_fees.= $request['fees_'.$request->ids[$i]];
              
          }
          
          
          $choice->offer_items = $items;
          $choice->name_ar = $request->name_ar;
          $choice->name_en = $request->name_en;
          $choice->extra_price = $items_fees;
          $choice->quantity_in_section = $request->quantity_in_section;
          $choice->status = $request->status;
          $choice->save();
      

        return Redirect::to('/products/offers/choices/'.$request->offer_id);  
      }
      
      
       public function add_choice(Request $request){
           
        if($request->isMethod('get')){
            
        $products = Product::select('id','name_ar','name_en')->get();
             
            $offer_id=$request->offer_id;
         return view('Admin.Products.add-choice',compact('offer_id','products'));
       }
            
            
          $items="";
          $items_fees="";
          
          
          for($i=0; $i<count($request->ids); $i++){
              
              if($i>0){
                  $items.=",";
                  $items_fees.=",";
              }
              
              $items.=$request->ids[$i];
              
              if(!$request['fees_'.$request->ids[$i]]){
                  $request['fees_'.$request->ids[$i]] = 0;
              }
              
              $items_fees.= $request['fees_'.$request->ids[$i]];
              
          }
          
          
          $Product = ProductOffer::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'offer_items'=>$items
                ,'extra_price'=>$items_fees
                ,
                'offer_id' => $request->offer_id ,
                'quantity_in_section' => $request->quantity_in_section ,
                'status' => $request->status ,
                 
            ]);
            
 
        
        return Redirect::to('/Admin/products/offers/choices/'.$request->offer_id); 
      }
      

      public function add(Request $request){

              $products = Product::get();

        if($request->isMethod('get')){
            
        if($request->is_offer){
        return view('Admin.Products.add-offer');
        }
         $categories = Category::where('deleted_at',null)->get();
         return view('Admin.Products.add-product',compact('categories','products'));
       }
          

            if(!$request->at_stock)$request->at_stock=1;
            if(!$request->category_id)$request->category_id=0;
            if(!$request->is_offer)$request->is_offer=0;
      
            
            $related_items="";
            
            if($request->ids){
            for($i=0; $i<count($request->ids); $i++){
                
                    if($i>0){
                        
                        $related_items .=",";
                    }
                
                    $related_items.=$request->ids[$i];
            }
            }
      
                //dd($related_items);
            
            
          $Product = Product::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                'image' => $request->image ,
                'cost_price'=>$request->cost_price,
                'details_ar' => $request->details_ar ,
                'details_en' => $request->details_en ,
                'at_stock' => $request->at_stock ,
                'price_before' => $request->price_before ,
                'price_after' => $request->price_after ,
                'category_id' => $request->category_id ,
                'related_products' => $related_items,
                'added_by' => 1 ,
                'is_offer'=>$request->is_offer
            ]);
            
    
        
            

        if($request->is_offer){
        return Redirect::to('/Admin/products'); 
        }
        
        return Redirect::to('/Admin/products'); 
      }
      
      
      
      
    public function add_image(Request $request){
        $id = $request->id;

        if($request->isMethod('get')){
         return view('Admin.Products.add-image',compact('id'));
          }
          
         
          
          if($files=$request->file('image')){
        foreach($files as $image){
                
                $Product = ProductImage::create([
                'product_id' => $request->id ,
                'position' => 0 ,
                'image' => $image ,
            ]);
            
        }
    }
    
 
          
            
     
        
        return Redirect::to('/Admin/products/edit/'.$id); 
      }
      
      
       public function delete_image(Request $request){
           
          $product_image = ProductImage::where('id',$request->image_id)->delete();
        
            $id = $request->id;
        
              return Redirect::to('/Admin/products/edit/'.$id); 
      }
      
      



      public function edit(Request $request)
      {  
          
          //$handle = fopen("http://kogear.shop/public/storedata.csv", "r");
          
    //       $handle = file('http://kogear.shop/public/storedata.csv');
          
    //         $data = [];
    //         $i=0;
   
    // foreach ($handle as $line) {
        
    //     $data  = str_getcsv($line);
        
    //     if($i>0){
            
    //         $go_in =  ProductAttribute::where('store_codes', $data[0])->first();
            
    //         if($go_in){
    //         $go_in->store_quantity = $data[1];
            
    //         $go_in->save();
    //         }
    //     }
        
    //     $i++;
    //     }
    // dd("Done");
       
        $product = Product::where('id',$request->id)->first();
        $variations = Variation::where('deleted_at',null)->get();
        $materials = Material::where('deleted_at',null)->get();
        
        
        $images = ProductImage::where('product_id',$product->id)->get();
    
    
    
         if($request->isMethod('get')){
                
          $products = Product::where('id','!=',$product->id)->select('id','name_en','name_ar')->get();
          
          
          $products_temp = Product::whereIn('id',explode(',',$product->related_products))->select('id')->get();
        
        for($i=0; $i<count($products); $i++){
            foreach($products_temp as $product_tmp){
                    if($products[$i]->id == $product_tmp->id){
                        $products[$i]->checked = true;
                        break;
                    }
              }
        }
        
        
             $product_categories_temp = explode(',',$product->product_categories);
             
              $categories = Category::where('deleted_at',null)->get();
              
              
              
              for($i=0; $i<count($categories); $i++){
            foreach($product_categories_temp as $product_category_temp){
                    if($categories[$i]->id == $product_category_temp){
                        $categories[$i]->checked = true;
                              break;
                                  }
                          }
                }
        
              
              
              foreach ($variations as $variation) {
                  $variation->attributies = Attribute::where('variation_id',$variation->id)->get();

                      foreach ($variation->attributies as $attribute) {
                    
                   $product_attribute = ProductAttribute::where('product_id', $request->id)->where('attribute_id', $attribute->id)->first();

                        if($product_attribute){
                            $attribute->store_codes = $product_attribute->store_codes;
                            $attribute->store_quantity  = $product_attribute->store_quantity;
                            $attribute->price = $product_attribute->price;
                            $variation->is_selected = true;
                        }



                       }

              }
              
              
           return view('Admin.Products.edit-product',compact('product','categories','variations','products','images'));
         }
     $related_items="";
    if($request->ids){
    
            for($i=0; $i<count($request->ids); $i++){
                
                    if($i>0){
                        
                        $related_items .=",";
                    }
                
                    $related_items.=$request->ids[$i];
            }
            
    }
    
    
             $product_categories = "";
     
        if($request->product_categories){
    
              for($i=0; $i<count($request->product_categories); $i++){
                
                      if($i>0){
                        
                        $product_categories .=",";
                     }
                
                $product_categories.=$request->product_categories[$i];
             }
            
         }
    
            
          

          $product->name_ar = $request->name_ar;
          $product->name_en = $request->name_en;
          $product->status = $request->status;
          $product->details_ar = $request->details_ar;
          $product->details_en = $request->details_en;
          $product->at_stock = $request->at_stock;
          $product->price_before = $request->price_before;
          $product->price_after = $request->price_after;
          
          $product->cost_price = $request->cost_price;
          
          
          $product->category_id = $request->category_id;
          
          $product->product_categories = $product_categories;
          
          $product->related_products =  $related_items;


          if($request->image){
          $product->image =  $request->image ;
          }

          ProductAttribute::where('product_id', $request->id)->delete();
        
            foreach($images as $image){
                $single_image = ProductImage::where('id',$image->id)->first();
                $single_image->position = $request['image_'.$image->id];
                $single_image->save();
            }


          foreach ($variations as $variation) {
                  $variation->attributies = Attribute::where('variation_id',$variation->id)->get();

                  foreach ($variation->attributies as $attribute) {

                      if($request['attribute_'.$attribute->id]!=null){
                           

                           ProductAttribute::create([
                            'product_id' => $request->id ,
                            'attribute_id' => $attribute->id ,
                            'price' => $request['attribute_'.$attribute->id] ,
                             'store_codes' => $request['attribute_store_codes_'.$attribute->id] ,
                             'store_quantity' => $request['attribute_store_quantity_'.$attribute->id]
  
                               ]);

                        }

                     }

              }

          $product->save();



           return  Redirect::to('/Admin/products');


      }
      
      
   public function edit_offer(Request $request){ 
       
       
        $product = Product::where('id',$request->id)->first();
        

         if($request->isMethod('get')){
             
              $categories = Category::where('deleted_at',null)->get();
           return view('Admin.Products.edit-offer',compact('product','categories'));
         }


          $product->name_ar = $request->name_ar;
          $product->name_en = $request->name_en;
          $product->status = $request->status;
          $product->details_ar = $request->details_ar;
          $product->details_en = $request->details_en;
          $product->at_stock = $request->at_stock;
          $product->price_before = $request->price_before;
          $product->price_after = $request->price_after;
          $product->category_id = $request->category_id;


          if($request->image){
          $product->image =  $request->image ;
          }

         
          $product->save();



           return  Redirect::to('/Admin/products/offers');


      }


       public function delete(Request $request)
      {
             $product = Product::where('id',$request->product_id)->first();
             $product->deleted_at =  Carbon::now();
             $product->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'product deleted successfully'
          ]);
      }
      
      
       public function delete_choice(Request $request) {
           
 
           
             $product = ProductOffer::where('id',$request->choice_id)->first();
             $product->deleted_at =  Carbon::now();
             $product->save();
             
          return response()->json([
            'status' => 'success',
            'flash_message' => 'product deleted successfully'
          ]);
      }
      
      
      
      
      public function products_analysis(Request $request){


        $products = Product::where('deleted_at',null)->get();

        foreach ($products as $product) {

         
             $result = array();
             
             
              $product->counter = Cart::where('product_id', $product->id)->where('order_id','!=','0')->sum('quantity');
              


        }


        return view('Admin.Products.products_analysis',compact('products'));
      }
      


   


}
