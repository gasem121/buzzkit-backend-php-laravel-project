<?php

namespace App\Http\Controllers\Admin;
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Setting;
use App\Suggestion;
use App\User;
use App\Order;
use App\CategoryofProducts;
use App\BrandofProducts;
use Illuminate\Support\Facades\Session; 
use App\VendorsProductNotificationsFromAdmin;

class SettingsController extends BaseController
{
   
    public function index()
    {
 
          $settings = Setting::select("id",'title','value')->get();
        
          $setting =  array();

          foreach($settings as $item){

              if( $item['title']=="about_title_ar"){
                $setting['about_title_ar']=$item['value'];
              }
        
            if($item['title']=="about_details_ar"){
                $setting['about_details_ar']=$item['value'];
              }



              if( $item['title']=="about_title_en"){
                $setting['about_title_en']=$item['value'];
              }
        
        if( $item['title']=="about_details_en"){
                $setting['about_details_en']=$item['value'];
              }


            if( $item['title']=="terms_title_ar"){
                $setting['terms_title_ar']=$item['value'];
              }
        
        if( $item['title']=="terms_details_ar"){
                $setting['terms_details_ar']=$item['value'];
              }


              if( $item['title']=="terms_title_en"){
                $setting['terms_title_en']=$item['value'];
              }
        
        if( $item['title']=="terms_details_en"){
                $setting['terms_details_en']=$item['value'];
              }



          if( $item['title']=="what_we_do_title_ar"){
                $setting['what_we_do_title_ar']=$item['value'];
              }
        
        if( $item['title']=="what_we_do_title_en"){
                $setting['what_we_do_title_en']=$item['value'];
              }


         if( $item['title']=="what_we_do_details_ar"){
                $setting['what_we_do_details_ar']=$item['value'];
              }
        
        if( $item['title']=="what_we_do_details_en"){
                $setting['what_we_do_details_en']=$item['value'];
              }


          if( $item['title']=="our_vision_details_ar"){
                $setting['our_vision_details_ar']=$item['value'];
              }
        
        if( $item['title']=="our_vision_details_en"){
                $setting['our_vision_details_en']=$item['value'];
              }


         if( $item['title']=="our_vision_title_ar"){
                $setting['our_vision_title_ar']=$item['value'];
              }
        
        if( $item['title']=="our_vision_title_en"){
                $setting['our_vision_title_en']=$item['value'];
              }


          if( $item['title']=="our_mission_details_ar"){
                $setting['our_mission_details_ar']=$item['value'];
              }
        
        if( $item['title']=="our_mission_details_en"){
                $setting['our_mission_details_en']=$item['value'];
              }


         if( $item['title']=="our_mission_title_ar"){
                $setting['our_mission_title_ar']=$item['value'];
              }
        
        if( $item['title']=="our_mission_title_en"){
                $setting['our_mission_title_en']=$item['value'];
              }



         if( $item['title']=="address_ar"){
                $setting['address_ar']=$item['value'];
              }
        
        if( $item['title']=="address_en"){
                $setting['address_en']=$item['value'];
              }


               if( $item['title']=="phone"){
                $setting['phone']=$item['value'];
              }


              if( $item['title']=="email"){
                $setting['email']=$item['value'];
              }


              if( $item['title']=="facebook"){
                $setting['facebook']=$item['value'];
              }


              if( $item['title']=="twitter"){
                $setting['twitter']=$item['value'];
              }


              if( $item['title']=="instagram"){
                $setting['instagram']=$item['value'];
              }


              if( $item['title']=="youtube"){
                $setting['youtube']=$item['value'];
              }


             



          }

         return view('Admin.Settings.settings',compact('setting'));
    }


     public function update_settings(Request $request){


             $settings = Setting::select("id",'title','value')->get();
        
          
          //dd($request);

          foreach($settings as $item){

              $setting = Setting::where('title',$item['title'])->first();

              $setting->value = $request[$item->title];
              
              $setting->save();


          }



     }

 

}
