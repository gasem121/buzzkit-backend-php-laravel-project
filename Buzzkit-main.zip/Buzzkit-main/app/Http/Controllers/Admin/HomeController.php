<?php


namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\City;
use App\Customer;
use App\DriverCar;
use App\Cart;
use App\OrderPayment;
use App\Order;
use App\Product;
use App\Member;
use App\UserPackage;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;


class HomeController extends BaseController {
      
      public function home(Request $request){


     $statistics = array();
     
     $orders_total_price = 1.5;
     
     
        $statistics['number_of_orders'] = Order::whereDate('created_at', Carbon::today())->count();
        
         $statistics['total_packages'] = UserPackage::whereDate('created_at', Carbon::today())->count();
        
        
       $statistics['total_got_money'] = OrderPayment::whereDate('created_at', Carbon::today())->sum('cost');
     
     $statistics['total_orders_money'] = OrderPayment::whereDate('created_at', Carbon::today())->where('package_id',null)->sum('cost');
     
     
      $statistics['total_delivery_money'] = Order::whereDate('created_at', Carbon::today())->sum('delivery_cost');
      
      
      $statistics['total_texes'] = ($statistics['total_got_money'] - $statistics['total_delivery_money']) * 0.14;
     
     $statistics['total_packages_money'] = OrderPayment::whereDate('created_at', Carbon::today())->where('order_id',null)->sum('cost');
     
     
     //فلوس الباكدجات الي المفروض تدفع 
   $statistics['total_packages_cost'] = UserPackage::whereDate('created_at', Carbon::today())->sum('total_price');
   
   //فلوس الباكدجات المتبقيه 
   
    $statistics['total_reminder_packages_cost'] = $statistics['total_packages_cost'] - $statistics['total_packages_money'] ;
     
     
      $statistics['total_visa'] = OrderPayment::whereDate('created_at', Carbon::today())->where('payment_type',0)->sum('cost');
      
      	  $statistics['total_cash'] = OrderPayment::whereDate('created_at', Carbon::today())->where('payment_type',1)->sum('cost');
      	  
      	  $statistics['total_vodafone_cash'] = OrderPayment::whereDate('created_at', Carbon::today())->where('payment_type',2)->sum('cost');
      	  
      	  $statistics['total_fawry'] = OrderPayment::whereDate('created_at', Carbon::today())->where('payment_type',3)->sum('cost');
      	  
     
 
     
     //المنتجات الي اتطلبت و مطلعتش من المطبخ او العميل رجعها
            
                  $total_real_products_cost = 0; 
      
  $today_orders_ids = Order::whereDate('created_at', Carbon::today())->pluck('id')->toArray();

      $vioal_products = Cart::select('product_id','price')->where('deleted_at','!=',null)->whereIn('order_id',$today_orders_ids)->get();
            
             $total_vioal_products_cost = 0;
        
         $statistics['total_vioal_products'] = count($vioal_products);
 
         
        foreach($vioal_products as $vioal_product){
            
            if($vioal_product->price>0){
            $total_vioal_products_cost += ( $vioal_product->price + (0.14*$vioal_product->price) );
            }else {
                $price = Product::select('price_after')->where('id',$vioal_product->product_id)->first()->price_after;
                
                $total_vioal_products_cost += ( $price + (0.14*$price) );
            }
            
        }
         
         
         $statistics['total_vioal_products_cost'] = $total_vioal_products_cost;
         
            
        
       	  $canceled_ids = Order::whereDate('created_at', Carbon::today())->where('status',5)->pluck('id')->toArray();

      	  $statistics['canceled_orders'] = count($canceled_ids);



      	  $statistics['total_canceled_orders'] = OrderPayment::whereDate('created_at', Carbon::today())->whereIn('order_id',$canceled_ids)->sum('cost');
              
     
           $statistics['total_discount_orders'] = Order::whereDate('created_at', Carbon::today())->where('discount','>',0)->count();
        
         $statistics['total_discount_money'] =  Order::whereDate('created_at', Carbon::today())->sum('discount');
         
          $statistics['final_profit'] = $statistics['total_got_money']-$statistics['total_canceled_orders']-$statistics['total_vioal_products_cost'];
          
          $counters = OrderPayment::whereDate('created_at', Carbon::today())->count();
             $statistics['avarage_cost'] = 0;
            if($counters>0)
           $statistics['avarage_cost'] = $statistics['final_profit'] / $counters;
          
          
      	  //dd($statistics);
      	  
      	  
      	   $orders = Order::whereDate('created_at', Carbon::today())->where('status',5)->latest()->paginate(1000);

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->delivery_id)->first();
 				
 				 if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Shop";
          		}

          }
          
          
          
            if($request->printer){
          
                 $statics = array();
                 
                 
              $statics['number_of_orders'] = "عدد الطلبات : ". " ". $statistics['number_of_orders'] ;
              
              $statics['total_packages'] = "عدد الباكدجات : ". " ". $statistics['total_packages'] ;
              
             $statics['total_got_money'] = "الاجمالي : ". " ". $statistics['total_got_money'] ;
              
              $statics['total_orders_money'] = "اجمالي الطلبات : ". " ". $statistics['total_orders_money'] ;
              
              $statics['total_delivery_money'] = "اجمالي التوصيل :  ". " ". $statistics['total_delivery_money'] ;
              
             $statics['total_texes'] = "عدد الطلبات : ". " ". $statistics['total_texes'] ;
             
              
              $statics['total_packages_money'] = "اجمالي الباكدجات : ". " ". $statistics['total_packages_money'] ;

              
             $statics['total_reminder_packages_cost'] = "المتبقي : ". " ". $statistics['total_reminder_packages_cost'] ;
              
             $statics['total_visa'] = " الفيزا : ". " ". $statistics['total_visa'] ;
              
              $statics['total_cash'] = " الكاش : ". " ". $statistics['total_cash'] ;
                     
              $statics['total_vodafone_cash'] = " فودافون كاش : ". " ". $statistics['total_vodafone_cash'] ;
                            
              $statics['total_fawry'] = "فوري : ". " ". $statistics['total_fawry'] ;
                                   
              $statics['total_vioal_products'] = "عدد المنتجات المتفوته : ". " ". $statistics['total_vioal_products'] ;
                            
              $statics['total_vioal_products_cost'] = "اجمالي التفويت : ". " ". $statistics['total_vioal_products_cost'];
              
              
              $statics['canceled_orders'] = "الطلبات الملغية : ". " ". $statistics['canceled_orders'] ;
                            
              $statics['total_canceled_orders'] = "اجمالي الملغي : ". " ". $statistics['total_canceled_orders'];
              
              $statics['total_discount_orders'] = "عدد الخصومات : ". " ". $statistics['total_discount_orders'] ;
                            
              $statics['total_discount_money'] = "اجمالي اللخصومات : ". " ". $statistics['total_discount_money'];
              
              
              
                 $statics['final_profit'] = "الربح النهائي : ". " ". $statistics['final_profit'] ;
                            
              $statics['avarage_cost'] = "متوسط الفرد : ". " ". $statistics['avarage_cost'];
              
        
                  return view('Admin.Home.print',compact('statics'));
                
            }

        return view('Admin.Home.home2',compact('statistics','orders'));
      }
      
      
      
   public function from_to(Request $request){
    
       
        $from = $request->from_date;
        $to = $request->to_date;
        
     
        
        

     $statistics = array();
     
     $orders_total_price = 1.5;
     
     
        $statistics['number_of_orders'] = Order::whereBetween('created_at', [$from, $to])->count();
        
         $statistics['total_packages'] = UserPackage::whereBetween('created_at', [$from, $to])->count();
        
        
       $statistics['total_got_money'] = OrderPayment::whereBetween('created_at', [$from, $to])->sum('cost');
     
     $statistics['total_orders_money'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('package_id',null)->sum('cost');
     
     
      $statistics['total_delivery_money'] = Order::whereBetween('created_at', [$from, $to])->sum('delivery_cost');
      
      
      $statistics['total_texes'] = ($statistics['total_got_money'] - $statistics['total_delivery_money']) * 0.14;
     
     $statistics['total_packages_money'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('order_id',null)->sum('cost');
     
     
     //فلوس الباكدجات الي المفروض تدفع 
   $statistics['total_packages_cost'] = UserPackage::whereBetween('created_at', [$from, $to])->sum('total_price');
   
   //فلوس الباكدجات المتبقيه 
   
    $statistics['total_reminder_packages_cost'] = $statistics['total_packages_cost'] - $statistics['total_packages_money'] ;
     
     
      $statistics['total_visa'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('payment_type',0)->sum('cost');
      
              $statistics['total_cash'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('payment_type',1)->sum('cost');
              
              $statistics['total_vodafone_cash'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('payment_type',2)->sum('cost');
              
              $statistics['total_fawry'] = OrderPayment::whereBetween('created_at', [$from, $to])->where('payment_type',3)->sum('cost');
              
     
 
     
     //المنتجات الي اتطلبت و مطلعتش من المطبخ او العميل رجعها
            
                  $total_real_products_cost = 0; 
      
  $today_orders_ids = Order::whereBetween('created_at', [$from, $to])->pluck('id')->toArray();

      $vioal_products = Cart::select('product_id','price')->where('deleted_at','!=',null)->whereIn('order_id',$today_orders_ids)->get();
            
             $total_vioal_products_cost = 0;
        
         $statistics['total_vioal_products'] = count($vioal_products);
 
         
        foreach($vioal_products as $vioal_product){
            
            if($vioal_product->price>0){
            $total_vioal_products_cost += ( $vioal_product->price + (0.14*$vioal_product->price) );
            }else {
                $price = Product::select('price_after')->where('id',$vioal_product->product_id)->first()->price_after;
                
                $total_vioal_products_cost += ( $price + (0.14*$price) );
            }
            
        }
         
         
         $statistics['total_vioal_products_cost'] = $total_vioal_products_cost;
         
            
        
              $canceled_ids = Order::whereBetween('created_at', [$from, $to])->where('status',5)->pluck('id')->toArray();

              $statistics['canceled_orders'] = count($canceled_ids);



              $statistics['total_canceled_orders'] = OrderPayment::whereBetween('created_at', [$from, $to])->whereIn('order_id',$canceled_ids)->sum('cost');
              
     
           $statistics['total_discount_orders'] = Order::whereBetween('created_at', [$from, $to])->where('discount','>',0)->count();
        
         $statistics['total_discount_money'] =  Order::whereBetween('created_at', [$from, $to])->sum('discount');
         
          $statistics['final_profit'] = $statistics['total_got_money']-$statistics['total_canceled_orders']-$statistics['total_vioal_products_cost'];
          
          $counters = OrderPayment::whereBetween('created_at', [$from, $to])->count();
             $statistics['avarage_cost'] = 0;
            if($counters>0)
           $statistics['avarage_cost'] = $statistics['final_profit'] / $counters;
          
          
              //dd($statistics);
              
              
               $orders = Order::whereBetween('created_at', [$from, $to])->where('status',5)->latest()->paginate(1000);

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->delivery_id)->first();
                        
                         if(!$order->delivery){
              $order->delivery = new Member();
              $order->delivery->name = "From Shop";
                  }

          }

        return view('Admin.Home.from_to',compact('statistics','orders'));
      }
      
      
 public function most_sold(Request $request){

            $most_sold =  array();


            $products = Product::select('id','name_en','image')->get();


            foreach ($products as $product) {

                  $counts = array();
              for($i=1; $i<13; $i++){

               $count = Cart::select('id')->whereMonth('created_at', $i)->where('product_id',$product->id)->count();
                  array_push($counts, $count);
               }

               $product->counts = $counts;

            }


             for($x=0; $x<12; $x++){
            

                    $temp_array =  array();

                   
                   $arr=$products;


                   $size = count($arr)-1;
                   for ($i=0; $i<$size; $i++) {
                            for ($j=0; $j<$size-$i; $j++) {
                              $k = $j+1;
                              if ($arr[$k]->counts[$x] > $arr[$j]->counts[$x]) {
                              
                               list($arr[$j], $arr[$k]) = array($arr[$k], $arr[$j]);
                        }
                      }
                     }


                     foreach ($arr as $product){ 
                    array_push($temp_array, $product);
                  }



              array_push($most_sold , $temp_array);



             }


         


        return view('Admin.Home.products-report',compact('most_sold'));
      }




public function canceled_orders(Request $request){


        $orders = Order::whereDate('created_at', Carbon::today())->where('status',5)->latest()->paginate(1000);

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->delivery_id)->first();
 				
 				 if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Shop";
          		}

          }

        return view('Admin.Orders.orders',compact('orders'));
      }
      
      
      
          public function filter_products(Request $request){

            $most_sold =  array();


            $products = Product::select('id','name_en','image')->get();


            foreach ($products as $product) {

                  $counts = array();
              for($i=1; $i<13; $i++){

               $count = Cart::select('id')->whereMonth('created_at', $i)->where('product_id',$product->id)->count();
                  array_push($counts, $count);
               }

               $product->counts = $counts;

            }


             for($x=0; $x<12; $x++){
            

                    $temp_array =  array();

                   
                   $arr=$products;


                   $size = count($arr)-1;
                   for ($i=0; $i<$size; $i++) {
                            for ($j=0; $j<$size-$i; $j++) {
                              $k = $j+1;
                              if ($arr[$k]->counts[$x] > $arr[$j]->counts[$x]) {
                              
                               list($arr[$j], $arr[$k]) = array($arr[$k], $arr[$j]);
                        }
                      }
                     }


                     foreach ($arr as $product){ 
                    array_push($temp_array, $product);
                  }



              array_push($most_sold , $temp_array);



             }


         


        return view('Admin.Reports.products-report',compact('most_sold'));
      }
      
      
      
       public function compare_months(Request $request){

    
                  $months_report = array();
        
            for($i=1; $i<13; $i++){
                  $statistics = array();
         $statistics['number_of_orders'] = intval(Order::whereMonth('created_at', $i)->count());
         $statistics['total_packages'] = UserPackage::whereMonth('created_at', $i)->count();
         $statistics['total_got_money'] = intval(OrderPayment::whereMonth('created_at', $i)->sum('cost'));
         $statistics['total_orders_money'] = intval(OrderPayment::whereMonth('created_at', $i)->where('package_id',null)->sum('cost'));
         $statistics['total_packages_money'] = intval(OrderPayment::whereMonth('created_at', $i)->where('order_id',null)->sum('cost'));



            array_push($months_report, $statistics);

            }

 

        return view('Admin.Home.compare-months',compact('months_report'));
      }
      
      
 

}
