<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\PromoCode;
 
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class PromoCodeController extends BaseController
{

     
  

      public function promo_codes(Request $request){
          
        $promo_codes = PromoCode::where('deleted_at',null)->get();
        
        
        return view('Admin.PromoCode.promo-codes',compact('promo_codes'));
      }




      public function add(Request $request){
          
          
        if($request->isMethod('get')){
         return view('Admin.PromoCode.add-promo-code');
       }
          



          $PromoCode = PromoCode::create([
                'name' => $request->name ,
                'limit' => $request->limit ,
                'percentage' => $request->percentage ,
                'code' => $request->code,
                'status' => $request->status ,
               
            ]);


        return Redirect::to('/Admin/promo_codes'); 
      }



  public function update(Request $request)
      {  


      $promo_code = PromoCode::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.PromoCode.edit-promo-code',compact('promo_code'));
         }


          $promo_code->name = $request->name;
          $promo_code->code = $request->code;
          $promo_code->limit = $request->limit;
          $promo_code->percentage = $request->percentage;
          $promo_code->status = $request->status;

     
          $promo_code->save();



           return  Redirect::to('/Admin/promo_codes');


      }
      

      public function edit(Request $request)
      {  


      $promo_code = PromoCode::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.PromoCode.edit-promo-code',compact('promo_code'));
         }


          $promo_code->name = $request->name;
          $promo_code->code = $request->code;
          $promo_code->limit = $request->limit;
          $promo_code->percentage = $request->percentage;
          $promo_code->status = $request->status;

     
          $promo_code->save();



           return  Redirect::to('/Admin/promo_codes');


      }


       public function delete(Request $request)
      {
             $category = PromoCode::where('id',$request->promo_code_id)->first();
             $category->deleted_at =  Carbon::now();
             $category->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'promo code deleted successfully'
          ]);
      }


   


}
