<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use View;
use App\Member;
use App\Position;
use App\Role;
use App\Permission;
 

class BaseController extends Controller {


     public  $user,$lang;


        public function __construct() {

          
             
              // dd(auth('Member')->check());


         $this->middleware(function ($request, $next) {

            $this->user  = (auth('Member')->check() );
            

            if($this->user){
              $this->user =  Member::where('id',auth('Member')->id())->first();

              $this->user->position = Position::where('id',$this->user->position_id)->first()->name_en;
              $this->user->permissions = Role::where('permission_id',Permission::where('id',$this->user->permission_id)->first()->id)->first();

            
              $user =   $this->user;
                }else {
                    $user=null;
                }


      

                   View::share('user', $user);


            return $next($request);


        });
 

 
          $lang = \App::getLocale();
          $this->lang=$lang;


        
       

        }

  }
