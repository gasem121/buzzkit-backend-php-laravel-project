<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Area;
use App\Branch;
use App\City;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class AreaController  extends BaseController {


      public function areas(Request $request){
        $areas = Area::where('deleted_at',null)->get();

        foreach ( $areas as $area) {
          $area->city = City::where('id',$area->city_id)->first();
          $area->branch = Branch::where('id',$area->branch_id)->first();
        }

        return view('Admin.Areas.areas',compact('areas'));
      }


 


      public function add(Request $request){

        if($request->isMethod('get')){

           $cities = City::where('deleted_at',null)->get();
           $branches = Branch::where('deleted_at',null)->get();

         return view('Admin.Areas.add-area',compact('cities','branches'));
       }
          

          $area = Area::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'delivery_fees' => $request->delivery_fees ,
                 'delivery_fees_temp' => $request->delivery_fees ,
                'city_id' => $request->city_id ,
                'branch_id' => $request->branch_id ,
                'status' => $request->status ,
            ]);


        return Redirect::to('/Admin/areas'); 
      }
      
      
      
        public function make_all_free(Request $request){
            
        if($request->status==0){
          $areas = Area::get();
          
          foreach($areas as $area){
              
              $area->delivery_fees = $area->delivery_fees_temp;
              $area->save();
          }
          
        }else {
            $area = Area::query()->update(['delivery_fees' => 0]);
        }

        return Redirect::to('/Admin/areas'); 
      }



      public function edit(Request $request)
      {  


      $area = Area::where('id',$request->id)->first();


         if($request->isMethod('get')){
           $cities = City::where('deleted_at',null)->get();
            $branches = Branch::where('deleted_at',null)->get();
            
           return view('Admin.Areas.edit-area',compact('area','cities','branches'));
         }


          $area->name_ar = $request->name_ar;
          $area->name_en = $request->name_en;
          $area->status = $request->status;
          $area->city_id = $request->city_id;
          $area->delivery_fees_temp = $request->delivery_fees_temp;
          $area->branch_id = $request->branch_id;
          $area->delivery_fees = $request->delivery_fees;

          
          $area->save();


           return  Redirect::to('/Admin/areas');
      }


       public function delete(Request $request)
      {
             $area = Area::where('id',$request->area_id)->first();
             $area->deleted_at =  Carbon::now();
             $area->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'Area deleted successfully'
          ]);
      }


   


}
