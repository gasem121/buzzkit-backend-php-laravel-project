<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\BaseController\Controller;
use Redirect;
use App\City;
use App\Member;
use App\Permission;
use App\Position;
use App\Branch;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class AuthController  extends BaseController
{

      public function employees(Request $request){

            $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id==-1){
            $employees = Member::where('deleted_at',null)->get();
            }else {
              $employees = Member::where('deleted_at',null)->where('branch_id',$branch_id)->get();  
            }
            
            
            foreach ($employees as $employee) {
                 $employee->permission = Permission::select('name_en')->where('id',$employee->permission_id)->first()->name_en;
                 $employee->position = Position::select('name_en')->where('id',$employee->position_id)->first()->name_en;

            }


        return view('Admin.Employees.employees',compact('employees'));
      }




      public function add(Request $request){



        if($request->isMethod('get')){

              $permissions = Permission::get();
              $positions = Position::get();
              $branches = Branch::get();
              
              $branch = new Branch();
              $branch['name_en'] = "All Branches";
              $branch['name_ar'] = "كل الفروع";
              $branch['id'] = -1;
               
               
              $branches[] = $branch;

         return view('Admin.Employees.add-employee',compact('permissions','positions','branches'));

       }
        

          $Member = Member::create([
                'name' => $request->name ,
                'national_id' => $request->national_id ,
                'image' => $request->image ,
                'phone' => $request->phone ,
                 'status' => $request->status ,
                'salary' => $request->salary ,
                 'branch_id' => $request->branch_id ,
                'password' => md5($request->password) ,
                'position_id' => $request->position_id ,
                'permission_id' => $request->permission_id ,
            ]);


        return Redirect::to('/Admin/employees'); 
      }



  
   public function sign_in(Request $request){
        return view('Admin.login');
        }

      public function login(Request $request)
      {


          $data = $request->validate([
              'phone' => 'required',
              'password' => 'required',
          ]);

          $Member = Member::where('phone',$request->phone)->where('password',md5($request->password))->first();

          if($Member) {

                auth()->guard('Member')->loginUsingId($Member->id, true);

                return Redirect::to('/Admin/orders/');
          }
          else{
               \Session::flash('error_message','the email or password is wrong');
               return back()->withInput($request->only('phone','remember') );
          }
      }

      public function logout()
      {
          if(auth()->guard('Member')->check())
              auth()->guard('Member')->logout();
          return back();
      }

      public function edit(Request $request)
      {

         $id = Crypt::decryptString($request->id);
              $permissions = Permission::get();
              $positions = Position::get();

          $employee = Member::where('id',$id)->first();
            $employee->permission = Permission::select('name_en')->where('id',$employee->permission_id)->first()->name_en;
        $employee->position = Position::select('name_en')->where('id',$employee->position_id)->first()->name_en;
           $branches = Branch::get();
    
              $branch = new Branch();
              $branch['name_en'] = "All Branches";
              $branch['name_ar'] = "كل الفروع";
              $branch['id'] = -1;
               
               
              $branches[] = $branch;

          return view('Admin.Employees.edit-employee',compact('employee','permissions','positions','branches'));
      }

      public function update(Request $request)
      {   


           // $validator = \Validator::make($request->all(),[
           //    'name' => 'required',
           //    'email' => 'required|unique:users,email,'.auth()->guard('Member')->id(),
           //    'phone' => 'required',
           //    'city_id' => 'required',
           // ]);
           // if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }

           // $member_data = [
           //     'name' => $request->name ,
           //     'email' => $request->email ,
           //     'phone' => $request->phone ,
           //     'city_id' => $request->city_id ,
           // ];

          $employee = Member::where('id',$request->id)->first();
          $employee->name = $request->name ;
          $employee->national_id = $request->national_id ;
          $employee->phone = $request->phone ;
          $employee->status = $request->status ;
          $employee->permission_id = $request->permission_id ;
          $employee->position_id = $request->position_id ;
          $employee->salary = $request->salary ;
           $employee->branch_id = $request->branch_id ;
       
          

          if($request->password){
          $employee->password =  md5($request->password) ;
          }

          if($request->image){
          $employee->image =  $request->image ;
          }

            $employee->save();



           return  Redirect::to('/Admin/employees/edit/'. Crypt::encryptString($request->id));


      }


       public function delete(Request $request)
      {
             $employee = Member::where('id',$request->user_id)->first();
             $employee->deleted_at =  Carbon::now();
             $employee->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'user deleted successfully'
          ]);
      }


    public function send_forget_password_email(Request $request)
    {
          $data = $request->validate([
              'email' => 'required',
          ]);

          $Member = Member::where('email',$request->email)->first();
          if($Member)
          {
             $Member->update([
                    'forgetpass_code' => \Str::random(80) ,
                    'forgetpass_code_date' => Carbon::now()
                  ]);
             \Mail::to($Member->email)->send(new \App\Mail\ForgetPassword($Member));
          }

          \Session::flash('flash_message',__('page.Forget password Email has send to your mail'));
          return redirect('');
    }


    public function resite_password_form($forgetpass_code)
    {
        $Member = Member::where('forgetpass_code',$forgetpass_code)
              ->where('forgetpass_code_date', '>', Carbon::now()->subMinutes(30)->toDateTimeString())
              ->orderBy('forgetpass_code_date', 'desc')->latest()->first();
        if(!$Member){
          return 'expired' ;
        }
        return view('Admin.layouts.reset_password',compact('Member','forgetpass_code'));
    }

    public function reset_password(Request $request)
    {
          $data = $request->validate([
            'forgetpass_code' => 'required',
            'password' => 'required',
          ]);

          $Member = Member::where('forgetpass_code',$request->forgetpass_code)
                ->where('forgetpass_code_date', '>', Carbon::now()->subMinutes(30)->toDateTimeString())
                ->orderBy('forgetpass_code_date', 'desc')->latest()->first();
          if(!$Member){
            return 'expired   ' ;
          }
        $Member->update([
          'forgetpass_code' => null ,
          'forgetpass_code_date' => null ,
          'password' => \Hash::make($request->password)
        ]);

        auth()->guard('Member')->loginUsingId($Member->id, true);
        return redirect('/');
    }


    public function change_password_page()
    {
        return view('Site/change_password');
    }

    //---api---
    public function change_password_action(Request $request)
    {
          $validator = \Validator::make($request->all(),[
              'old_password' => 'required',
              'password' => 'required',
          ]);
          if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }


            $member = Member::find(auth('Member')->id());
          if( \Hash::check($request->old_password, $member->password ) )
          {
              $member->update([
                  'password' => \Hash::make($request->password)
              ]);

              return response()->json([
                'status' => 'success',
                'flash_message' => __('page.password_has_changed')
              ]);
          }
          else //else of \Hash::check
          {
             return response()->json([
               'status' => 'faild' ,
               'flash_message' => __('page.change_password_wrong_old_pass')
             ]);
          }
    }


}
