<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Variation;
use App\Attribute;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class VariationController  extends BaseController {


      public function variations(Request $request){
        $variations = Variation::where('deleted_at',null)->get();

        foreach($variations as $variation){

           $variation->items=$this->getAttributes($variation->id);
          
        }

        return view('Admin.Variations.variations',compact('variations'));
      }



      public function getAttributes($id){
           $temp = Attribute::select('name_en')->where('variation_id',$id)->get()->pluck('name_en');

          if($temp){
            $i=false;
            $items="[ ";

            foreach ($temp as $name ) {

                    if($i)$items.=", ";
                    $i=true;
                    $items.=$name;
               }
            $items.=" ]";

           
           }

           return $items;
      }


      public function add(Request $request){
        if($request->isMethod('get')){
         return view('Admin.Variations.add-variation');
       }
          

          $variation = Variation::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                'added_by' => 1 ,
            ]);


        return Redirect::to('/Admin/variations'); 
      }



      public function edit(Request $request)
      {  


      $variation = Variation::where('id',$request->id)->first();


         if($request->isMethod('get')){
           $attributes = Attribute::where('deleted_at',null)->where('variation_id',$variation->id)->get();
           return view('Admin.Variations.edit-variation',compact('variation','attributes'));
         }


          $variation->name_ar = $request->name_ar;
          $variation->name_en = $request->name_en;
          $variation->status = $request->status;
          $variation->save();


           return  Redirect::to('/Admin/variations');
      }


       public function delete(Request $request)
      {
             $variation = Variation::where('id',$request->variation_id)->first();
             $variation->deleted_at =  Carbon::now();
             $variation->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'Variation deleted successfully'
          ]);
      }


   


}
