<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Branch;
 
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class BranchController  extends BaseController
{

      public function branches(Request $request){


        $branches = Branch::where('deleted_at',null)->get();


        return view('Admin.Branches.branches',compact('branches'));
      }




      public function add(Request $request){

        if($request->isMethod('get')){
         return view('Admin.Branches.add-branch');
       }
         
          $Branch = Branch::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                 'start_time' => $request->start_time ,
                  'end_time' => $request->end_time ,
                'address_en' => $request->address_en ,
                  'address_ar' => $request->address_ar ,
         
            ]);


        return Redirect::to('/Admin/branches'); 
      }



      public function edit(Request $request)
      {  


      $branch = Branch::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.Branches.edit-branch',compact('branch'));
         }

          $branch->name_ar = $request->name_ar;
          $branch->name_en = $request->name_en;
          $branch->address_en = $request->address_en;
          $branch->address_ar = $request->address_ar;
          
           $branch->start_time = $request->start_time;
          $branch->end_time = $request->end_time;
          
          $branch->status = $request->status;
 

          $branch->save();



           return  Redirect::to('/Admin/branches');


      }


       public function delete(Request $request)
      {
             $branch = Branch::where('id',$request->branch_id)->first();
             $branch->deleted_at =  Carbon::now();
             $branch->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'branch deleted successfully'
          ]);
      }



   public function change_all_status(Request $request)
      {
          Branch::query()->update(['status' => $request->status]);
          
          return response()->json([
            'status' => 'success',
            'flash_message' => 'Status Changed successfully'
          ]);
      }


   


}
