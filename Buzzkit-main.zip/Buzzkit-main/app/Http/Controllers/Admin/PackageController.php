<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Package;
use App\Category;
use App\Variation;
use App\PackageAttribute;
use App\Attribute;
use App\PackageCategoryLimit;
use App\UserPackage;
use App\UserAddress;
use App\Order;
use App\Customer;
use App\Area;
use App\Member;
use App\User;
use App\OrderPayment;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class PackageController  extends BaseController
{

      public function packages(Request $request){


        $packages = Package::where('deleted_at',null)->get();

    	foreach ($packages as $package) {
    		$meals_limit = "";
    		$limits = PackageCategoryLimit::where('package_id',$package->id)->get();

    		foreach ($limits as $limit) {
    		 $meals_limit .= Category::where('id',$limit->category_id)->first()->name_en." ".$limit->products_limit." \r\n";
    		}

    		$package->meals_limit=$meals_limit;

    	}
 

        return view('Admin.Packages.packages',compact('packages'));
      }



          public function orders_packages(Request $request){


        $orders = Order::latest()->where('package_id',$request->package_id)->paginate(1000);
        
        $package_id = $request->package_id;

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->user_id)->first();
          }
    
    
      $payments = OrderPayment::where('package_id',$request->package_id)->get();
      
           
        return view('Admin.Orders.package-orders',compact('package_id','orders','payments'));
      }


        public function today_packages(Request $request){


        $packages = UserPackage::whereDate('created_at', Carbon::today())->latest();
        
        
        
           $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
             $packages->where('branch_id',$branch_id);
                }

      $packages = $packages->get();

      foreach ($packages as $package) {
        $package->package_details = Package::where('id',$package->package_id)->first();
        $package->user = Customer::where('id',$package->user_id)->first();
      }
 

        return view('Admin.Packages.users-packages',compact('packages'));
      }


      public function users_packages(Request $request){

        $packages = UserPackage::latest();
        
                $branch_id = auth()->guard('Member')->user()->branch_id;
        
        if($branch_id!=-1){
             
             $packages->where('branch_id',$branch_id);
                }

      $packages = $packages->get();
      

      foreach ($packages as $package) {
        $package->package_details = Package::where('id',$package->package_id)->first();
        $package->user = Customer::where('id',$package->user_id)->first();
      }
 

        return view('Admin.Packages.users-packages',compact('packages'));
      }
      
      
      public function print_package_order(Request $request){
          
         $package = UserPackage::where('id',$request->package_id)->first();
          
          
     
        $package->package_details = Package::where('id',$package->package_id)->first();
        
        
     
        $package->vat = $package->total_price - $package->package_details->price_after;
        
        $package->total_price = $package->package_details->price_after;
        
        $package->user = Customer::where('id',$package->user_id)->first();
        $totals = $package->total_price - $package->discount;
        
        $package->total_price+=$package->vat;
        
              $package->invoice = "رقم الفاتوره :  ". "# ".$package->id;
              $package->invoice_date = " وقت الاصدار : ".$package->created_at;
              $package->invoice_customer = "اسم العميل : ".$package->user->name;
              $package->invoice_phone = "رقم الهاتف : ".$package->user->phone;
              $package->total_price = "السعر النهائي : ".$package->total_price." ج.م ";
              $package->discount = " الخصم : ".$package->discount." ج.م ";
              $package->sub_total = " الاجمالي : " .$totals." ج.م ";
              $package->vat = " الضريبة  (14%) : ".$package->vat." ج.م ";
             
  
          
          return view('Admin.Orders.package-printer',compact('package'));
          
      }
      
      
      
      public function search_packages(Request $request){

          $customer = Customer::where('phone',$request->text)->first();
        
        $packages = null;
         
        if($customer){
           $packages = UserPackage::where('user_id',$customer->id)->latest()->paginate(1000);
        }else {
           $packages =  UserPackage::where('id',$request->text)->latest()->paginate(1000);
        }
        

      foreach ($packages as $package) {
        $package->package_details = Package::where('id',$package->package_id)->first();
        $package->user = Customer::where('id',$package->user_id)->first();
      }
 

        return view('Admin.Packages.users-packages',compact('packages'));
      }



      public function add(Request $request){


          $categories = Category::where('deleted_at',null)->get();

        if($request->isMethod('get')){
         return view('Admin.Packages.add-package',compact('categories'));
       }
          
          
       
    

          $package = Package::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                'image' => $request->image ,
                'details_ar' => $request->details_ar ,
                'details_en' => $request->details_en ,
                'price_before' => $request->price_before ,
                'price_after' => $request->price_after ,
            ]);


          foreach ($categories as $category) {

          	$limit = $request['max_meal_'.$category->id];
          	if(!$limit)$limit=0;

 			PackageCategoryLimit::create([
                'package_id' => $package->id ,
                'category_id' => $category->id ,
                'products_limit' => $limit ,
               
            ]);

          }



        return Redirect::to('/Admin/packages'); 
      }



      public function edit(Request $request)
      {  


  		$categories = Category::where('deleted_at',null)->get();
        $package = Package::where('id',$request->id)->first();
 


         if($request->isMethod('get')){
         	 
         	 foreach ($categories as $category) {
         	     
         	 	$category->products_limit = PackageCategoryLimit::where('package_id',$package->id)->where('category_id',$category->id)->first();
         	 	
         	 	if($category->products_limit){
         	 	    $category->products_limit=$category->products_limit->products_limit;
         	 	}
         	 	
         	 	
         	 }

           return view('Admin.Packages.edit-package',compact('package','categories'));
         }


          $package->name_ar = $request->name_ar;
          $package->name_en = $request->name_en;
          $package->status = $request->status;
          $package->details_ar = $request->details_ar;
          $package->details_en = $request->details_en;
          $package->price_before = $request->price_before;
          $package->price_after = $request->price_after;
 


          if($request->image){
          $package->image =  $request->image ;
          }

           PackageCategoryLimit::where('package_id',$package->id)->delete();

           foreach ($categories as $category) {

          	$limit = $request['max_meal_'.$category->id];
          	if(!$limit)$limit=0;

 			PackageCategoryLimit::create([
                'package_id' => $package->id ,
                'category_id' => $category->id ,
                'products_limit' => $limit ,
               
            ]);

          }


          $package->save();



           return  Redirect::to('/Admin/packages');


      }


       public function delete(Request $request)
      {
             $package = Package::where('id',$request->package_id)->first();
             $package->deleted_at =  Carbon::now();
             $package->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'package deleted successfully'
          ]);
      }




       public function package_cashier(Request $request){


        $categories = Category::where('deleted_at',null)->get();
        $packages = Package::where('deleted_at',null)->get();
        $areas = Area::where('deleted_at',null)->get();
        
           foreach ($packages as $package) {
        $meals_limit = "";
        $limits = PackageCategoryLimit::where('package_id',$package->id)->get();

        foreach ($limits as $limit) {
         $meals_limit .= Category::where('id',$limit->category_id)->first()->name_en." ".$limit->products_limit." \r\n";
        }

        $package->meals_limit=$meals_limit;
        }

        return view('Admin.Orders.package_cashier',compact('packages','areas'));
      }

   


}
