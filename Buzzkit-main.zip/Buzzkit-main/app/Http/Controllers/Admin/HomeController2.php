<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Order;
use App\Customer;
use App\Member;
use App\Category;
use App\Product;
use App\Package;
use App\Variation;
use App\ProductAttribute;
use App\Attribute;
use App\CartAttribute;
use App\UserPackage;
use App\UserAddress;
use App\Area;
use App\User;
use App\Cart;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class HomeController  extends BaseController
{

      
      public function home(Request $request){
        return view('Admin.Home.home');
      }

   


}
