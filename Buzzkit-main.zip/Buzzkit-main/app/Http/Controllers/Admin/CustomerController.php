<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\City;
use App\Customer;
use App\Permission;
use App\Position;
use App\UserAddress;
use App\Order;
use App\Area;
use App\Suggestion;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class CustomerController  extends BaseController
{

    

   public function customers(Request $request){
            $customers = Customer::get();
            
            foreach($customers as $customer){
                 $customer->orders = Order::where('user_id',$customer->id)->count();
             $customer->orders_cost = Order::where('user_id',$customer->id)->sum('total_price');
            }
             
             
        return view('Admin.Customers.customers',compact('customers'));
      }



 

       public function change_status(Request $request)
      {
             $customer = Customer::where('id',$request->customer_id)->first();
             $customer->status =  ($customer->status==0) ? 1 : 0;
             
        
             
             $customer->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'user deleted successfully'
          ]);
      }

        public function search_customer(Request $request){


          $customer = Customer::where('phone',$request->user_phone)->first();


          if($customer){
             $customer->address = UserAddress::latest()->where('user_id',$customer->id)->first();

          if($customer->address)
          $customer->address->area = Area::latest()->where('id',$customer->address->area_id)->first();

         return response()->json([
            'status' => 'success',
            'user' => $customer
          ]);
       }

          return response()->json([
            'status' => 'fail',
            
          ]);


      }
      
      
         public function suggestions(Request $request){
        $suggestions = Suggestion::orderBy('is_contacted')->get();
        return view('Admin.Customers.suggestions',compact('suggestions'));
      }



       public function change_suggestions_status(Request $request)
      {
             $suggestion = Suggestion::where('id',$request->suggestion_id)->first();
             $suggestion->is_contacted =  ($suggestion->is_contacted==0) ? 1 : 0;
             $suggestion->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'Status changed successfully'
          ]);
      }


 
}
