<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\City;
use App\Area;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class CityController  extends BaseController {


      public function cities(Request $request){
        $cities = City::where('deleted_at',null)->get();

        foreach ($cities as $city) {
           $city->areas = Area::where('city_id',$city->id)->count();
        }

        return view('Admin.Cities.cities',compact('cities'));
      }


 


      public function add(Request $request){

        if($request->isMethod('get')){

           $cities = City::where('deleted_at',null)->get();

         return view('Admin.Cities.add-city',compact('cities'));
       }
          

          $city = City::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
            ]);


        return Redirect::to('/Admin/cities'); 
      }



      public function edit(Request $request)
      {  


      $city = City::where('id',$request->id)->first();


         if($request->isMethod('get')){
           $cities = City::where('deleted_at',null)->get();
           return view('Admin.Cities.edit-city',compact('city','cities'));
         }


          $city->name_ar = $request->name_ar;
          $city->name_en = $request->name_en;
          $city->status = $request->status;

          
          $city->save();


           return  Redirect::to('/Admin/cities');
      }


       public function delete(Request $request)
      {
             $city = City::where('id',$request->city_id)->first();
             $city->deleted_at =  Carbon::now();
             $city->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'City deleted successfully'
          ]);
      }


   


}
