<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Order;
use App\Customer;
use App\Member;
use App\Category;
use App\Product;
use App\Package;
use App\Variation;
use App\ProductAttribute;
use App\Attribute;
use App\CartAttribute;
use App\UserPackage;
use App\ProductMaterial;
use App\Material;
use App\UserAddress;
use App\Area;
use App\OrderPayment;
use App\PackageCategoryLimit;
use App\User;
use App\Cart;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class OrderController extends BaseController
{

      public function orders(Request $request){

         $orders = Order::latest();	
         
           $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
            // $orders->where('branch_id',$branch_id);
                }

         if($this->user->position_id == 3 ){
             
        //  	$orders = $orders->where('delivery_id',$this->user->id)->paginate(1000);
        
        $orders = $orders->paginate(1000);
         }else {
         	$orders = $orders->paginate(1000);
         }

          foreach($orders as $order){
              
          	 $order->user = Customer::where('id',$order->user_id)->first();
          	  $order->delivery = Member::where('id',$order->delivery_id)->first();

          	  if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}
          		
          		$order->total_price-= $order->delivery_cost;
           
        
            $order->original_price = ceil($order->total_price / 1.14);
            
             //dd($order->original_price);
            
            $order->taxes = floor($order->original_price * 0.14);
            
            
            $order->price_without_taxes =  $order->original_price ;
            
            
            $price_with_taxes = round($order->taxes+$order->original_price);
            
            
               $order->total_price = round(($order->taxes+$order->original_price) + $order->delivery_cost);
               
            $order->discount_result = "";
            
            if($order->discount){
                
             
                
                $discount_result = "Discount : ".$order->discount ." % \n\r Total Before discount : ".$order->total_price. " EGP";
                
                // .  ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  )." EGP";
                
                $order->total_price  = ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  );
                
              $order->discount_result = $discount_result;
                            
            }
            
         
            
            
            if($order->payment_type == 0){
                $order->payment_type = "CASH";
            }else {
                $order->payment_type = "VISA";
            }


          }

        return view('Admin.Orders.orders',compact('orders'));
      }


   public function customer_orders(Request $request){

         $orders = Order::where('user_id',$request->customer_id)->latest();	
         
           $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
             //$orders->where('branch_id',$branch_id);
                }

         if($this->user->position_id == 3 ){
             
         	$orders = $orders->where('delivery_id',$this->user->id)->paginate(1000);
         }else {
         	$orders = $orders->paginate(1000);
         }

          foreach($orders as $order){
              
          	 $order->user = Customer::where('id',$order->user_id)->first();
          	  $order->delivery = Member::where('id',$order->delivery_id)->first();

          	  if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}
          		
          		$order->total_price-= $order->delivery_cost;
           
        
            $order->original_price = ceil($order->total_price / 1.14);
            
             //dd($order->original_price);
            
            $order->taxes = floor($order->original_price * 0.14);
            
            
            $order->price_without_taxes =  $order->original_price ;
            
            
            $price_with_taxes = round($order->taxes+$order->original_price);
            
            
               $order->total_price = round(($order->taxes+$order->original_price) + $order->delivery_cost);
               
            $order->discount_result = "";
            
            if($order->discount){
                
             
                
                $discount_result = "Discount : ".$order->discount ." % \n\r Total Before discount : ".$order->total_price. " EGP";
                
                // .  ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  )." EGP";
                
                $order->total_price  = ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  );
                
              $order->discount_result = $discount_result;
                            
            }
            
         
            
            
            if($order->payment_type == 0){
                $order->payment_type = "CASH";
            }else {
                $order->payment_type = "VISA";
            }


          }

        return view('Admin.Orders.orders',compact('orders'));
      }
      
    public function print(Request $request){
        
        
        return view('Admin.Orders.printer');
        
    }

     


      public function today_orders(Request $request){


        $orders = Order::whereDate('created_at', Carbon::today())->latest();
        
        
         $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
             //$orders->where('branch_id',$branch_id);
                }

         if($this->user->position_id == 3 ){
             
         	$orders = $orders->where('delivery_id',$this->user->id)->paginate(1000);
         }else {
         	$orders = $orders->paginate(1000);
         }

          foreach($orders as $order){
              
          	 $order->user = Customer::where('id',$order->user_id)->first();
          	  $order->delivery = Member::where('id',$order->delivery_id)->first();

          	  if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}
          		
          		$order->total_price-= $order->delivery_cost;
           
        
            $order->original_price = ceil($order->total_price / 1.14);
            
             //dd($order->original_price);
            
            $order->taxes = floor($order->original_price * 0.14);
            
            
            $order->price_without_taxes =  $order->original_price ;
            
            
            $price_with_taxes = round($order->taxes+$order->original_price);
            
            
               $order->total_price = round(($order->taxes+$order->original_price) + $order->delivery_cost);
               
            $order->discount_result = "";
            
            if($order->discount){
                
             
                
                $discount_result = "Discount : ".$order->discount ." % \n\r Total Before discount : ".$order->total_price. " EGP";
                
                // .  ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  )." EGP";
                
                $order->total_price  = ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  );
                
              $order->discount_result = $discount_result;
                            
            }
            
         
            
            
            if($order->payment_type == 0){
                $order->payment_type = "CASH";
            }else {
                $order->payment_type = "VISA";
            }


          }

        return view('Admin.Orders.orders',compact('orders'));
      }

    public function canceled_orders(Request $request){


        $orders = Order::whereDate('created_at', Carbon::today())->where('status',5)->latest();
        
        
        $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
            // $orders->where('branch_id',$branch_id);
                }
                
                
        $orders = $orders->paginate(1000);

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->delivery_id)->first();
 				
 				 if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}

          }

        return view('Admin.Orders.orders',compact('orders'));
      }
      
      
      public function search_orders(Request $request){
            
            
        $customer = Customer::where('phone',$request->text)->first();
        
         $orders = null;
         
        if($customer){
           $orders =  Order::where('user_id',$customer->id)->latest();
        }else {
           $orders =  Order::where('id',$request->text)->latest();
        }
        
        
        $branch_id = auth()->guard('Member')->user()->branch_id;
            
            
            if($branch_id!=-1){
             
             //$orders->where('branch_id',$branch_id);
                }
                
                
        $orders = $orders->paginate(1000);
        
       

          foreach($orders as $order){
             $order->user = Customer::where('id',$order->user_id)->first();
              $order->delivery = Member::where('id',$order->delivery_id)->first();
 				
 				 if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}

          }

        return view('Admin.Orders.orders',compact('orders'));
      }




       public function cashier(Request $request){

        $package_id = $request->package_id;
        $search_phone ='';


        if(!$package_id){
          $package_id=0;
        }else {
            $package_details=UserPackage::where('id',$package_id)->first();;
          $user = Customer::where('id',$package_details->user_id)->first();
          $search_phone = $user->phone;
        }
        
        $category_temp = array();
        $categories = Category::where('deleted_at',null)->get();
        $products = Product::where('deleted_at',null)->get();
        $areas = Area::where('deleted_at',null)->get();
        $deliveries = User::where('deleted_at',null)->where('position_id','3')->get();

 
            
            $products=array();
            $deleted_indexes=array();
          for($i=0; $i<count($categories); $i++){
              
              
              $category = $categories[$i];
                
              if($package_id>0){
                  
                  
                $package_category_limitation  =  PackageCategoryLimit::where('products_limit','>',0)->where('package_id', $package_details->package_id)->where('category_id',$category->id)->first();
                    
                      
                if($package_category_limitation){
                   array_push($deleted_indexes,$i);
                } 
                
              }    
                
              $category->products = Product::where('category_id',$category->id)->get();
                
                  $variations = Variation::where('deleted_at',null)->get();
  
             foreach ($category->products as $product) {
            
             $product_attributes = ProductAttribute::where('product_id', $product->id)->get();
             $result = array();

              
              foreach ($product_attributes as $product_attribute) {
                  $attribute = Attribute::where('id',$product_attribute->attribute_id)->first();

                  $attribute->variation_name = Variation::where('id',$attribute->variation_id)->first()->name_en;


                  if(!array_key_exists("a_".$attribute->variation_id,$result)){

               
                  
                  $result['a_'.$attribute->variation_id] = array();
                  array_push($result['a_'.$attribute->variation_id], $attribute);
                  }else {
                    array_push($result['a_'.$attribute->variation_id], $attribute);
                  }
               

                  //array_push($result, $attribute);
              }

              $product->variations = $result;
              $product->variation_count= count($product->variations);

               if($package_id>0){
                $product->price_after=0;
                $product->price_before=0;
              }
             
     

            }
            
            $categories[$i] = $category;
            
            if(count($category->products)>0){
                foreach($category->products as $pro){
                    array_push($products, $pro);
                }
            }
            
          }
          
          $products=array();
    
        if($package_id>0){
        for($i=0; $i<count($deleted_indexes); $i++){
            array_push($category_temp,$categories[$deleted_indexes[$i]]);
        }
    
         $categories=$category_temp;
         
         foreach($categories as $category){
             
              foreach($category->products as $pro){
             array_push($products,$pro);
             
              }
         }
         
         
             
        }
        
       
      
        return view('Admin.Orders.cashier',compact('categories','products','areas','deliveries','package_id','search_phone'));
      }






public function confirm_order(Request $request){  

    

          $res="";

          $customer = null;
          $user_address = null;


          if($request->search_phone){

        $customer = Customer::where('phone',$request->search_phone)->first();
         
          }
      

         if($customer==null){
             
             
              if(!$request->user_name || !$request->user_phone){
              dd("Please enter customer name and phone");
              }
          

           $customer = Customer::create([
                'name' => $request->user_name ,
                'phone' => $request->user_phone ,
                
            ]);

         }
         
        // dd($customer);



        $user_address = UserAddress::where('area_id',$request->area_id)->where('address',$request->address)->where('user_id',$customer->id)->first();


        if($request->delivery_id==0){
                   $request->user_address = "لا يوجد عنوان (استلام من المكان )";
        }
    
      if($user_address==null){

          if(!$request->user_address){
              dd("Please enter customer use address");
          }
          
        $user_address =  UserAddress::create([
                'user_id' => $customer->id ,
                'area_id' => $request->area_id ,
                'address' => $request->user_address ,
            ]);

      }

    
    if($request->discount_amount==null){
        $request->discount_amount=0;
    }
    
    
    $delivery_cost = 0;
    
    if($request->delivery_id){
    $delivery_cost = Area::where('id',$request->area_id)->first()->delivery_fees;
    } 


    $location_area = Area::where('id',$request->area_id)->first();

    if( $location_area){
      $branch_id=$location_area->branch_id;  
    }else {
        $branch_id=-1;
    }

     $order =  Order::create([
                'user_id' => $customer->id ,
                'discount' => $request->add_discount ,
                'total_price' => $request->total_bill_value ,
                'delivery_id' => $request->delivery_id ,
                'discount' => $request->discount_amount ,
                'location_id' => $user_address->id ,
                 'branch_id' => $branch_id ,
                'package_id'  => $request->package_id,
                'comment'  => $request->order_comment,
                'delivery_cost' => $delivery_cost
            ]);


       OrderPayment::create([
                'order_id' => $order->id ,
                'cost' => $request->paid_amount ,
                 'payment_type' => $request->payment_type , 
            ]);


   

        for($i=0; $i<100; $i++){




            if($request['cart_'.$i]){

              $temp_ids = explode(",",$request['cart_'.$i]);


              if($temp_ids[0]!="0"){
              $cart = Cart::create([
                'order_id' => $order->id ,
                'quantity' => $request['qty'.$i] ,
                'product_id' => $temp_ids[0] ,
              ]);


              //decrease from materials 

              
                  
         

                       $product_materials = ProductMaterial::where('product_id', $temp_ids[0])->get();


                  foreach ($product_materials as $product_material) {

                    $material = Material::where('id',$product_material->material_id)->first();

                    
                    if($material&&$material->cooking_rate>0){

                      $after_cooking  = $material->quantity * $material->cooking_rate ; 
                      $after_cooking -= $product_material->quantity * $request['qty'.$i];
                      $lost_quantity = $after_cooking / $material->cooking_rate;


                       $material->quantity = $lost_quantity;
                       $material->save();

                    }else if($material&&$material->cooking_rate<0) {

                      $after_cooking  = $material->quantity / (-1*$material->cooking_rate) ; 
                      $after_cooking -= $product_material->quantity * $request['qty'.$i];

                     $lost_quantity = $after_cooking * (-1*$material->cooking_rate);

                       $material->quantity = $lost_quantity;
                       $material->save();

                    }


                   

                  }

              
       


              //adding attriibutes
              for($j=1; $j<count($temp_ids); $j++){
                CartAttribute::create([
                'cart_id' => $cart->id ,
                'attribute_id' => $temp_ids[$j] ,
              ]);

                 }

             }else {

               //custom order
 					$cart = Cart::create([
                'order_id' => $order->id ,
                'quantity' => $request['qty'.$i] ,
                'product_id' => 0 ,
                'price' => $temp_ids[2] ,
                'custom_meal' => $temp_ids[1] ,
              ]);

             } 

           }


        }

       
      return Redirect::to('/Admin/orders/printer/'.$order->id.'/1'); 
      }


     public function confirm_package_order(Request $request){  

          $res="";

          $customer = null;
          $user_address = null;


          if($request->search_phone){

        $customer = Customer::where('phone',$request->search_phone)->first();
         
          }
      

         if($customer==null){

           $customer = Customer::create([
                'name' => $request->user_name ,
                'phone' => $request->user_phone ,
                
            ]);

         }


        $user_address = UserAddress::where('area_id',$request->area_id)->where('address',$request->address)->first();


      if($user_address==null){
        $user_address =  UserAddress::create([
                'user_id' => $customer->id ,
                'area_id' => $request->area_id ,
                'address' => $request->user_address ,
            ]);
            
        

      }
      
      
     $location_area = Area::where('id',$request->area_id)->first();

    if( $location_area){
      $branch_id=$location_area->branch_id;  
    }else {
        $branch_id=-1;
    }
        
        

        if(!$request->discount_amount){
          $request->discount_amount=0;
        }

        for($i=0; $i<100; $i++){


            if($request['cart_'.$i]){
                
                
              $cart = UserPackage::create([
                'package_id' => $request['cart_'.$i] ,
                'user_id' => $customer->id ,
                 'branch_id' => $branch_id ,
                  'discount' => $request->discount_amount ,
                'total_price' => $request->total_bill_value ,
              ]);

                 }
       }


      OrderPayment::create([
                'package_id' => $cart->id ,
                'cost' => $request->paid_amount ,
                 'payment_type' => $request->payment_type , 
            ]);
        
        
    
        
           return Redirect::to('/Admin/packages/printer/'.$cart->id); 
      }

       public function order_products(Request $request){


        $order = Order::where('id',$request->order_id)->first();

        $order->paid_amount = OrderPayment::where('order_id',$request->order_id)->sum('cost');
 
          $order->user = Customer::where('id',$order->user_id)->first();
          $order->delivery = Member::where('id',$order->delivery_id)->first();
          
          
            // $order->original_price = round($order->total_price / 1.14);
            
             
            
            // $order->taxes = round($order->original_price * 0.14);
            
            
            // $order->price_without_taxes =  $order->original_price ;
            
            // $order->total_price = ($order->taxes+$order->original_price) + $order->delivery_cost;
            
        	$order->total_price-= $order->delivery_cost;
           
        
            $order->original_price = ceil($order->total_price / 1.14);
            
             //dd($order->original_price);
            
            $order->taxes = floor($order->original_price * 0.14);
            
            
            $order->price_without_taxes =  $order->original_price ;
            
            
            $price_with_taxes = round($order->taxes+$order->original_price);
            
            
               $order->total_price = round(($order->taxes+$order->original_price) + $order->delivery_cost);
               
            $order->discount_result = "";
            
            if($order->discount){
                
             
                
                $discount_result = "Discount : ".$order->discount ." % \n\r Total Before discount : ".$order->total_price. " EGP";
                
                // .  ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  )." EGP";
                
                $order->total_price  = ( $price_with_taxes - round(($order->discount/100)* $price_with_taxes)  );
                
              $order->discount_result = $discount_result;
                            
            }
            
            
              if($order->payment_type == 0){
                $order->payment_type = "CASH";
            }else {
                $order->payment_type = "VISA";
            }
            
            


         $order->user->address =   UserAddress::where('id',$order->location_id)->first();


         	  if(!$order->delivery){
          	  $order->delivery = new Member();
          	  $order->delivery->name = "From Mobile";
          		}
          		
          		if( $order->user->address){
          		    
          		     $order->user->address->area= Area::where('id',$order->user->address->area_id)->first()->name_ar;
          		
          		}



          $order->products = Cart::select('carts.*',"products.image","products.price_before","products.price_after","products.name_ar","products.name_en",'image' )
                                ->leftJoin('products','products.id','carts.product_id')
                                ->groupBy('carts.id')
                                ->where('carts.order_id',$request->order_id)
                                 ->where('carts.deleted_at',null)
                                ->limit(80)
                                ->get();

  
        foreach ($order->products as $product) {

        	    $variations = "";
        	    
        	    if($product->custom_meal){
        		    
        		    //135|22-17-9,147,160,163;
        		    
        		    $selected_products = array();
        		    
        		    $items = explode(",", $product->custom_meal);
        		    $counter=0;
        		      foreach($items as $item){
        		      $variations .= "#".(++$counter)."\n\r";    
        		          
        		          $attributes="";
        		         if(str_contains($item,'|')){
        		                $splited = explode("|",$item);
        		                array_push($selected_products,$splited[0]);
        		                
        		                   $product_id = $splited[0];
        		                   
        		                   $attr = explode("-", $splited[1]);
        		                  $attrs = Attribute::whereIn('id',$attr)->get();
        	
        		                  foreach($attrs as $atr){
        		                      $attributes = Variation::where('id',$atr->variation_id)->first()->name_en. " : ". $atr->name_en ."\n\r";
        		                  }
        		                   //$variations.=$attributes;
        		                  }else {
        		                      array_push($selected_products,$item);
        		                        $product_id = $item;
        		                  }
        		                  
        		           $variations.= Product::select('name_en','name_ar')->where('id',$product_id)->first()->name_en."\n\r".$attributes;
        		             $variations.="\n\r";
        		      }
        		      
        		      
        		       $product->variations = $variations;
        		       
        		      
        		       
        		       $product->price_after += $product->price;
        		 
        		}else {
               $product->variations =  $this->getVariations($product->id);
        		}
          }  
        
        
        
        //don't delete this 
        $payments = OrderPayment::where('order_id',$request->order_id)->get();
        
        
        
        if($request->from_printer){
                
        		
        	
               
                //dd($order->sub_total);    
                
                $totals = 0.0; 
                foreach($order->products as $product){
                	
                	
                	if($product->variations){
                	 $product->name_ar = $product->name_ar." ".$product->variations;
                	}
                
                    if($order->package_id){
                        $product->price_after=0;
                    }
                    
                    $totals +=$product->price_after*$product->quantity;
                }
                
              $order->vat = .14*$totals;
              
              
               $order->sub_total =  $order->vat + $totals - doubleval($order->discount) + doubleval($order->delivery_cost);
              
              
              $order->invoice = "رقم الفاتوره :  ". "# ".$order->id;
              $order->invoice_date = " وقت الاصدار : ".$order->created_at;
              $order->invoice_customer = "اسم العميل : ".$order->user->name;
              $order->invoice_area = "المنطقة : ".$order->user->address->area;
              $order->invoice_address = "العنوان : ".$order->user->address->address;
              $order->invoice_phone = "رقم الهاتف : ".$order->user->phone;
              $order->total_price = "السعر النهائي : ".$order->total_price." ج.م ";
              $order->delivery_cost = "سعر التوصيل : ".$order->delivery_cost." ج.م ";
              $order->discount = " الخصم : ".$order->discount." ج.م ";
             $order->sub_total = " الاجمالي : " .$totals." ج.م ";
             $order->vat = " الضريبة  (14%) : ".$order->vat." ج.م ";
             	
             	if($order->comment){
              $order->comment = " ملاحظات : ".$order->comment;
             }else {
             	$order->comment  ="";
             }
             
             
            
            
             return view('Admin.Orders.printer',compact('order'));
        }
        
         $order->user->address = $order->user->address->address;
        return view('Admin.Orders.order-products',compact('order','payments'));
      }




      public function new_customer(){

      }
      
      
      public function getVariations($id){
          
             $variations="";
        

                $product_attributes = CartAttribute::select('attributes.variation_id','attributes.name_en','attributes.name_ar','cart_attributes.*' )
                                ->leftJoin('attributes','attributes.id','cart_attributes.attribute_id')
                                ->groupBy('cart_attributes.id')
                                ->where('cart_attributes.cart_id',$id)
                                ->get();


                      foreach ($product_attributes as $product_attribute) {
                          
                        if($variations!=""){
                        $variations.="\n\r";
                 		   }

                        $product_attribute->variation_name = Variation::where('id',$product_attribute->variation_id)->first()->name_ar;

                        $variations.=$product_attribute->variation_name." : ".$product_attribute->name_ar;

                      }
                      
                      
                      return $variations;
      }





        public function change_order_status(Request $request)
      {
             $order = Order::where('id',$request->order_id)->first();
             $order->status =  $request->status;
             $order->cancel_reason =  $request->cancel_reason;
             
             
             if( $order->status==5){
                 
                 Cart::where('order_id', $request->order_id )->update(['deleted_at' => NULL]);
                  
             }
             
             $order->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'product deleted successfully'
          ]);
      }
      
      
      public function add_order_tag(Request $request)
      {
             $order = Order::where('id',$request->order_id)->first();
             $order->tags =  $request->tags;
             $order->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'tags added successfully'
          ]);
      }


         public function add_payment(Request $request)
      {
             OrderPayment::create([
                'order_id' => $request->order_id ,
                  'package_id' => $request->package_id ,
                'cost' => $request->paid_amount ,
                 'payment_type' => $request->payment_type , 
            ]);

          return response()->json([
            'status' => 'success',
            'flash_message' => 'payment added successfully'
          ]);
      }
      
      
           public function delete_from_cart(Request $request)
      {
             $ad = Cart::where('id',$request->cart_id)->first();
             $ad->deleted_at =  Carbon::now();
             $ad->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'item deleted successfully'
          ]);
      }

 


    
   


}
