<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\City;
use App\Notification;
use App\Permission;
use App\Position;
use App\UserAddress;
use App\Area;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class NotificationController  extends BaseController
{

    

   public function notifications(Request $request){
            $notifications = Notification::get();
        return view('Admin.Notifications.notifications',compact('notifications'));
      }





      public function add(Request $request){



        if($request->isMethod('get')){
         return view('Admin.Notifications.add-notification');
       }

          $Notification = Notification::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                 'details_en' => $request->details_en ,
                'details_ar' => $request->details_ar ,
                'image' => $request->image,
          
            ]);


        return Redirect::to('/Admin/notifications'); 
      }

 

       public function change_status(Request $request)
      {
             $customer = Notification::where('id',$request->customer_id)->first();
             $customer->status =  ($customer->status==0) ? 1 : 0;
             $customer->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'user deleted successfully'
          ]);
      }

        public function search_customer(Request $request){


          $customer = Notification::where('phone',$request->user_phone)->first();

         
            



          if($customer){
             $customer->address = UserAddress::latest()->where('user_id',$customer->id)->first();

          if($customer->address)
          $customer->address->area = Area::latest()->where('id',$customer->address->area_id)->first();

         return response()->json([
            'status' => 'success',
            'user' => $customer
          ]);
       }

          return response()->json([
            'status' => 'fail',
            
          ]);


      }

 
}
