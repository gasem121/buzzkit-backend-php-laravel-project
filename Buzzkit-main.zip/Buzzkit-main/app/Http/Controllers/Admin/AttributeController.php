<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Attribute;
use App\Variation; 
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class AttributeController  extends BaseController
{

     

      public function attributes(Request $request){



        $attributes = Attribute::where('deleted_at',null)->get();

        foreach ($attributes as $attribute) {
            $attribute->variation_name =  Variation::where('id',$attribute->variation_id)->first()->name_en;
        }


        return view('Admin.Attributes.attributes',compact('attributes'));
      }




      public function add(Request $request){


        if($request->isMethod('get')){

          $variations  = Variation::where('deleted_at',null)->get();

         return view('Admin.Attributes.add-attribute',compact('variations'));
       }
          

          $attribute = Attribute::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                'variation_id' => $request->variation_id ,
                'added_by' => 1 ,
            ]);


        return Redirect::to('/Admin/attributes'); 
      }



      public function edit(Request $request)
      {  


      $attribute = Attribute::where('id',$request->id)->first();


         if($request->isMethod('get')){
            $variations  = Variation::where('deleted_at',null)->get();
           return view('Admin.Attributes.edit-attribute',compact('attribute','variations'));
         }


          $attribute->name_ar = $request->name_ar;
          $attribute->name_en = $request->name_en;
          $attribute->status = $request->status;
          $attribute->variation_id  = $request->variation_id;

          $attribute->save();



           return  Redirect::to('/Admin/attributes');


      }


       public function delete(Request $request)
      {
             $attribute = Attribute::where('id',$request->attribute_id)->first();
             $attribute->deleted_at =  Carbon::now();
             $attribute->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'Attribute deleted successfully'
          ]);
      }


   


}
