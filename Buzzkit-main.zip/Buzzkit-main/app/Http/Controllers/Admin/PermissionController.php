<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Permission;
use App\Role;
use App\Branch;
use App\City;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Schema;

class PermissionController extends BaseController {


      public function permissions(Request $request){
        
        $permissions = Permission::where('deleted_at',null)->get();
        
        return view('Admin.Permissions.permissions',compact('permissions'));
      }


 


      public function add(Request $request){

        if($request->isMethod('get')){

        // $roles = Schema::getColumnListing("roles");
         
         
         
         return view('Admin.Permissions.add-permission');
       }
          

          $permission = Permission::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
            ]);

        
        $added_roles = array();
        $added_roles['permission_id']=$permission->id;
        
        $roles = Schema::getColumnListing("roles");
        
        
        foreach($roles as $role){
            
            if($role!="id"&&$role!="permission_id"){
                $added_roles[$role] = $request[$role];
            }
        
        if($request[$role]!=true){
            $added_roles[$role]=0;
        }else {
             $added_roles[$role]=1;
        }
        
        
        }
        //dd($added_roles);
      Role::create($added_roles);

        return Redirect::to('/Admin/permissions'); 
      }



      public function edit(Request $request)
      {  


      $permission = Permission::where('id',$request->id)->first();
       

         if($request->isMethod('get')){
           $permission->roles = Role::where('permission_id',$permission->id)->first();
              
           return view('Admin.Permissions.edit-permission',compact('permission'));
         }


          $permission->name_ar = $request->name_ar;
          $permission->name_en = $request->name_en;
 
 

          
          $permission->save();


           return  Redirect::to('/Admin/permissions');
      }


       public function delete(Request $request)
      {
             $permission = Permission::where('id',$request->permission_id)->first();
             $permission->deleted_at =  Carbon::now();
             $permission->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'Permission deleted successfully'
          ]);
      }


   


}
