<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Material;
use App\MaterialHistory;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class MaterialController  extends BaseController
{

      public function materials(Request $request){

        $materials = Material::where('deleted_at',null)->get();

        return view('Admin.Materials.materials',compact('materials'));
      
      }




      public function add(Request $request){


        if($request->isMethod('get')){
         return view('Admin.Materials.add-material');
       }
          



          $material = Material::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'status' => $request->status ,
                  'cooking_rate' => $request->cooking_rate ,
                'added_by' => 1 ,
            ]);


        return Redirect::to('/Admin/materials'); 
      }



      public function edit(Request $request)
      {  


      $material = Material::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.Materials.edit-material',compact('material'));
         }


          $material->name_ar = $request->name_ar;
          $material->name_en = $request->name_en;

  
          $material->cooking_rate = $request->cooking_rate;


          $material->status = $request->status;
 

          $material->save();



           return  Redirect::to('/Admin/materials');


      }


        public function edit_history(Request $request)
      {  


        $material = Material::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.Materials.edit-material-history',compact('material'));
         }




          $material->quantity = $material->quantity + $request->quantity;

       

         $material_history = MaterialHistory::create([
                'material_id' => $material->id ,
                'note' => $request->note ,
                'quantity' => $request->quantity ,
                'added_by' => $this->user->id ,
            ]);
      
 

          $material->save();



           return  Redirect::to('/Admin/materials');


      }



       public function delete(Request $request)
      {
             $material = Material::where('id',$request->material_id)->first();
             $material->deleted_at =  Carbon::now();
             $material->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'material deleted successfully'
          ]);
      }


   


}
