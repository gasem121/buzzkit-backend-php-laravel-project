<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Ads;
 
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class AdsController  extends BaseController
{

     
  

      public function ads(Request $request){



        $ads = Ads::where('deleted_at',null)->get();


        return view('Admin.Ads.ads',compact('ads'));
      }




      public function add(Request $request){



        if($request->isMethod('get')){
         return view('Admin.Ads.add-ad');
       }
          



          $Category = Ads::create([
                'title_ar' => $request->name_ar ,
                'title_en' => $request->name_en ,
                'status' => $request->status ,
                'image' => $request->image ,
                   'link' => $request->link ,
 
            ]);


        return Redirect::to('/Admin/ads'); 
      }



      public function edit(Request $request)
      {  


      $ad = Ads::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.Ads.edit-ad',compact('ad'));
         }


          $ad->title_ar = $request->name_ar;
          $ad->title_en = $request->name_en;
          $ad->status = $request->status;
           $ad->link = $request->link;

          if($request->image){
          $ad->image =  $request->image ;
          }

          $ad->save();



           return  Redirect::to('/Admin/ads');


      }


       public function delete(Request $request)
      {
             $ad = Ads::where('id',$request->ad_id)->first();
             $ad->deleted_at =  Carbon::now();
             $ad->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'ad deleted successfully'
          ]);
      }


   


}
