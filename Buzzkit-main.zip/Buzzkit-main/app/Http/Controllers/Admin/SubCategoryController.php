<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Redirect;
use App\Category;
 
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class SubCategoryController  extends BaseController
{
     
     
     
     public function categories(Request $request){
        $categories = Category::where('deleted_at',null)->where('category_id',$request->category_id)->get();
        return view('Admin.SubCategories.categories',compact('categories'));
      }




      public function add(Request $request){
         

        $categories = Category::where('deleted_at',null)->get();
 
        if($request->isMethod('get')){
         return view('Admin.SubCategories.add-category',compact('categories'));
       }
          //dd( $request->category_id);

          $Category = Category::create([
                'name_ar' => $request->name_ar ,
                'name_en' => $request->name_en ,
                'category_id' => $request->category_id ,
                'status' => $request->status ,
                'image' => $request->image ,
                'added_by' => 1 ,
            ]);


        return Redirect::to('/Admin/sub_categories/categories/'.$request->category_id); 
      }



      public function edit(Request $request)
      {  

      $categories = Category::where('deleted_at',null)->get();
     
      $category = Category::where('id',$request->id)->first();


         if($request->isMethod('get')){
           return view('Admin.SubCategories.edit-category',compact('category','categories'));
         }

        dd( $request->category_id);
          $category->name_ar = $request->name_ar;
          $category->name_en = $request->name_en;
          $category->category_id   = $request->category_id;
          $category->status = $request->status;

          if($request->image){
          $category->image =  $request->image ;
          }

          $category->save();

           return  Redirect::to('/Admin/sub_categories/categories/'.$request->category_id);


      }


       public function delete(Request $request)
      {
             $category = Category::where('id',$request->category_id)->first();
             $category->deleted_at =  Carbon::now();
             $category->save();

          return response()->json([
            'status' => 'success',
            'flash_message' => 'category deleted successfully'
          ]);
      }


   


}
