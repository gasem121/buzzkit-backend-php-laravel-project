<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\Product;
use App\Customer;
use App\Ads;
use App\FavouriteProducts;
use App\Category;
use App\Package;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class HomeController extends ApiBaseController
{

      
 
      public function home(Request $request)
      {
          
          
          $result = array();
          
         
              
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

    

          $result['ads'] = Ads::select('id','image','title_'.$request->header('language').' as name','link')->where('status',1)->where('deleted_at',NULL)->get();

          $result['categories'] = Category::select('id','image','name_'.$request->header('language').' as name')->orderBy('position')
          ->where('category_id',0)
          ->where('id','!=',16)
          ->where('id','!=',15)
          ->where('id','!=',17)
          ->where('id','!=',12)->where('status',1)->where('deleted_at',NULL)->get();


          	foreach ($result['categories'] as $category) {
           				
             $category['items']=Product::where('category_id',$category->id)->where('status',1)->where('deleted_at',NULL)->limit(10)->count();
          	}
 
            
            
            $result['offers'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','bulk_price','individual_price','single_quantity')->orderBy('id', 'DESC')->where('status',1)->where(function ($query) {
                     $query->where('category_id', '=', 1)
                    ->orWhere('category_id', '=', 2);
                })->where('deleted_at',NULL)->where('id','!=','1')->get();
                
                
                $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('id','!=','172')->where('status',1)->where('deleted_at',NULL)->orderBy('is_offer', 'DESC')->limit(10)->get();
                
          
         
             if($user){
                 
                  foreach($result['offers'] as $offer){
                $offer->is_fav = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$offer->id)->first()?true:false;
                 }
                 
                foreach($result['products'] as $popular){
                $popular->is_fav = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$popular->id)->first()?true:false;
                 }
                 
                 
                
                 
                 
                  
            
            
            }
           

          return $this->response(200, $result); 


      }
 

      

       


}
