<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\Product;
use App\SocialMedia;
use App\Ads;
use App\AboutUs;
use App\Area;
use App\City;
use App\UserAddress;
use App\Package;
use App\Customer;
use App\Suggestion;
use App\Notification;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class SettingsController extends ApiBaseController
{

        
        public function cities_areas(Request $request){
            
            $cities_areas = City::select('id','name_'.$request->header('language').' as name' )->where('deleted_at',NULL)->get();
            
            
            foreach($cities_areas as $city){
                
                $city->areas = Area::select('id','name_'.$request->header('language').' as name' )->where('city_id',$city->id)->get();
            }
            
             return $this->response(200, $cities_areas); 
        }
 
      public function social_media(Request $request)
      {
          $result = array();


            $result = SocialMedia::select('id','name_'.$request->header('language').' as name','image' ,'link' )->where('status',1)->where('deleted_at',NULL)->get();
 
         
          return $this->response(200, $result); 


      }


      public function about_us(Request $request)
      {
 
          $result = AboutUs::select('id','name_'.$request->header('language').' as name','details_'.$request->header('language').' as details','image' )->first();
         
          return $this->response(200, $result); 


      }
 
 

 public function notifications(Request $request)
      {
          $result = array();

          
 
          $result = Notification::select('id','name_'.$request->header('language').' as name','details_'.$request->header('language').' as details','created_at')->get();
 
         
          return $this->response(200, $result); 


      }


       public function areas(Request $request)
      {
        

          $user = Customer::where('jwt',$request->header('jwt'))->first();
 
          $cities = Area::select('id','delivery_fees','name_'.$request->header('language').' as name' )->where('status',1)->where('deleted_at',NULL)->get();
 
         
          return $this->response(200, $cities); 


      }

       public function addresses(Request $request)
      {

            $user = Customer::where('jwt',$request->header('jwt'))->first();
 
          $addreses = UserAddress::select('id','address','area_id','lat','lng')->where('user_id',$user->id)->get();

          foreach ($addreses as $address) {
             $address['area'] = Area::select('id','delivery_fees','name_'.$request->header('language').' as name' )->where('id',$address->area_id)->first();
          }
        

          return $this->response(200, $addreses); 
      }


   public function add_address(Request $request)
      {

            $user = Customer::where('jwt',$request->header('jwt'))->first();
 
          $addreses =  UserAddress::create([
                'address' => $request->address ,
                'lat' => $request->lat ,
                'lng' => $request->lng ,
                'user_id' => $user->id ,
                'area_id' => $request->area_id,
                
            ]);
 
       $addreses->delivery_fees =  Area::select('delivery_fees' )->where('id',$addreses->area_id)->first()->delivery_fees;

          return $this->response(200, $addreses); 
      }





      public function send_problem(Request $request)
      {
          $result = array();

          
 
             $problem =  Suggestion::create([
                'phone_email' => $request->phone_email ,
                'subject' => $request->subject ,
                'message' => $request->message ,
                'user_name' => $request->user_name ,
       
                
            ]);
 
         
          return $this->response(200, $problem); 


      }

      

       


}
