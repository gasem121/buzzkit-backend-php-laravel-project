<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\Product;
use App\Customer;
use App\Ads;
use App\Category;
use App\Package;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\FavouriteProducts;

use Illuminate\Support\Facades\Crypt;

class ProductOperationsController extends ApiBaseController
{

      
 
      public function products(Request $request)
      {
          $result = array();


 
      
      $user = Customer::where('jwt',$request->header('jwt'))->first();

      if(!$user){
        return $this->response(401, $result); 
      }

          
 
            $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('status',1)->where('deleted_at',NULL)->get();
 
 
    
        
        
             if($user){
                 
                foreach($result['products'] as $product){
                $product->is_fav = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$product->id)->first()?true:false;
                 }
                 
         
            
            
            }
            
            
            
         
          return $this->response(200, $result); 


      }


      public function products_by_category(Request $request)
      {
  

          
 
         $result = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('category_id',$request->category_id)->where('status',1)->where('deleted_at',NULL)->get();
 
         
          return $this->response(200, $result); 


      }


       public function products_and_categories(Request $request)
      {
          $result = array();
          
           
              $user = Customer::where('jwt',$request->header('jwt'))->first();

              if(!$user){
                return $this->response(401, $result); 
                  }

               $result['categories'] = Category::select('id','image','name_'.$request->header('language').' as name')->where('status',1)->where('deleted_at',NULL)->get();

 
         $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')->where('status',1)->where('deleted_at',NULL)->get();
         
         
           if($user){
                 
                foreach($result['products'] as $product){
                $product->is_fav = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$product->id)->first()?true:false;
                 }
                 
         
            
            
            }
            
 
         
          return $this->response(200, $result); 


      }
      
      
      
       public function search_products(Request $request)
      {
          $result = array();
          
           
              $user = Customer::where('jwt',$request->header('jwt'))->first();

             

               $result['categories'] = Category::select('id','image','name_'.$request->header('language').' as name')->where('status',1)->where(function($query) use ($request){
               
                     $query->where('name_ar', 'LIKE', '%'.$request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'. $request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'.$request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'.$request->search_text.'%');
                    
               })->where('deleted_at',NULL)->get();
    
    
 
 
         $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')
               ->where(function($query) use ($request){
               
                     $query->where('name_ar', 'LIKE', '%'.$request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'. $request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'.$request->search_text.'%')
                    ->orWhere('name_en', 'LIKE', '%'.$request->search_text.'%');
                    
               })->where('status',1)->where('deleted_at',NULL)->get();
         
         
           if($user){
                 
                foreach($result['products'] as $product){
                $product->is_fav = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$product->id)->first()?true:false;
                 }
                 
         
            
            
            }
            
 
         
          return $this->response(200, $result); 


      }
 

      

       


}
