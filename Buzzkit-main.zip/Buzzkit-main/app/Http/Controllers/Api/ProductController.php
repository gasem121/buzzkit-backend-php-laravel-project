<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\Product;
use App\Package;
use App\Customer;
use App\Ads;
use App\ProductOffer;
use App\PromoCode;
use App\Category;
use App\ProductAttribute;
use App\FavouriteProducts;
use App\Variation;
use App\Review;
use App\ProductImage;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class ProductController extends ApiBaseController
{

      
 
      public function products(Request $request)
      {
          $result = array();

            $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('status',1)->where('deleted_at',NULL)->get();
 
         
          return $this->response(200, $result); 


      }


      public function products_by_categories(Request $request)
      {
 
         $result = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('category_id',$request->category_id)->where('status',1)->where('deleted_at',NULL)->get();
         
         
          foreach ($result as $product) {

              if($product->price_after>0&&$product->price_before>0)
               $product->off = intval($product->price_before-(($product->price_after/$product->price_before)*100));
             else {
              $product->off=0;
             }
    
              $user = Customer::where('jwt',$request->header('jwt'))->first();

            if($user){
            $product->is_fav = (FavouriteProducts::select('id')
                      ->where('user_id',$user->id)
                      ->where('product_id',$product->id)->first()!=NULL);
            }else {
                  $product->is_fav=false;
            }

            }
            
 
         
          return $this->response(200, $result); 


      }
      
      
      
      public function vouchers(){
          
            $result = PromoCode::select('id','name','code')->where('deleted_at',NULL)->get();
          
           return $this->response(200, $result); 
          
      }
      
    public function products_by_sub_categories(Request $request)
      {
 
               $result = array();
               
         $categories_list = Category::select('id')->where('category_id',$request->category_id)->pluck('id');      
 
         $result['categories'] = Category::select('id','image','name_'.$request->header('language').' as name')->whereIn('id',$categories_list)->orderBy('position')->where('status',1)->where('deleted_at',NULL)->get();
         
         
          if($request->category_id == 25){
            $categories_list = Category::select('id')->where('id',$request->category_id)->pluck('id');  
            $result['categories'] =  Category::select('id','image','name_'.$request->header('language').' as name')->where('id',$request->category_id)->orderBy('position')->where('status',1)->where('deleted_at',NULL)->get();
         }else if($request->category_id == 33){
             
            $categories_list = null;
         }
         
        
         if($request->category_id == 0){
             
             $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')
         ->where('id','!=','1')->orderBy('is_offer', 'DESC')->limit(10)->where('status',1)->where('deleted_at',NULL)->get();
         
           $result['categories'] = null;
         }else if($request->category_id == -2){
             
             $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')
         ->where('id','!=','1')->orderBy('id', 'DESC')->where('status',1)->where(function ($query) {
                     $query->where('category_id', '=', 1)
                    ->orWhere('category_id', '=', 2);
                })->where('deleted_at',NULL)->where('id','!=','1')->get();
         
           $result['categories'] = null;
         }
         else if($request->category_id == 33){
             
         $result['products']   = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')
         ->where('id','!=','1')->where('status',1)->where('deleted_at',NULL)->get();

         }else {
             
              $result['products']   = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')
         ->where('id','!=','1')
         ->whereIn('category_id',$categories_list)->where('status',1)->where('deleted_at',NULL)->get();
             
         }
                
            $user = Customer::where('jwt',$request->header('jwt'))->first();


            foreach ($result['products'] as $product) {

              if($product->price_after>0&&$product->price_before>0)
               $product->off = intval($product->price_before-(($product->price_after/$product->price_before)*100));
             else {
              $product->off=0;
             }


            if($user){
            $product->is_fav = (FavouriteProducts::select('id')
                      ->where('user_id',$user->id)
                      ->where('product_id',$product->id)->first()!=NULL);
            }else {
                  $product->is_fav=false;
            }

            }
 
 
         
          return $this->response(200, $result); 


      }


       public function products_and_categories(Request $request)
      {
          $result = array();

               $result['categories'] = Category::select('id','image','name_'.$request->header('language').' as name')->orderBy('position')->where('status',1)->where('deleted_at',NULL)->get();

 
         $result['products'] = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id')->where('id','!=','1')->where('status',1)->where('deleted_at',NULL)->get();


            $user = Customer::where('jwt',$request->header('jwt'))->first();


            foreach ($result['products'] as $product) {

              if($product->price_after>0&&$product->price_before>0)
               $product->off = intval($product->price_before-(($product->price_after/$product->price_before)*100));
             else {
              $product->off=0;
             }


            if($user){
            $product->is_fav = (FavouriteProducts::select('id')
                      ->where('user_id',$user->id)
                      ->where('product_id',$product->id)->first()!=NULL);
            }else {
                  $product->is_fav=false;
            }

            }


            // foreach ($result['categories'] as $category) {
                  
            //       $category['items']=Product::where('category_id',$category->id)->where('id','!=','1')->where('status',1)->where('deleted_at',NULL)->limit(10)->count();
            // }

 
         
          return $this->response(200, $result); 


      }


        public function product_details(Request $request) {
          $product = $this->get_product($request,1); 
          
          $product->reviews = Review::where('product_id',$product->id)->get();
          
          foreach($product->reviews as $review){
              $review->user = Customer::where('id',$review->user_id)->first();
          }
          
          $product->images = ProductImage::where('product_id',$product->id)->get();
          
          return $this->response(200, $product); 
      }
      
      
      public function offer_products(Request $request) {
          $result = array();
          $lang = $request->header('language');
          $user = Customer::where('jwt',$request->header('jwt'))->first();
          
          
     
          
          $offer_products = ProductOffer::select('id','quantity_in_section', 'offer_items','name_'.$request->header('language').' as name')->where('offer_id',$request->offer_id)->get();
          
          
         
          
          foreach($offer_products as $offer_product){
              
              
              
              
                $offer_product->quantity_in_section = intval($offer_product->quantity_in_section);
                
            
                
               $extra_price = explode(",", $offer_product->extra_price);
               
              $offer_product->products = Product::select('id','image','name_'.$request->header('language').' as name','details_'.$request->header('language').' as details')->WhereIn('id', explode(",", $offer_product->offer_items))->get();
              
              
                 for($i=0; $i<count($offer_product->products); $i++){
                     
                        $product = $offer_product->products[$i];
                    
                       $product->variations = Variation::select('id','name_'.$lang.' as name')->orderBy('id', 'DESC')->get();

                $has_attributes=false;
               foreach($product->variations as $variation){
                            
                            
                         $variation->attributes = ProductAttribute::select('attributes.id','attributes.name_'.$lang.' as name','product_attributes.price' )
                                ->leftJoin('attributes','attributes.id','product_attributes.attribute_id','attributes.value')
                                ->groupBy('product_attributes.id')
                                ->where('product_attributes.product_id',$product->id)
                                  ->where('attributes.variation_id',$variation->id)
                                ->get();
                                
                               if(count($variation->attributes)>0){
                                    $has_attributes=true;
                               } 

                      }
                      
                      
                    $offer_product->products[$i]->has_attributes = $has_attributes;
                    
                    if($offer_product->products[$i]->has_attributes==false){
                       $offer_product->products[$i]->variations=null;
                    }
               
                     
                     
                    
                 }
              
          }
          
          return $this->response(200, $offer_products); 
      }
      
      public function get_product($request,$related){
          
            $result = array();
          $lang = $request->header('language');
          $user = Customer::where('jwt',$request->header('jwt'))->first();
          
           $product = Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after','category_id','bulk_price','individual_price','single_quantity')->where('id',$request->product_id)->where('status',1)->where('deleted_at',NULL)->first();
         
         
       

              $product->variations = Variation::select('id','name_'.$lang.' as name')->orderBy('id', 'DESC')->get();

                
               foreach($product->variations as $variation){
                            
                            
                         $variation->attributes = ProductAttribute::select('attributes.id','attributes.name_'.$lang.' as name','product_attributes.price','attributes.value' )
                                ->leftJoin('attributes','attributes.id','product_attributes.attribute_id')
                                ->groupBy('product_attributes.id')
                                ->where('product_attributes.product_id',$product->id)
                                  ->where('attributes.variation_id',$variation->id)
                                ->get(); 

                      }
            
 
                if($user){
            $product->is_fav = (FavouriteProducts::select('id')
                      ->where('user_id',$user->id)
                      ->where('product_id',$product->id)->first()!=NULL);
                }else {
                   $product->is_fav=false; 
                }

       
    
        if($related==1){
        $product->related_products =  Product::select('id','image','name_'.$request->header('language').' as name' , 'details_'.$request->header('language').' as details','price_before','price_after')->where('status',1)->inRandomOrder()->where('deleted_at',NULL)->where('id','!=','1')->where('id','!=',$request->product_id)->limit(6)->get();
        }
        
        return $product;
      }
 

      

       


}
