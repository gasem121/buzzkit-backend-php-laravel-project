<?php

namespace App\Http\Controllers\Api;


use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use App\Customer;
use App\Cart;
use App\Order;
use App\Product;
use App\OrderProduct;

class HistoryController extends ApiBaseController
{


      public function index()
      {
          $lang = \App::getLocale();
          $AuthMember_id = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
           $history = Order::select('*' ,'type_product_delivery_status as delivery' )
                        ->where('user_id',$AuthMember_id)->orderBy('id','desc')
                        ->limit(25)->latest()->get();
          return view('Site.History.history_list',compact('history') );
      }


      public function orders(Request $request)
      {
        
      $lang = $request->header('language');
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

      if(!$user){
        return $this->response(401, $result); 
      }


         $result = Order::select('id','total_price','status','location_id','rating','comment','created_at')
                         ->where('user_id',$user->id)->get();  //return $order;



          foreach ($result as $order) {
              
              $order->order_no = "981".$order->id;
          	   
          	   $order->items  = Cart::where('order_id',$order->id)->get();


          	   if($order->items->count()>0 && ($order->items[0]->product_id>0)){
          	   $order->image =  Product::where('id',$order->items[0]->product_id)->first()->image;
          	}else {
          		  $order->image = "https://d2ily9edavk8z4.cloudfront.net/uploads/products/customized-meals/1563859593397-Customize.jpg";
          	}
          	
          	            $order->quantity =  $order->items->count();
          	   
          	   $order->items =  $order->items->count();
          	   
          	   
    

          	   if($order->status==1){

          	   	$order->status_text = "Pending";
          	   	$order->color = "#DA7F69";
          	   	
          	   	} else if($order->status==2){
				
				$order->status_text = "Preparing";
				$order->color = "#3DA145";
          	   	
          	   	}else if($order->status==3){

          	   $order->status_text = "On Way";
          	   $order->color = "#3DA145";

          	   	}else if($order->status==4){

          	    $order->status_text = "Shipped";
          	    $order->color = "#3DA145";
          	   		
          	   	}
          	   	else if($order->status==5){
          	   		 $order->color = "#FF0000";
          	   		
          	   	 $order->status_text = "Cancelled";
          	   	}

          }

    

         return $this->response(200, $result); 


      }

      public function cancle_order($order_id)
      {
          $order = Order::where('user_id',auth('Member')->id())->findOrFail($order_id);
          if($order->type_product_delivery_status == 'processing' || $order->type_product_delivery_status == 'canceled')
          {
             $order->update(['type_product_delivery_status' => 'canceled' ]);
                return response()->json([
                 'status' => 'success',
                 'delivery' => $order->type_product_delivery_status,
                 'flash_message' => 'Order has cancled'
               ]);
          }
          else
          {
                return response()->json([
                 'status' => 'cant cancle',
                 'delivery' => $order->type_product_delivery_status,
                 'flash_message' => 'sorry cant cancle the order now'
               ]);
          }
      }


}
