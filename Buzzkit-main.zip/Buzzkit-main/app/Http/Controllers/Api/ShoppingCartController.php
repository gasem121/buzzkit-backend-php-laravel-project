<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use App\Order;
use App\Customer;
use App\Member;
use App\ShoppingCart;
use App\Product;
use App\Package;
use App\Variation;
use App\ProductAttribute;
use App\Attribute;
use App\CartAttribute;
use App\UserPackage;
use App\ProductMaterial;
use App\Material;
use App\Offer;
use App\PromoCode;
use App\UserAddress;
use App\Area;
use App\OrderPayment;
use App\User;
use App\Cart;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class ShoppingCartController extends ApiBaseController
{
    

            public function cart(Request $request){

    //   $lang = $request->header('language');
    //   $result = null;
    //   $user = Customer::where('jwt',$request->header('jwt'))->first();


    //       $products = Cart::select('carts.id','carts.product_id','carts.quantity','products.image','products.price_before','products.price_after','products.name_'.$lang.' as name','image' )
    //                             ->leftJoin('products','products.id','carts.product_id')
    //                             ->groupBy('carts.id')
    //                             ->where('carts.user_id',$user->id)
    //                              ->where('carts.order_id',0)
    //                             ->limit(80)
    //                             ->get();

  
    //     foreach ($products as $product) {
         

    //         $product->total_price = $product->quantity*$product->price_after;
            
    //         $product->quantity = intval($product->quantity);
            
    //         $product->price_after = doubleval($product->price_after);
            
    //         $product->price_before = doubleval($product->price_before);
 
    //             $product_attributes = CartAttribute::select('attributes.variation_id','attributes.name_'.$lang.' as name' )
    //                             ->leftJoin('attributes','attributes.id','cart_attributes.attribute_id')
    //                             ->groupBy('cart_attributes.id')
    //                             ->where('cart_attributes.cart_id',$product->id)
    //                             ->get();


    //                   foreach ($product_attributes as $product_attribute) {
    //                     $product_attribute->variation_name = Variation::select('name_'.$lang.' as name')->where('id',$product_attribute->variation_id)->first()->name;
    //                   }
      
  

    //           $product->product_attributes =  $product_attributes;
    //       }  
        
        
    //     $payments = OrderPayment::where('order_id',$request->order_id)->get();


    //     return $this->response(200, $products);
    
    
       $lang = $request->header('language');
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

    $final_products=array();
          $products = Cart::select('carts.id','carts.product_id','carts.quantity','carts.custom_meal','products.image','products.price_before','products.price_after','products.name_'.$lang.' as name','image' )
                                ->leftJoin('products','products.id','carts.product_id')
                                ->groupBy('carts.id')
                                ->where('carts.user_id',$user->id)
                                 ->where('carts.order_id',0)
                                ->limit(80)
                                ->get();

        $all_price =0;
        foreach ($products as $product) {
         

            $product->total_price = $product->quantity*$product->price_after;

            
                $product->custom_meal = null;
                
                
                $product_attributes = CartAttribute::select('cart_attributes.attribute_id','attributes.variation_id','attributes.name_'.$lang.' as name','cart_attributes.*' )
                                ->leftJoin('attributes','attributes.id','cart_attributes.attribute_id')
                                ->groupBy('cart_attributes.id')
                                ->where('cart_attributes.cart_id',$product->id)
                                ->get();

                $total_price_temps=0;
                      foreach ($product_attributes as $product_attribute) {
                          
                        $product_attribute->variation_name = Variation::select('name_'.$lang.' as name')->where('id',$product_attribute->variation_id)->first()->name;
                            
                        $product_attribute->price = ProductAttribute::select('price')->where('attribute_id',$product_attribute->attribute_id)->first()->price;    
                            
                        $total_price_temps+=$product_attribute->price;
                        
                      }
                      
                           $product->price_after +=  $total_price_temps;
                           $product->total_price = $product->quantity*$product->price_after;
      
  
                  $all_price+= $product->total_price;
               $product->product_attributes =  $product_attributes;
          } 
          
          
          foreach ($products as $product) {
           
                 array_push($final_products,$product);
             }
             
            
                 $offers = Offer::select('product_id')->where('offer_price','>',0)->where('offer_price','<=',$all_price)->pluck('product_id');
                 $offer_price_products = Product::select('id as product_id' ,'image','price_before','price_after','name_'.$lang.' as name','image')->whereIn('id', $offers )->get() ;
                   
 
                // dd($offers);
                   
               foreach ($offer_price_products as $temp_product) {
                  
                  $temp_product->id=0;
                    $temp_product->quantity=1;
                    $temp_product->custom_meal=null;
                    $temp_product->price_after=0;
                    
                    $temp_product->total_price=$temp_product->price_after;
                    $temp_product->product_attributes = [];
                    
                 array_push($final_products,$temp_product);
                 
                 }
             
             
          $offers = Offer::where('offer_price',0)->get();
          
          
          foreach($offers as $offer){
              
                $foundCounter=0;
              
               $offers_items = explode(",", $offer->how_to_get);
               $offers_items_quantity = explode(",", $offer->how_got_quantity);
               
              for($i=0; $i<count($offers_items); $i++){
                    
                    $quantityCount=0;
                foreach ($products as $product) {
                    
                    if($offers_items[$i]==$product->product_id){
                            
                            $quantityCount+=$product->quantity;
                        }
                        
                    }
                      // dd($offers_items_quantity[$i]);
                    
                  
                    if($quantityCount>=$offers_items_quantity[$i]){
                        $foundCounter++;
                    }
                    
                }
                
             
                if($foundCounter==count($offers_items)){
                    
                    $temp_product = Product::select('id as product_id' ,'image','price_before','price_after','name_'.$lang.' as name','image')->where('id',$offer->product_id)->first();
                    $temp_product->id=0;
                    $temp_product->quantity=1;
                    $temp_product->custom_meal=null;
                    $temp_product->price_after=0;
                    $temp_product->total_price=$temp_product->price_after;
                    $temp_product->product_attributes = [];
                     
                    
                   array_push($final_products,$temp_product);
                }
               
               
               
          }
       
        
              
        
     foreach($final_products as $temp_product){
            $temp_product->total_price=doubleval($temp_product->total_price);
             $temp_product->quantity=intval($temp_product->quantity);
             $temp_product->product_id=intval($temp_product->product_id);
               $temp_product->price_before=doubleval($temp_product->price_before);
                  $temp_product->price_after=doubleval($temp_product->price_after);
     }


        return $this->response(200, $final_products); 
        
        

    
      }

    public function add_to_cart(Request $request)
    {


      $lang = $request->header('language');
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

      if(!$user){
        return $this->response(401, $result); 
      }


         $ShoppingCarts = Cart::where('user_id',$user->id)->where('order_id',0)->where('product_id',$request->product_id)->get();
       

         


          foreach ($ShoppingCarts as $ShoppingCart) {
 
         
               if($ShoppingCart){

                  $found =false;
                  $counter=0;

                 $cart_atts =  CartAttribute::where('cart_id',$ShoppingCart->id)->get();

                

                     if($request->attriuties){

                      if(count($request->attriuties)==count($cart_atts)){


                       
                       foreach ($cart_atts as $attr) {

                           if(in_array($attr->attribute_id, $request->attriuties)){
                           $counter++;
                            }
                       }

                   }else {
                    continue;
                   }

                  }

 

                  if(($cart_atts==null&&$request->attriuties==null)||(count($cart_atts)==$counter)){
                      
                      $ShoppingCart->update([ 'quantity' => $request->quantity??1 + $ShoppingCart->quantity]);
                       return $this->response(200, $result); 
                       
                      }
                  
 
              }

            }

              $ShoppingCart = Cart::create([
                          'user_id' => $user->id,
                          'product_id' => $request->product_id,
                          'quantity' => $request->quantity??1,
                    ]);

                       if($request->attriuties){

                  foreach ($request->attriuties as $attriutie) {
                  
               CartAttribute::create([
                          'cart_id' => $ShoppingCart->id,
                          'attribute_id' => $attriutie,
                           
                    ]);
                }


               }



                 return $this->response(200, $result); 
        

    
      }


  public function add_custom_meal_to_cart(Request $request)
    {


      $lang = $request->header('language');
      $result = null;
      $custom_meal="";
      $total=0.0;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

      if(!$user){
        return $this->response(401, $result); 
      }
      
 
         $ShoppingCart = Cart::create([
                          'user_id' => $user->id,
                          'product_id' => $request->offer_id,
                          'custom_meal'=>$request->offer_items,
                          'price'=>$request->price,
                          'quantity' => 1,
                    ]);
 



                 return $this->response(200, $result); 
        

    
      }



  public function calculate_custom_meal(Request $request)
    {


      $lang = $request->header('language');
      $result = null;
      $custom_meal="";
      $total=0.0;
 

     


        if($request->chicken){
         $custom_meal .= 'Chicken : '.$request->chicken.' Grams \n';
         $total+=$request->chicken*0.5;
        }

        if($request->meat){
         $custom_meal .= 'Meat : '.$request->meat.' Grams \n';
         $total+=$request->meat*0.5;
        }

        if($request->meat_mafrroom){
         $custom_meal .= 'Mafroom Meat : '.$request->meat_mafrroom.' Grams \n';
         $total+=$request->meat_mafrroom*0.5;
        }


        if($request->fish){
         $custom_meal .= 'Fish : '.$request->fish.' Grams \n';
         $total+=$request->fish*0.5;
        }


        if($request->salamon){
         $custom_meal .= 'Salamon : '.$request->salamon.' Grams \n';
         $total+=$request->salamon*0.5;
        }


        if($request->shrimp){
         $custom_meal .= 'Shrimp : '.$request->shrimp.' Grams \n';
         $total+=$request->shrimp*0.5;
        }


         if($request->carp){
         $custom_meal .= 'Carp : '.$request->carp.' Grams \n';
         $total+=$request->carp*0.5;
        }


        if($request->vegetables){
         $custom_meal .= 'Vegetables : '.$request->vegetables.' Grams \n';
         $total+=$request->vegetables*0.5;
        }




         $custom_meal .= 'Total Price : '.$total.' EGP \n';
 
        
         return $this->response(200, $custom_meal); 
        

    
      }



       public function increase_cart(Request $request){

 
        $ShoppingCart = Cart::where('id',$request->cart_id)->first();

        
       $ShoppingCart->update([ 'quantity' => 1+$ShoppingCart->quantity ]);
        

        return $this->response(200, null); 

      }


         public function decrease_cart(Request $request){
        $ShoppingCart = Cart::where('id',$request->cart_id)->first();

        if($ShoppingCart->quantity>1)
       $ShoppingCart->update([ 'quantity' => $ShoppingCart->quantity-1 ]);
        

          return $this->response(200, null); 

      }


      public function remove_from_cart(Request $request)
      {

        $lang = $request->header('language');
 
        $user = Customer::where('jwt',$request->header('jwt'))->first();

      
      	if(!$user){
     	   return $this->response(401, null); 
     	 }

        
        Cart::where('user_id',$user->id)->where('id',$request->cart_id)->delete();
           

           return $this->response(200, null); 

      }

       public function book_package(Request $request)
      {

        $lang = $request->header('language');
 
        $user = Customer::where('jwt',$request->header('jwt'))->first();

      
        if(!$user){
         return $this->response(401, null); 
       }

      $package =  Package::where('id',$request->package_id)->first();
 

        
      UserPackage::create([
               'user_id' => $user->id,
                'package_id' => $request->package_id,
                  'total_price' => $package->price_after,
            ]);
           

           return $this->response(200, null); 

      }


      


      public function confirm_order(Request $request)
      {
          
          
         
         
          $curl = curl_init();
            
            $data = array();
            $url = "https://khazenly4--devcom.sandbox.my.site.com/services/apexrest/api/CreateOrder";
            
            $customer_name = "Mohamed";
            $phone = "01121333333";
            $customer_id = "100003";
            $address = "Sample detailed address for customer, 123 st.";
            $country = "Egypt";
            $city = "Giza";
            $order_number = "10000001";
            $order_amount = 645;
            $shipping_fee = 45;
            $total_order = $order_amount+$shipping_fee;
            $discount = 0;
            
            $line_items = array();
            $sku = "CB111";
            $price = 600;
            $item_id = "3394";
            $item_name = "Hoddie";
            $single_quantity = 1;
            
            
            
          $single_item =  [
            "SKU" => $sku,
            "Price" => $price,
            "ItemId" => $item_id,
            "ItemName" => $item_name,
            "Quantity" => $single_quantity,
            "DiscountAmount" => null,
             ];
             
            array_push($line_items,$single_item); 
            
            
            
 
            $data = [
              "Order" => [
                "weight" => 1,
                "orderId" => $order_number,
                "storeName" => "https://kogear.shop",
                "taxAmount" => 0,
                "orderNumber" => $order_number,
                "totalAmount" => $order_amount,
                "shippingFees" => $shipping_fee,
                "paymentMethod" => "Cash-on-Delivery",
                "paymentStatus" => "pending",
                "storeCurrency" => "EGP",
                "discountAmount" => $discount,
                "invoiceTotalAmount" => $total_order,
                ],
                "Customer" => [
                    "Tel" => $phone,
                    "secondaryTel" => $phone,
                    "City" => $city,
                    "Country" => $country,
                    "Address1" => $address,
                    "customerName" => $customer_name,
                    "customerId" => $customer_id,
                ],
                    "lineItems" => $line_items,
                ];


    
    
            
            
            $postdata = json_encode($data);

$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

  $token = "00D4L000000Fua7!AQEAQFSix1G.7B.c2sFpvUkkEXZ1YgLFDbZJMvpKifzsxb3Nq_IaudoFTK7y6MfKcdYMkCeue4VM4MrtJ4szS3KCyg1X_xl6";
        
                
                // Returns the data/output as a string instead of raw data
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

//Set your auth headers
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  'Content-Type: application/json',
  'Authorization: Bearer ' . $token
  ));
                 

  $result = curl_exec($ch);

             curl_close($ch);
   
           $lang = $request->header('language');
 
        $user = Customer::where('jwt',$request->header('jwt'))->first();

      
      	if(!$user){
     	   return $this->response(401, null); 
     	 }


          $order = Order::create([
               'user_id' => $user->id,
                'location_id' => $request->location_id,
                  'total_price' => $request->total_price,
            ]);


          $cart = Cart::where( 'user_id',$user->id)->where('order_id',0)->update(['order_id'=>$order->id]);
 


          	 return $this->response(200, null); 



      }


      public function get_Count_number()
      {
          return ShoppingCart::where( 'user_id',$AuthMember_id)->count();
      }


      function sendPayment($apiURL, $apiKey, $postFields) {

    $json = $this->callAPI("$apiURL/v2/SendPayment", $apiKey, $postFields);
    return $json->Data;
}


    public function check_promo_code(Request $request){
            
             $lang = $request->header('language');
 
        $user = Customer::where('jwt',$request->header('jwt'))->first();
        
        $promo_code = PromoCode::where('code',$request->promo_code)->where('status',1)->first();
        
        if(!$promo_code){
     	   return $this->response(401, null,"Sorry wrong promo code"); 
     	 }
     	 
     	  return $this->response(200, $promo_code); 
            
    }
      

//------------------------------------------------------------------------------
/*
 * Call API Endpoint Function
 */

function callAPI($endpointURL, $apiKey, $postFields = [], $requestType = 'POST') {

    $curl = curl_init($endpointURL);
    curl_setopt_array($curl, array(
        CURLOPT_CUSTOMREQUEST  => $requestType,
        CURLOPT_POSTFIELDS     => json_encode($postFields),
        CURLOPT_HTTPHEADER     => array("Authorization: Bearer $apiKey", 'Content-Type: application/json'),
        CURLOPT_RETURNTRANSFER => true,
    ));

    $response = curl_exec($curl);
    $curlErr  = curl_error($curl);

    curl_close($curl);

    if ($curlErr) {
        //Curl is not working in your server
        die("Curl Error: $curlErr");
    }

    $error = $this->handleError($response);
    if ($error) {
        die("Error: $error");
    }

    return json_decode($response);
}

//------------------------------------------------------------------------------
/*
 * Handle Endpoint Errors Function
 */

function handleError($response) {

    $json = json_decode($response);
    if (isset($json->IsSuccess) && $json->IsSuccess == true) {
        return null;
    }

    //Check for the errors
    if (isset($json->ValidationErrors) || isset($json->FieldsErrors)) {
        $errorsObj = isset($json->ValidationErrors) ? $json->ValidationErrors : $json->FieldsErrors;
        $blogDatas = array_column($errorsObj, 'Error', 'Name');

        $error = implode(', ', array_map(function ($k, $v) {
                    return "$k: $v";
                }, array_keys($blogDatas), array_values($blogDatas)));
    } else if (isset($json->Data->ErrorMessage)) {
        $error = $json->Data->ErrorMessage;
    }

    if (empty($error)) {
        $error = (isset($json->Message)) ? $json->Message : (!empty($response) ? $response : 'API key or API URL is not correct');
    }

    return $error;
}



}
