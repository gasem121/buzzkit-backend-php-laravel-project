<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use App\Product;
use App\Customer;
use App\FavouriteProducts;
use App\BrandofProducts;

class WishListController extends ApiBaseController
{
    public function __construct()
    {
       //$this->middleware('auth:Member');
    }

   public function favourites(Request $request)
   {

      $lang = $request->header('language');
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();


           if($user){
               
           $result =  FavouriteProducts::select('products.id as id','products.price_after','products.price_before',
                            "products.details_$lang as details","products.name_$lang as name",'products.id as product_id',
                            'products.image as image',
                            \DB::raw("true as is_fav") 
                      )
                      ->join('products','products.id','favourites_products.product_id')
                      ->groupBy('favourites_products.id')
                      ->where('favourites_products.user_id',$user->id)
                      ->get();


                       foreach ($result as $product) {
                           
                           $product->price_after = doubleval($product->price_after);
                           
                           $product->id = intval($product->id);
                           
                           $product->price_before = doubleval($product->price_before);

              if($product->price_after>0&&$product->price_before>0)
               $product->off = intval($product->price_before-(($product->price_after/$product->price_before)*100));
             else {
              $product->off=0;
             }



            $product->is_fav = true;

            }



        }


       return $this->response(200, $result); 

   }

 

    public function add_remove_favourites(Request $request)
    {

       $lang = $request->header('language');
      $result = null;
      $user = Customer::where('jwt',$request->header('jwt'))->first();

      if(!$user){
        return $this->response(401, $result); 
      }



      $product_id=$request->product_id;

          $WishList = FavouriteProducts::where( 'user_id',$user->id )->where('product_id',$product_id)->first();

          if($WishList)
          {
              $WishList->delete();
              
              return $this->response(200, $result); 
          }
          else
          {
              FavouriteProducts::create([
                'user_id' => $user->id,
                'product_id' => $product_id
              ]);

            return $this->response(200, $result); 
          }
    }

}
