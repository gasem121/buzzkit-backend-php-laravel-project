<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\ApiBaseController;
use Redirect;
use App\City;
use App\Customer;
use App\Permission;
use App\Position;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class AuthController extends ApiBaseController
{

      
 
      public function login(Request $request)
      {
          
         // dd($request->phone);
      
          $customer = Customer::select('id','jwt','name','phone','email','image')->where('phone',$request->phone)->where('password',md5($request->password))->first();


           if(!$customer){
           return $this->response(401, null,"Sorry account not found"); 
          }

          return $this->response(200, $customer); 


      }
      
      
          public function forgot_password(Request $request)
      {
      
          $customer = Customer::select('id','name')->where('email',$request->email)->first();


           if(!$customer){
            return $this->response(401, null,"Sorry email not found"); 
          }
          
            $to = $request->email;
            $subject = "Change Password Link";
            $txt = "Hello : ".$customer->name." \n Please follow this link to change your password "."www.bunnbun.com/recover_passwword";
            $headers = "From: no_reply@bunnbun.com";

        mail($to,$subject,$txt,$headers);

        
          return $this->response(200, null,"Please check your email"); 


      }

      public function register(Request $request){

          $is_phone_found = Customer::where('phone',$request->phone)->first();

          if($is_phone_found){
         return $this->response(401, null,"Sorry this phone is used before"); 
          }


          $is_email_found = Customer::where('email',$request->email)->first();

          if($is_email_found){
            return $this->response(401, null,"Sorry this email is used before"); 
          }


        $customer =  Customer::create([
                'name' => $request->name ,
                'phone' => $request->phone ,
                'email' => $request->email ,
                'image' => $request->image ,
                 'jwt' => Crypt::encryptString(md5($request->phone)),
                'password' => md5($request->password),
                
            ]);


    $customer = Customer::select('id','jwt','name','phone','email','image')->where('id',$customer->id)->first();

 

         return $this->response(200, $customer); 
      }

      
         public function update_profile(Request $request){

          $is_phone_found = Customer::where('phone',$request->phone)->first();

          if($is_phone_found){
            return $this->response(401, null,"Sorry phone not found"); 
          }


          $is_email_found = Customer::where('email',$request->email)->first();

          if($is_email_found){
           return $this->response(401, null,"Sorry email not found"); 
          }


        $customer =  Customer::create([
                'name' => $request->name ,
                'phone' => $request->phone ,
                'email' => $request->email ,
                'image' => $request->image ,
                 'jwt' => Crypt::encryptString(md5($request->phone)),
                'password' => md5($request->password),
                
            ]);


    $customer = Customer::select('id','jwt','name','phone','email','image')->where('id',$customer->id)->first();

 

         return $this->response(200, $customer); 
      }

       


}
