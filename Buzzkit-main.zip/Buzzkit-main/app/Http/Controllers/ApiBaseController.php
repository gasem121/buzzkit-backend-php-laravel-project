<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use App\City;
use App\Customer;
use App\Permission;
use App\Position;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;

class ApiBaseController extends Controller
{
    


	public function response($code , $data = null , $message = "" , $language="" ){
		return response()->json(['status' => $code, 'message'=>$message , 'data' => $data]); 
	}

}
