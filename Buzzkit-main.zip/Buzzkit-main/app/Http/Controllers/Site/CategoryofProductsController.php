<?php

namespace App\Http\Controllers\Site;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\SubCategoryofProducts;
use App\Product; 
use App\NewItem; 
use App\SpecName;
use App\SpecValue;


class CategoryofProductsController extends BaseController
{
      public function index($id)
      { 

           $returned_details = $this->init();

           $specs = SpecName::select("id",'name_'.$this->lang.' as name' )->where('category_of_product_id',$id)->get();

          for($ii=0; $ii<count($specs); $ii++){
              $specs[$ii]['values'] = SpecValue::select("id",'name_'.$this->lang.' as name')->where('spec_name_id',$specs[$ii]->id)->get();
            }

           $products_by_category = Product::select("id",'price_before','price_after','title_'.$this->lang.' as title','image')->get();

           $sub_categories = SubCategoryofProducts::select("id",'name_'.$this->lang.' as title','image')->where('category_of_product_id',$id)->get();

                //dd($sub_categories);
         return view('Site.Categories',$returned_details,compact('sub_categories','specs','products_by_category'));
      }

      public function get_list()
      {
          $lang = \App::getLocale();
          return CategoryofProducts::select('id',"name_$lang as name" ,'image' )
             ->where('status',1)
             ->orderBy('position')
             ->paginate(25);
      }


}
