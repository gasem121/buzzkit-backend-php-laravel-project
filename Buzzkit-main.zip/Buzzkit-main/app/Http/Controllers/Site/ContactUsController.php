<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\ContactUs;
use App\PagesBanner;

class ContactUsController extends BaseController
{
      public function index()
      {
         

          $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;

          
            $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;

          $Banner = PagesBanner::select("imageen as image","title_$lang as title","body_$lang as body")
                                  ->where('page','contact')->first();

          return view('Site.ContactUs',$returned_details,compact('Banner','navActive','user' )  );
      }

      public function store(Request $request)
      {
            $validator = \Validator::make($request->all(),[
                'name' => 'required',
                'phone' => 'required',
                'email' => 'required',
                'message' => 'required',
            ]);

          if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }

          return response()->json([
            'status' => 'success',
            'flash_message' => __('page.contactus_flash_message')
          ]);

      }
}
