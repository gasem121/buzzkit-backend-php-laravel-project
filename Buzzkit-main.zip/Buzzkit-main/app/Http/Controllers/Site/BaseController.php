<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use App\Member;
use App\Setting;
use App\Ads;
use App\Category;
 
use App\FavouriteProducts;
use App\Cart;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
 use Illuminate\Support\Facades\Session;  

class BaseController extends Controller {


     public $all_categories ,$user,$lang,$ads,$brands,$categories;


        public function init() {
            
          
          \App::setLocale(Session::get('current_language',"en"));

         $this->user = $user = Session::get('member_id');

 
          $lang = \App::getLocale();
          $this->lang=$lang;
          
          $settings = Setting::select("id",'title','value')->get();
        
          $main_settings =  array();



          foreach($settings as $item){


             if($lang=="en"&&$item['title']=="about_title_en"){
                $main_settings['about_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="about_details_en"){
                $main_settings['about_details']=$item['value'];
              }

              
               if($item['title']=="phone"){
                $main_settings['phone']=$item['value'];
              }


              if($item['title']=="facebook"){
                $main_settings['facebook']=$item['value'];
              }

              if($item['title']=="instagram"){
                $main_settings['instagram']=$item['value'];
              }


              if($item['title']=="twitter"){
                $main_settings['twitter']=$item['value'];
              }

              if($item['title']=="youtube"){
                $main_settings['youtube']=$item['value'];
              }
              
                if($lang=="ar"&&$item['title']=="fotter_description_ar"){
                $main_settings['fotter_description']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="fotter_description_en"){
                $main_settings['fotter_description']=$item['value'];
              }
              
              if($item['title']=="logo"){
               
                  $main_settings['logo']=asset('public/images/Settings/'.$item['value']);
              }

              
          }


          $cart_count =   Cart::where('order_id',0)->where( 'user_id',$user )->count();

          $fav_count =   FavouriteProducts::where( 'user_id',$user)->count();
      
          
          //$brands = Brand::select("id",'name_'.$lang.' as title','image')->where('status','1')->where('deleted_at',NULL)->get();
         
          $ads = Ads::select("id",'title_'.$lang.' as title','details_'.$lang.' as details','image','link')->where('deleted_at',NULL)->where('status','1')->get();
       
          $categories = Category::select("id",'name_'.$lang.' as title','image')->where('id',1)->Orwhere('id',2)->Orwhere('id',35)->Orwhere('id',4)->Orwhere('id',5)->Orwhere('id',10)->orderBy('position')->get();
     
     
            $ko = Category::select("id",'name_'.$lang.' as title','image')->where('status','1')->where('category_id',24)->where('deleted_at',NULL)->get();
            
             $specials = Category::select("id",'name_'.$lang.' as title','image')->where('status','1')->where('category_id',27)->where('deleted_at',NULL)->get();
             
             
              $shop_all = Category::select("id",'name_'.$lang.' as title','image')->where('status','1')->where('deleted_at',NULL)->get();

            $index=0;
          return compact('main_settings','ads','categories','user','cart_count','fav_count','index','lang','ko','specials','shop_all');

     
        }

  }
