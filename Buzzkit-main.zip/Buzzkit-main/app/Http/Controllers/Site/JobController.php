<?php

namespace App\Http\Controllers\Site;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Job;
use App\AppliedUsers;
use App\Certification;
use App\ProductFile;
use App\CategoryofProducts;
use App\BrandofProducts;
use App\VendorsProductNotificationsFromAdmin;

class JobController extends Controller
{
    
       

    public function index()
    {
    	 $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
        $lang = \App::getLocale();
          $jobs = Job::select("id",'title_'.$lang.' as title','description_'.$lang.' as description','image')->where('status','1')->get();
		 $_un=103;
          //dd($jobs[0]['image']);

         return view('Site.jobs',compact('jobs','user','_un'));
    }


    public function fileUpload()

    {

        return view('fileUpload');

    }



    public function fileUploadPost(Request $request)

    {

        $request->validate([

            'file' => 'required',
             'job_id' => 'required',

        ]);


        // dd($request->job_id);
  

        $fileName = time().'.'.$request->file->extension();  

        $request->file->move(public_path('uploads'), $fileName);

        $request->cv=$fileName;


       

        $request->request->add(['cv' => $fileName]);
         AppliedUsers::create(request(['job_id', 'cv']));


        return back()

            ->with('success','You have successfully upload file.')

            ->with('file',$fileName);

   

    }

   

 

    

    

}
