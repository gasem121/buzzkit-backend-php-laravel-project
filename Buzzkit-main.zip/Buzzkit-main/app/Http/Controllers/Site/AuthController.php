<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use App\City;
use App\Member;
use App\Customer;
use App\User;
use App\MemberAddress;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;



class AuthController extends BaseController
{


 
    
    
      public function __construct()
      {


         // $this->middleware('guest:Member')->except('logout','edit','update','add_new_address' );
         // $this->middleware('auth:Member')->only('edit','update','change_password_page','change_password_action' );
         $this->middleware('guest:Member')->only('check_register_validation','check_login_validation','register','login' );
         $this->middleware('auth:Member')->only('edit','update','add_new_address','change_password_page','change_password_action' );
      }

      //--api--
      public function check_register_validation(Request $request)
      {   
           dd("teest");
          $validator = \Validator::make($request->all(),[
              'city_id' => 'required',
              'name' => 'required',
              'email' => 'required|unique:users',
              'password' => 'required',
              'phone' => 'required',
          ]);

          if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }
          return response()->json([
            'status' => 'success',
          ]);
      }

      //--api--
      public function check_login_validation(Request $request)
      {
          $validator = \Validator::make($request->all(),[
              'email' => 'required',
              'password' => 'required',
          ]);

          if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }

          $Member = Customer::where('email',$request->email)->where('password',md5($request->password))->first();
          if(!$Member)
          {
              return response()->json([
                'status' => 'faild',
                'flash_message' => __('page.check_login_validation_faild')
             ]);
          }

          return response()->json([
            'status' => 'success',
          ]);
      }

      public function register(Request $request)
      {

            $Member = Customer::create([
                'name' => $request->name ,
                'email' => $request->email ,
                'password' => md5($request->password) ,
                'phone' => str_replace(' ', '', $request->phone) ,
                'city_id' => $request->city_id ,
            ]);
            auth()->guard('Member')->loginUsingId($Member->id, true);
             return view('Site.sign_up');
      }

      public function login(Request $request)
      {
          $data = $request->validate([
              'email' => 'required',
              'password' => 'required',
          ]);

          $Member = Customer::where('email',$request->email)->where('password',md5($request->password))->first();

  

          if( $Member )
          {
                auth()->guard('Member')->loginUsingId($Member->id, true);
                return back();
          }
          else
          {
               \Session::flash('flash_message','the email or password is wrong');
               return back()->withInput($request->only('username','remember') );
          }
      }

      public function logout()
      {
          if(auth()->guard('Member')->check())
              auth()->guard('Member')->logout();
          return back();
      }

      public function edit()
      {
          $member = auth('Member')->user();

          return view('Site.profile',compact('member'));
      }

      public function update(Request $request)
      {
           $validator = \Validator::make($request->all(),[
              'name' => 'required',
              'email' => 'required|unique:users,email,'.auth()->guard('Member')->id(),
              'phone' => 'required',
              'city_id' => 'required',
           ]);
           if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }

           $member_data = [
               'name' => $request->name ,
               'email' => $request->email ,
               'phone' => $request->phone ,
               'city_id' => $request->city_id ,
           ];

          $Member = auth()->guard('Member')->user()->update($member_data);

          return response()->json([
            'status' => 'success',
            'flash_message' => 'profile has updated'
          ]);
      }
      

    public function send_forget_password_email(Request $request)
    {   
        
        
        
          $data = $request->validate([
              'email' => 'required',
          ]);
          
            

          $Member = Customer::where('email',$request->email)->first();
          
          
          $random_number=$Member->id."".rand (1111,9999);
          
          if($Member)
          {
             $Member->update([
                    'forgetpass_code' => $random_number ,
                    'forgetpass_code_date' => Carbon::now()
                  ]);
        
        
                
        $to = $request->email;
        $subject = 'New Request';
        $message = "please follow this link to reset your password "."http://kogear.shop/member/resite_password_form/".$random_number;
    
        $from="info@kogear.shop";
    
        $headers = "From:$from \r\n";
        $headers .= "Cc:$from \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html\r\n";

                 mail($to, $subject, $message, $headers);
                 
            
          }else {
              
               return Redirect::back()->with('alert_error', "This email not registered before");
          }

         return Redirect::back()->with('alert', "Forgot password details has been sent to your email");
           
    }
    
    
  
    
    
     public function change_password(Request $request)
    {
         
            $forgetpass_code = $request->forgetpass_code;
          
          if($request->password!=$request->confirm_password){
                return Redirect::back()->with('alert_error', "Passwords not matches");
              
          }
          
            //     ->where('forgetpass_code_date', '>', Carbon::now()->subMinutes(30)->toDateTimeString())
            //   ->orderBy('forgetpass_code_date', 'desc')->latest()
              
                  $Member = Customer::where('forgetpass_code',$forgetpass_code)
        ->first();
              
          if(!$Member){
              
                return Redirect::back()->with('alert_error', "Sorry Expired");
                
          }else {
              
              $Member->password=md5($request->password);
              $Member->save();
                return Redirect::back()->with('alert', "Password has been changed successfully");
          }
          
    }
    
    
    public function change_password_form($forgetpass_code)
    {
        
        
             $returned_details = $this->init();

                  $Member = Customer::where('forgetpass_code',$forgetpass_code)
              ->first();
              
            //   ->where('forgetpass_code_date', '>', Carbon::now()->subMinutes(30)->toDateTimeString())
            //   ->orderBy('forgetpass_code_date', 'desc')->latest()
              
          if(!$Member){
              
                return 'expired';
                
          }
          
         
         return view('Site.layouts.reset_password',$returned_details,compact('forgetpass_code')  ); 
          
    }
    
    
    
     public function resite_password_form()
    {
             $returned_details = $this->init();
        return view('Site.layouts.forgot_password',$returned_details);
    }

    public function reset_password(Request $request)
    {
          $data = $request->validate([
            'forgetpass_code' => 'required',
            'password' => 'required',
          ]);

          $Member = Customer::where('forgetpass_code',$request->forgetpass_code)
                ->where('forgetpass_code_date', '>', Carbon::now()->subMinutes(30)->toDateTimeString())
                ->orderBy('forgetpass_code_date', 'desc')->latest()->first();
          if(!$Member){
            return 'expired   ' ;
          }
        $Member->update([
          'forgetpass_code' => null ,
          'forgetpass_code_date' => null ,
          'password' => \Hash::make($request->password)
        ]);

        auth()->guard('Member')->loginUsingId($Member->id, true);
        return redirect('/');
    }


    public function change_password_page()
    {
        return view('Site/change_password');
    }

    //---api---
    public function change_password_action(Request $request)
    {
          $validator = \Validator::make($request->all(),[
              'old_password' => 'required',
              'password' => 'required',
          ]);
          if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }


            $member = Customer::find(auth('Member')->id());
          if( \Hash::check($request->old_password, $member->password ) )
          {
              $member->update([
                  'password' => \Hash::make($request->password)
              ]);

              return response()->json([
                'status' => 'success',
                'flash_message' => __('page.password_has_changed')
              ]);
          }
          else //else of \Hash::check
          {
             return response()->json([
               'status' => 'faild' ,
               'flash_message' => __('page.change_password_wrong_old_pass')
             ]);
          }
    }


}
