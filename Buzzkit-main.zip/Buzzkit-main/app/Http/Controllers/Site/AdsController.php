<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\SinglePageAdminController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Ads;

class AdsController extends SinglePageAdminController
{

    public function __construct()
    {
        parent::__construct();

          $this->set_model_name('Ads');

          $this->search_attrs =  [
               'id' , 'title_en' , 'title_ar'
          ];

          $this->sort_attrs =  [
               'id' , 'title_ar as name' , 'position'  , 'status'
          ];

          $this->store_attrs =  [
              'title_en' => 'required',
              'title_ar' => 'required',
              'image' => 'required',
              'link' => 'required',
          ];

          $this->update_attrs =  [
              'id' => 'required',
              'title_en' => 'required',
              'title_ar' => 'required',
              'image' => '',
              'link' => 'required',
          ];
    }





}
