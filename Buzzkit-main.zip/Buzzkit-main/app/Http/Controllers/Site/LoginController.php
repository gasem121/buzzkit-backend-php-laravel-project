<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\City;
use App\User;
use App\Customer;
use App\MemberAddress;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

use swal;


class LoginController extends BaseController
{
    public function create()
    {
       //xdd(( auth('Member')->check() )? auth('Member')->id() : 0 );  
            $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;
             
           $returned_details['index']=5;
             
        return view('Site.login',$returned_details);
    }

     public function login(Request $request){



      
          $Member = Customer::where('phone',$request->phone)->where('password',md5($request->password))->first();


        
          if(!$Member)
          {
            return  response()->json([
             'status' => 'faild',
             'flash_message' => "Wrong phone or password"
           ]);
          }  
          
          
          if($Member->status==0){
               return  response()->json([
             'status' => 'faild',
             'flash_message' => "Sorry your account has been stopped"
           ]);
          }

        
       //auth()->guard('Member')->loginUsingId($Member->id, true);


          Session::put('member_id', $Member->id);

        
        return  response()->json([
             'status' => 'success',
             'flash_message' => "Correct Data"
           ]);
    }

    public function logOut(){

       Session::put('member_id',0);

        return redirect()->to('/');
    }
}
