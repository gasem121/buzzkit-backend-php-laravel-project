<?php

namespace App\Http\Controllers\Site;
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Job;
use App\Branch;
use App\ProductFile;
use App\CategoryofProducts;
use App\BrandofProducts;
use App\VendorsProductNotificationsFromAdmin;

class BranchController extends Controller
{
   
    public function index()
    {
    	 $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
        $lang = \App::getLocale();
          $branches = Branch::select("id",'title_'.$lang.' as title','description_'.$lang.' as description','image')->where('status','1')->get();

          //dd($jobs[0]['image']);

         return view('Site.branches',compact('branches','user' ));
    }

    

    

}
