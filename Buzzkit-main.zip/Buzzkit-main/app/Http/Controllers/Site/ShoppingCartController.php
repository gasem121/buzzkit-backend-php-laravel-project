<?php
namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Setting;
use App\Cart;
use App\Order;
use App\MemberPromo;
use App\PromoCode;
use App\FreeTestList;
use App\UserAddress;
use DB;
use App\PagesBanner;
use App\CategoryofProducts;
use App\SubCategoryofProducts;
use App\Product;
use App\HomeSlider;
use App\NewItem; 
use App\Ads; //home_slider
use App\BrandofProducts;
use App\CartAttribute;
use App\Partener;
use App\Customer;
use App\ProductAttribute;
use Illuminate\Support\Facades\Session;
use App\Lab;
use App\SpecName;
use App\SpecValue;

class ShoppingCartController extends BaseController
{
    public function __construct()
    {

      // $this->middleware('auth:Member');
       // $this->middleware('CheckIfAddressCorrect')->only('index');
    }

   public function index()
   {            
                
               
      
             $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;
               
             
              $customer = Customer::where('id',$AuthMember_id)->first();
        
     
        $carts =  Cart::where('user_id',$AuthMember_id )->where('order_id',0)->get();
        
         $total=0.0;
  
        
        foreach($carts as $cart){
            $cart->product = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('id',$cart->product_id)->first();
            $total+= ($cart->product->price_after * $cart->quantity);
            $cart->cart_id = $cart->id;
        }
             //dd($total);
             
             $total = ceil($total/ 1.14);
             
             $vat =  0.14*$total;
             
             $shipping=45;
             
             $total_vat = round($total + (0.14*$total));
             
             
               $total_with_shipping = $total_vat+$shipping;
               
             $ads_count=-1;
            $session_id=0;

          return view('Site.Cart',$returned_details,compact('carts','total','total_vat','vat','session_id','total_with_shipping','shipping','customer')  );
    }


public function update_order_status_call_back(){
    return "Done";
}

 public function orderProducts(Request $request){

             $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;
             
             $shipping = 45;


            $order = Order::where('id',$request->order_id)->first();
            
            
            $address = UserAddress::where('id',$order->location_id)->first();
            
          

           
          if($address){
              $address = $address->address;
          }else {
              
              $address="";
          }
     
            
            $order->address=$address;
          
          $carts =  Cart::where('order_id',$order->id )->get();
        
         $total=0.0;
  
        
        foreach($carts as $cart){
            $cart->product = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('id',$cart->product_id)->first();
            $cart->product->price = ($cart->product->price_after * $cart->quantity);
            $total+= ($cart->product->price_after * $cart->quantity);
        }
             //dd($total);
            
            
             
             
               
           $total = round($total / 1.14);
            
             
            
            $vat = round($total * 0.14);
            
            
            $total_vat =  $total+$vat ;
            
            
             $ads_count=-1;
            
            $session_id=0;
            
            $ads_count=-1;
            
            //dd($carts);
            
            $total_with_shipping = $total_vat+$shipping;

          return view('Site.OrderProducts',$returned_details,compact('carts','total','total_vat','vat','order','address','total_with_shipping'));
    }


    public function list()
    { 
           $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;

        $lang = \App::getLocale();
        $Authuser_id = $this->user;
        $ShoppingCart = Cart::select(
                          'shopping_cart.id as id' ,'products.price','products.image as image',
                          "products.name_$lang as name" ,'products.id as product_id',
                          "products.stock as stock","description_$lang as description",
                          "shopping_cart.quantity as in_card_quantity",
                          DB::raw("CONCAT('cc_',shopping_cart.id) as cc")
                    )
                    ->join('products','products.id','shopping_cart.product_id')
                    ->groupBy('shopping_cart.id')
                    ->where( 'user_id',$AuthMember_id )
                    // ->where( 'products.stock','>','0' )
                    ->get();
                    
                    
           
         return $ShoppingCart;
    }


    public function add(Request $request)
    {


              $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;

      if($AuthMember_id==0){
          
          $cus = Customer::latest()->first();
          
          
         $user_temp =  Customer::create([
                          'name' => 'Guest-',
                          'second_name' => $cus->id+1 ,
                          'password' => '123' ,
                            'email' => '-' ,
                             'phone' => '-' ,
                             'jwt' => '-' ,
                         
                    ]);
        
        $this->user = $user_temp->id;
                    
        Session::put('member_id', $this->user);
        
        
        $AuthMember_id = $user_temp->id;
        
        
      }

         $ShoppingCart = Cart::where( 'user_id',$AuthMember_id)->where('order_id',0)->where('product_id',$request->product_id)->first();
         $product = Product::findOrFail($request->product_id);

         if($request->quantity) //a spisifc quantity
         {
             
             if($ShoppingCart){
             $final_quantity = ($request->quantity??1)+$ShoppingCart->quantity;
             }else {
                 
                 $final_quantity = ($request->quantity??1);
             }


             $stack_on = Product::where('id',$request->product_id)->where('at_stock','>=',$final_quantity)->first();


               if($ShoppingCart){
                     $ShoppingCart->update([ 'quantity' => 1+$ShoppingCart->quantity ]);
               }
               else {
                   
                     $ShoppingCart = Cart::create([
                          'user_id' => $AuthMember_id,
                          'product_id' => $request->product_id,
                          'quantity' => $request->quantity??1,
                    ]);
                    
                   
               }
               
               
               return response()->json([
                'status' => 'success',
                'case' => true,
                'dats' => $request->selected_sku,
                'quantity' => $ShoppingCart->quantity,
                'flash_message' => $request->multi_skus
               ]);
         }

    
      }


       public function increase_cart(Request $request){

 
        $ShoppingCart = Cart::where('id',$request->cart_id)->first();
        
           $final_quantity = 1+$ShoppingCart->quantity;
        
          $stack_on = Product::where('id',$ShoppingCart->product_id)->where('at_stock','>=',$final_quantity)->first();
             
             
             if(!$stack_on){
                 return response()->json([
                'status' => 'out_stock',
                'case' => true,
                'flash_message' => 'sorry this product is out of stock'
               ]);
             }
             
    
        
       $ShoppingCart->update([ 'quantity' => 1+$ShoppingCart->quantity ]);
        

          return response()->json([
                'status' => 'success',
                'case' => true,
                'quantity' => $ShoppingCart->quantity,
                'flash_message' => 'prouduct added to the cart'
               ]);

      }


         public function decrease_cart(Request $request){
        $ShoppingCart = Cart::where('id',$request->cart_id)->first();

        if($ShoppingCart->quantity>1)
       $ShoppingCart->update([ 'quantity' => $ShoppingCart->quantity-1 ]);
         

          return response()->json([
                'status' => 'success',
                'case' => true,
                'quantity' => $ShoppingCart->quantity,
                'flash_message' => 'prouduct added to the cart'
               ]);

      }


      public function remove(Request $request)
      { 

        $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;


        $AuthMember_id = $this->user;
      if(   $AuthMember_id==0){
        return redirect()->to('/login');
      }


           Cart::where( 'user_id',$AuthMember_id)->whereId($request->cart_id)->delete();
           return response()->json([
             'status' => 'success',
             'flash_message' => __('page.product has deleted from the cart')
           ]);
      }


      public function finishOrder(Request $request)
      {
          
          
          
 
          $returned_details = $this->init();
             $lang = $this->lang;
          $AuthMember_id = $this->user;
          
          
          $cart = Cart::where( 'user_id',$AuthMember_id)->where('order_id',0)->get();
          
          $order = Order::latest()->first();
          
          if(count($cart)==0){
              return response()->json([
              'order_id' => $order->id,
             'status' => 'success',
             'flash_message' => $order->id
             
           ]);
          }
          
          
          $delivery_fees = 45;

      if( $AuthMember_id==0){
        return redirect()->to('/login');
      }
      
      $single_temp_user = Customer::where('id',$AuthMember_id)->first();
      
      if($single_temp_user->email=="-"){
          
       $single_temp_user->name = $request->first_name;
        $single_temp_user->second_name = $request->second_name;
         $single_temp_user->phone = $request->phone;
          $single_temp_user->email = $request->email;
          $single_temp_user->save();
      
          
          
      }
       
       
       $city = "";
       
       if($request->countryCode == "Egypt"){
           $city = $request->cityCode;
       }else {
           
           $city = $request->city;
       }
        
       if(!$request->discount)$request->discount=0;
       
       $request->address = $request->address." , ".$request->countryCode." , ".$city ;
      
      $location_id =  UserAddress::create([
               'user_id' => $AuthMember_id,
                'address' => $request->address,
                'country_code' => $request->country,
                'country' => $request->country,
                'city' => $request->city,
                 'area_id' => 1 ,
                  'lat' => 0,
                  'lng' => 0
            ])->id;
            
       

          $order = Order::create([
              'user_id' => $AuthMember_id,
                'location_id' => $location_id,
                 'comment' => $request->message ,
                  'total_price' => $request->final_price,
                  'delivery_cost' => $delivery_fees,
                  'discount' => $request->discount,
                  'payment_type' => $request->payment_type
            ]);
        
       // $order = Order::first();
     

        $single_customer = Customer::where('id',$AuthMember_id)->first();

    
            $data = array();
            $customer_name = $single_customer->name." ".$single_customer->second_name;
            $phone = $single_customer->phone;
            $customer_id = $single_customer->phone;
            $address = $request->address." \n ".$request->message;
            $country = $request->countryCode;
            $city = $city;
            $order_number = $order->id."-10002";
            $order_amount = $request->final_price;
            $shipping_fee = 45;
            $total_order = $order_amount+$shipping_fee;
            
            

          $cart = Cart::where( 'user_id',$AuthMember_id)->where('order_id',0)->update(['order_id'=>$order->id]);
          
          
           //don't forget to divide in discunt
          
            
            $line_items = array();

          $cart = Cart::where('order_id',$order->id)->get();
          
            $discount = 0;
            
            
            foreach($cart as $item){
                
                
               $product =  Product::where('id',$item->product_id)->first();
              
  
               $attribute_id = CartAttribute::where('cart_id',$item->id)->first()->attribute_id;
               
               
               $skus  = ProductAttribute::where('product_id',$product->id)->where('attribute_id',$attribute_id)->get();
              
              foreach($skus as $single_sku){
                  
              $sku = $single_sku->store_codes;
              
              
              $sku_mins = ProductAttribute::where('product_id',$product->id)->where('attribute_id',$attribute_id)->first();
              
              if($sku_mins){
                  
                  $sku_mins->store_quantity = $sku_mins->store_quantity - $item->quantity;
                  $sku_mins->save();
              }
              
              
            $price = $product->price_after;
            $item_id = $product->id;
            $item_name = $product->name_en;
            $single_quantity = $item->quantity;
            
            
         $discount += (($product->price_after*$item->quantity)/100) * $request->discount;
            
            
            
          $single_item =  [
            "SKU" => $sku,
            "Price" => $price,
            "ItemId" => $item_id,
            "ItemName" => $item_name,
            "Quantity" => $single_quantity,
            "DiscountAmount" => null,
             ];
             
            array_push($line_items,$single_item); 
              }
            
               
               $product->at_stock-=$item->quantity;
               
               $product->save();
                
                
            }
            
            
            
            ///Start shipment 
            
                 
          $result = "";
          $postdata=null;
         
            
              return response()->json([
              'order_id' => $order->id,
             'status' => 'success',
             'flash_message' => $order->id
             
           ]);
           

      }


      public function get_Count_number()
      {
          return Cart::where( 'user_id',$AuthMember_id)->count();
      }


      function sendPayment($apiURL, $apiKey, $postFields) {

    $json = $this->callAPI("$apiURL/v2/SendPayment", $apiKey, $postFields);
    return $json->Data;
}



 


private function get_payment_token(){
    
    
            $curl = curl_init();
            $url = "https://accept.paymob.com/api/auth/tokens";
 
            $data = [
                    "username" => "01065500508",
                     "password" => "owTv3L@U94W&mV",
                ];
 
            $postdata = json_encode($data);

            $ch = curl_init($url); 
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'Content-Type: application/json',));
            $result = curl_exec($ch);
             curl_close($ch);
             
         return  json_decode($result,true)['token'];  
             
} 


 public function generate_payment(Request $request){
     
     
    
        
           $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;
        $order = Order::where('user_id',$AuthMember_id)->orderBy('id','desc')->first() ;
        
        //  $order = Order::where('id',425)->orderBy('id','desc')->first() ;
        //   $AuthMember_id =   $order->user_id;
        
        
   
       
        
    
        
         if($request->success == true){
          $order->order_paid = $request->id;
            $order->save();
         }else {
             
             return "Sorry Payment error please call the provider";
         }
         
         
        //   if($order->payment_type==0){
        //         $lang = $this->lang;
             
             
        //   return view('Site.Confirmed',$returned_details,compact('lang')  );
        // }
     
     
           
            
            
              $order_total_price = $order->total_price;
             	$order_total_price-= $order->delivery_cost;
           
        
            $order_original_price = ceil($order_total_price / 1.14);
            $order_total_price_taxes = floor($order_original_price * 0.14);
            $order_total_price_without_taxes =  $order->original_price ;
            $order_total_price_with_taxes = round($order_total_price_taxes+$order_original_price);
            
            
               $order_total_price = round(($order_total_price_taxes+$order_original_price) + $order->delivery_cost);
               
 
            
            if($order->discount){
                 
                $order_total_price  = ( $order_total_price_with_taxes - round(($order->discount/100)* $order_total_price_with_taxes)  );
            }
            
    
    
         $line_items = array();

          $cart = Cart::where('order_id',$order->id)->get();
            $discount = 0;
            foreach($cart as $item){
               $product =  Product::where('id',$item->product_id)->first();
               $attribute_id = CartAttribute::where('cart_id',$item->id)->first()->attribute_id;
              $sku = ProductAttribute::where('product_id',$product->id)->where('attribute_id',$attribute_id)->first()->store_codes;
            $price = $product->price_after;
            $item_id = $product->id;
            $item_name = $product->name_en;
            $single_quantity = $item->quantity;
         $discount += (($product->price_after*$item->quantity)/100) * $order->discount;
          $single_item =  [
            "SKU" => $sku,
            "Price" => $price,
            "ItemId" => $item_id,
            "ItemName" => $item_name,
            "Quantity" => $single_quantity,
            "DiscountAmount" => null,
             ];
             
            array_push($line_items,$single_item); 
               $product->at_stock-=$item->quantity;
               
               $product->save();
            }
            
        
    
        $order_number = $order->id;
        
        
         $single_customer = Customer::where('id',$AuthMember_id)->first();

    
            $data = array();
            $customer_name = $single_customer->name." ".$single_customer->second_name;
            $phone = $single_customer->phone;
            $customer_id = $single_customer->phone;
       
            
             $address = UserAddress::where('id',$order->location_id)->first();
             
             
         
            
            $country = $address->country_code;
            $city = $address->city;
            $order_number = $order->id."-10002";
           $address = $address->address."\n".$order->comment;
            
           
             
                $order_amount = $order_total_price;
            
            $shipping_fee = $order->delivery_cost;
            $total_order = $order_amount+$shipping_fee;
 
             
         
        
        
             $lang = $this->lang;
             
             
          return view('Site.Confirmed',$returned_details,compact('lang')  );
    
        
    
    }

private function setup_payment_order(){
    
       
          $returned_details = $this->init();
             $lang = $this->lang;
          $AuthMember_id = $this->user;
          
          
             $token = $this->get_payment_token();
             
    
    
            $line_items = array();
 
                $cart = Cart::where('user_id',$AuthMember_id)->where('order_id',0)->get();
          
            $discount = 0;
            
            $total=0;
            
            
            foreach($cart as $item){
                
                    $product =  Product::where('id',$item->product_id)->first();
        
            
                  $single_item =  [
                    "name" => $product->name_en,
                    "amount_cents" => ($product->price_after*100),
                    "description" => $product->name_en." - ".$product->id,
                    "quantity" => $item->quantity,
                     ];
                     
                    array_push($line_items,$single_item); 
                    
                    
                    $total+=($product->price_after*100);
            } 
          
        
             $data = [
                    "auth_token" => $token,
                     "delivery_needed" => false,
                     "currency" => "EGP",
                      "amount_cents" => $total,
                     "items" => $line_items,
                     
                ];
                
                
                //dd($data);
             
        
            $curl = curl_init();
            $url = "https://accept.paymob.com/api/ecommerce/orders";
            
       

            $postdata = json_encode($data);
            
            
            $ch = curl_init($url); 
            
            
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  
            
            
            $result = curl_exec($ch);
            
             
         $payment_order_id = json_decode($result,true)['id'];   
         
         
          curl_close($ch);
          
                    $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;
             
            $customer = Customer::where('id',$AuthMember_id)->first();
          
          $billing_data = [
                     
                     "email" => $customer->email,
                     "first_name" => $customer->name,
                     "phone_number"=> $customer->phone,
                     "apartment" => 803,
                     "floor" => 42,
                     "street"=> "Ethan Land",
                     "building" => 8028,
                     "last_name" => $customer->name,
                     "country" => "Egypt",
                     "city" => "Cairo",
                ];
             
            
                 $data = [
                    "auth_token" => $token,
                     "delivery_needed" => false,
                     "currency" => "EGP",
                     "billing_data"=>$billing_data,
                      "amount_cents" => $total,
                     "expiration" => 60000,
                     "order_id"=> $payment_order_id,
                     "integration_id"=> 2059699,
                      "lock_order_when_paid"=> "false",
                ];
        
            $curl = curl_init();
            $url = "https://accept.paymob.com/api/acceptance/payment_keys";
 
       

            $postdata = json_encode($data);
            
            
            $ch = curl_init($url); 
            
            
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  
            
            
            $result = curl_exec($ch);
            
   
            
             $token = json_decode($result,true)['token'];
             
             
} 

//------------------------------------------------------------------------------
/*
 * Call API Endpoint Function
 */

function callAPI($endpointURL, $apiKey, $postFields = [], $requestType = 'POST') {

    $curl = curl_init($endpointURL);
    curl_setopt_array($curl, array(
        CURLOPT_CUSTOMREQUEST  => $requestType,
        CURLOPT_POSTFIELDS     => json_encode($postFields),
        CURLOPT_HTTPHEADER     => array("Authorization: Bearer $apiKey", 'Content-Type: application/json'),
        CURLOPT_RETURNTRANSFER => true,
    ));

    $response = curl_exec($curl);
    $curlErr  = curl_error($curl);

    curl_close($curl);

    if ($curlErr) {
        //Curl is not working in your server
        die("Curl Error: $curlErr");
    }

    $error = $this->handleError($response);
    if ($error) {
        die("Error: $error");
    }

    return json_decode($response);
}

//------------------------------------------------------------------------------
/*
 * Handle Endpoint Errors Function
 */

function handleError($response) {

    $json = json_decode($response);
    if (isset($json->IsSuccess) && $json->IsSuccess == true) {
        return null;
    }

    //Check for the errors
    if (isset($json->ValidationErrors) || isset($json->FieldsErrors)) {
        $errorsObj = isset($json->ValidationErrors) ? $json->ValidationErrors : $json->FieldsErrors;
        $blogDatas = array_column($errorsObj, 'Error', 'Name');

        $error = implode(', ', array_map(function ($k, $v) {
                    return "$k: $v";
                }, array_keys($blogDatas), array_values($blogDatas)));
    } else if (isset($json->Data->ErrorMessage)) {
        $error = $json->Data->ErrorMessage;
    }

    if (empty($error)) {
        $error = (isset($json->Message)) ? $json->Message : (!empty($response) ? $response : 'API key or API URL is not correct');
    }

    return $error;
}



    public function check_promo_code(Request $request){
            
 
        
        $promo_code = PromoCode::where('code',$request->promo_code)->where('status',1)->first();
        
        if(!$promo_code){
                 return response()->json([
             'status' => 'faild',
             'message' => 'Sorry wrong promo code'
           ]);
           
     	 }
     	  
     	   return response()->json([
             'status' => 'success',
             'promo_code' => $promo_code
           ]);
           
            
    }



}
