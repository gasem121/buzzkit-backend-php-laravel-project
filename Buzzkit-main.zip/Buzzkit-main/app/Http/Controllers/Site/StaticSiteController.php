<?php


namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
 
use App\Product; 
use App\Category;   
use App\Suggestion;
use Illuminate\Support\Facades\Crypt;


class StaticSiteController extends Controller {
      
      public function index(){

        $index=0;
       
        $statistics  = array();

 $categories = Category::where('deleted_at',null)->where('status',1)->get();

      foreach ( $categories as $category) {
      
          $category->products = Product::where('category_id',$category->id)->get();
           $category->name =  $category->name_en;

            foreach ( $category->products as $product) {

              $product->name=$product->name_en;

            }

        }




    return view('Site.home',compact('categories','index'));
     
      }


  public function about(){
    $index=1;
    return view('Site.about',compact('index'));
  }

  public function service(){
       $index=2;
    return view('Site.service',compact('index'));
  }

  
   public function menu(){

           $index=3;

     $statistics  = array();
    $categories = Category::where('deleted_at',null)->where('status',1)->get();

      foreach ( $categories as $category) {
      
          $category->products = Product::where('category_id',$category->id)->get();
           $category->name =  $category->name_en;

            foreach ( $category->products as $product) {

              $product->name=$product->name_en;

            }

        }
    return view('Site.menu',compact('categories','index'));
      }


 public function contact(){
       $index=4;
    return view('Site.contact',compact('index'));
 }


 public function ask_for_franchise(){
     
      $index=10;
    
    return view('Site.ask-for-franchise',compact('index'));
 }


 public function enter_franchise_details(Request $request){
     
          $this->validate(request(), [
            'user_name' => 'required',
            'subject' => 'required',
            'phone_email' => 'required',
            'message' => 'required'
        ]);
        
        $request->is_franchise=1;
        
        Suggestion::create([
                'user_name' => $request->user_name ,
                'subject' => $request->subject ,
                'phone_email' => $request->phone_email ,
                'message' => $request->message ,
                   'is_franchise' => 1 ,
 
            ]);
        
            
    

         
         return redirect()->back()->with('alert', 'Message Sent successfully and we will call you as fast as possible!');
      
    
    return view('Site.ask-for-franchise',compact('index'));
 }





 public function contact_us(Request $request){

  
           $this->validate(request(), [
            'name' => 'required',
            'subject' => 'required',
            'phone_email' => 'required',
            'message' => 'required'
        ]);
        

         Suggestion::create(request(['user_name', 'subject','phone_email', 'message']));

         
         return redirect()->back()->with('alert', 'Message Sent successfully and we will call you as fast as possible!');
      
 

       
    return view('Site.contact',compact('index'));
 }




 

}
