<?php

namespace App\Http\Controllers\Site;
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Setting;
use App\Suggestion;
use App\User;
use App\Order;
use App\Email;
use App\CategoryofProducts;
use App\BrandofProducts;
use App\ShoppingCart;
use Illuminate\Support\Facades\Session; 
use App\VendorsProductNotificationsFromAdmin;

class SettingsController extends BaseController
{
   
    public function index()
    {

         $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;

       $user = $this->user;
        $lang = \App::getLocale();
          $settings = Setting::select("id",'title','value')->get();
        
          $setting =  array();

          foreach($settings as $item){

              if($lang=="ar"&&$item['title']=="about_title_ar"){
                $setting['about_title']=$item['value'];
              }
        
        if($lang=="ar"&&$item['title']=="about_details_ar"){
                $setting['about_details']=$item['value'];
              }



              if($lang=="en"&&$item['title']=="about_title_en"){
                $setting['about_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="about_details_en"){
                $setting['about_details']=$item['value'];
              }



          if($lang=="ar"&&$item['title']=="what_we_do_title_ar"){
                $setting['what_we_do_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="what_we_do_title_en"){
                $setting['what_we_do_title']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="what_we_do_details_ar"){
                $setting['what_we_do_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="what_we_do_details_en"){
                $setting['what_we_do_details']=$item['value'];
              }


          if($lang=="ar"&&$item['title']=="our_vision_details_ar"){
                $setting['our_vision_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_vision_details_en"){
                $setting['our_vision_details']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="our_vision_title_ar"){
                $setting['our_vision_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_vision_title_en"){
                $setting['our_vision_title']=$item['value'];
              }


          if($lang=="ar"&&$item['title']=="our_mission_details_ar"){
                $setting['our_mission_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_mission_details_en"){
                $setting['our_mission_details']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="our_mission_title_ar"){
                $setting['our_mission_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_mission_title_en"){
                $setting['our_mission_title']=$item['value'];
              }
              
              
               if($lang=="ar"&&$item['title']=="fotter_description_ar"){
                $setting['fotter_description']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="fotter_description_en"){
                $setting['fotter_description']=$item['value'];
              }


             if($item['title']=="logo"){
               
                  $setting['logo']=asset('images/Settings/'.$item['value']);
              }
              
              if($item['title']=="about_us_image"){
               
                  $setting['about_us_image']=asset('images/Settings/'.$item['value']);
              }
              
              if($item['title']=="what_we_do_image"){
               
                  $setting['what_we_do_image']=asset('images/Settings/'.$item['value']);
              }
              
              if($item['title']=="our_vision_image"){
               
                  $setting['our_vision_image']=asset('images/Settings/'.$item['value']);
              }
              
              if($item['title']=="our_mission_image"){
               
                  $setting['our_mission_image']=asset('images/Settings/'.$item['value']);
              }

              
          } 
          
          
              $returned_details['index']=3;
 

         return view('Site.about',$returned_details,compact('setting','user'));
    }


    public function contact()
    {
    

          $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;

             
          $settings = Setting::select("id",'title','value')->get();
        
          $setting =  array();

          foreach($settings as $item){

              if($lang=="ar"&&$item['title']=="contact_us_ar"){
                $setting['contact_us']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="contact_us_en"){
                $setting['contact_us']=$item['value'];
              } 




        if($item['title']=="email"){
                $setting['email']=$item['value'];
              }
             
        
               if($item['title']=="phone"){
                $setting['phone']=$item['value'];
              }


              if($lang=="ar"&&$item['title']=="address_ar"){
                $setting['address']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="address_en"){
                $setting['address']=$item['value'];
              }


                if($item['title']=="map"){
                $setting['map']=$item['value'];
              }




              
          }
    
            $returned_details['index']=4;

         return view('Site.contact',$returned_details,compact('setting'));
    }
    
    
   


      public function account_details()
    { 


               $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;


          $user_id = $this->user;
          
          $user_details = User::where('id',$user_id)->first();
          $orders = Order::where('user_id',$user_id)->latest()->get();

          foreach ($orders as $order) {
            $order['created_at'] = date("M d, Y", strtotime($order['created_at'])); 
             $order['quantity']= ShoppingCart::where('order_id',$order->id)->count();
        
          }
          
           
          
              $returned_details['index']=5;

         return view('Site.MyAccount',$returned_details,compact('user_details','orders'));
    }


    public function update_details(Request $request)
    {


              $returned_details = $this->init();
             $lang = $this->lang;
         
          $user_id = $this->user;
          $user = User::where('id',$user_id)->first();


          if($request->current_pwd&&$request->new_pwd&&$request->confirm_pwd){



              if(md5($request->current_pwd)!=$user['password']){
                  redirect()->back()->with('alert_error', "Sorry your current password not correct");  
              }


              if($request->new_pwd != $request->confirm_pwd){
                  redirect()->back()->with('alert_error', "Sorry passwords not matches");  
              }


          $user->password = md5($request->new_pwd);
          $user->save();

            }



          if($request->acc_name){
          $user->name = $request->acc_name;
          $user->save();
          }
       
     

         return  redirect()->back()->with('alert', 'Data has been updated successfully');
    }


   public function add_message(Request $request)
    {
           $this->validate(request(), [
            'user_name' => 'required',
            'subject' => 'required',
            'phone_email' => 'required',
            'message' => 'required'
        ]);
        

         Suggestion::create(request(['user_name', 'subject','phone_email', 'message']));
         return redirect()->back()->with('alert', 'Message Sent successfully and we will call you as fast as possible!');
      
    }
    
    
    public function add_email(Request $request)
    {       
        $email = Email::where('email',$request->email)->first();
        
            if(!$email){
            Email::create(request(['email']));
            }
            
           return response()->json([
                'status' => 'success',
                'flash_message' => 'E-mail signed up succssefully'
               ]);
      
    }
    

}
