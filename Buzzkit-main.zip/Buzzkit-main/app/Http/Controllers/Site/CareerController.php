<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Job;
use App\JobApplicant;
use App\PagesBanner;
use App\Setting;
use DB;


class CareerController extends Controller
{
      public function index()
      {
          $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
          $lang = \App::getLocale();
          $navActive = 'Career';
          $Banner = PagesBanner::select("imageen as image","title_$lang as title","body_$lang as body")
                                    ->where('page','careers')->first();

          return view('Site.Career',compact('Banner','navActive','user' )  );
      }


      public function get_list()
      {
          $lang = \App::getLocale();
          return Job::select('id',"title_$lang as title","description_$lang as description", \DB::raw("false as is_opend"))
             ->where('status',1)
             ->orderBy('position')
             ->paginate();
      }

      public function store(Request $request)
      {
            $validator = \Validator::make($request->all(),[
              'job_id' => 'required',
              'name' => 'required',
              'phone' => 'required',
              'email' => 'required',
              'resume' => 'required',
              'birth_day' => 'required',
            ]);

            if ($validator->fails()) { return response()->json([ 'status' => 'notValid' , 'data' => $validator->messages() ]);  }

            $JobApplicant = JobApplicant::create($request->all());

            return response()->json([
              'status' => 'success',
              'flash_message' => __('page.Career_flash_message')
            ]);
      }

}
