<?php
namespace App\Http\Controllers\Site;

use App\Http\Controllers\SinglePageAdminController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use App\Certification;
use App\ProductFile;
use App\CategoryofProducts;
use App\BrandofProducts;
use App\VendorsProductNotificationsFromAdmin;

class CertificationController extends Controller
{
   

    public function index()
    {
            $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;

                 $lang = \App::getLocale();
          $certifictions = Certification::select("id",'title_'.$lang.' as title','description_'.$lang.' as description','image')->where('status','1')->get();

          
         return view('Site.certifictions',compact('certifictions','user'));
    }

    

}
