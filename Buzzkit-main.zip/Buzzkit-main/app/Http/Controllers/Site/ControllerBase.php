<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use App\Member;
use App\Customer;

use App\MemberAddress;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Task;
use App\HomeSlider;
use App\Ads; //home_slider
use App\CategoryofProducts;
use App\SubCategoryofProducts;
use App\BrandofProducts;

class ControllerBase extends Controller {


public $registered;
public $lang;
public $user;
public $brands;
public $categories;


    public function init()
    {
       $this->lang = \App::getLocale();
        $lang = $this->lang;
       $user_id = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
       $this->user  = Member::where('id',$user_id)->first();

         $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
    
    
          
          $this->brands = BrandofProducts::select("id",'name_'.$lang.' as title','image')->where('status','1')->get();
          $this->ads = Ads::where('status','1')->get();

      

        $this->categories = CategoryofProducts::select("id",'name_'.$lang.' as title','image')->where('status','1')->limit(5)->get();


     for($i=0; $i<count($this->categories); $i++){
          $sub_categories = SubCategoryofProducts::select("id",'name_'.$lang.' as title','image')->where('category_of_product_id',$this->categories[$i]->id)->get();

           $this->categories[$i]['sub_categories'] = $sub_categories;
        }


       

       
        
    }

  }
