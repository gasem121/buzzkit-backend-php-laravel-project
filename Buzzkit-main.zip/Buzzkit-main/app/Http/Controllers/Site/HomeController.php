<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\CategoryofProducts;
use App\Product; 
use App\FavouriteProducts;
use App\PagesBanner;
use App\ProductAttribute;


use App\Blog;
use App\Ads;
use App\Http\Controllers\Fatorah\PaymentMyfatoorahApiV2;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;

// use App\Setting;


class HomeController extends BaseController
{
      public function index()
      { 
          
          // \App::setLocale("ar");
                
             $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;


          $top_offers = Product::where('status',1)->where('deleted_at',NULL)->select("id",'price_before','price_after','name_'.$lang.' as title','image')->where('is_offer','1')->where('status','1')->where('deleted_at',NULL)->get();

            for($j=0; $j<count($top_offers); $j++){
                
                $top_offers[$j]['at_stock'] = ProductAttribute::where('product_id',$top_offers[$j]->id)->sum('store_quantity');
                
                    $top_offers[$j]['off']  = ( ( $top_offers[$j]['price_before']-$top_offers[$j]['price_after'])/$top_offers[$j]['price_before']) * 100;
           
                
                $top_offers[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$top_offers[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
            }

     $latest_products = Product::where('status',1)->where('deleted_at',NULL)->select("id",'price_before','price_after','name_'.$lang.' as title','image')->where('status','1')->where('deleted_at',NULL)->latest()->limit(20)->get();
        
        
        for($j=0; $j<count($latest_products); $j++){
            
            
            $latest_products[$j]['off']  = ( ( $latest_products[$j]['price_before']-$latest_products[$j]['price_after'])/$latest_products[$j]['price_before']) * 100;
            
              $latest_products[$j]['at_stock'] = ProductAttribute::where('product_id',$latest_products[$j]->id)->sum('store_quantity');
              
              
                $latest_products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$latest_products[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
            }

           $banners = PagesBanner::where('status',1)->where('deleted_at',NULL)->select("id",'image','link')->get();


            $blogs = Blog::where('status',1)->where('deleted_at',NULL)->get();
 
            $returned_details['index']=1;
            //dd($banners);
 

          return view('Site.Home',$returned_details,compact('top_offers','latest_products','banners','blogs')  );
      }


       public function add(Request $request)
    {

     // dd("test");
         $data = $request->validate([
            'product_id' => 'required',
            'quantity' => '',
            'price' => ''
         ]);

         $ShoppingCart = ShoppingCart::where( 'user_id',auth('Member')->id() )->where('product_id',$request->product_id)->first();
         $product = Product::findOrFail($request->product_id);

         if($request->quantity) //a spisifc quantity
         {
               if($ShoppingCart){
                     $ShoppingCart->update([ 'quantity' => (int)$request->quantity ]);
               }
               else {
                     $ShoppingCart = ShoppingCart::create([
                          'user_id' => auth('Member')->id(),
                          'product_id' => $request->product_id,
                          'quantity' => $request->quantity??1,
                    ]);
               }
               return response()->json([
                'status' => 'success',
                'case' => true,
                'quantity' => $ShoppingCart->quantity,
                'flash_message' => 'prouduct added to the cart'
               ]);
         }

         if($ShoppingCart)
         {
                $ShoppingCart->delete();

                return response()->json([
                   'status' => 'success',
                   'case' => false,
                   'quantity' => 0,
                   'flash_message' => 'prouduct removed from the cart'
                ]);
         }//End if($ShoppingCart)
         else
         {
                $ShoppingCart = ShoppingCart::create([
                     'user_id' => auth('Member')->id(),
                     'product_id' => $request->product_id,
                     'quantity' => $request->quantity??1,
                ]);

                return response()->json([
                   'status' => 'success',
                   'case' => true,
                   'quantity' => $ShoppingCart->quantity,
                   'flash_message' => 'product added to cart'
                ]);
          }
      }




 public function show($id){
   $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
          $lang = \App::getLocale();
          $navActive = 'New';
          $AuthMember_id = ( auth('Member')->check() )? auth('Member')->id() : 0 ;

            $Product = NewItem::select("id",'title_'.$lang.' as title','details_'.$lang.' as details','image' )->where('new_items.id',$id)
             ->first();
          return view('Site.home-news-single',compact('navActive','Product','related_products','user') );

      }
      
      
      public function change_language($language){
          
          Session::put('current_language',$language);
          
         // dd(Session::get('current_language'));
          
          return Redirect::to('/');
      }









}
