<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Product;
use App\PagesBanner;
use App\FavouriteProducts;
use App\BrandofProducts;

class WishListController extends BaseController
{
    public function __construct()
    {
       //$this->middleware('auth:Member');
    }

   public function index()
   {

 
             $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;

            $products =  Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->whereIn('id',FavouriteProducts::where('user_id',$AuthMember_id)->pluck('product_id'))->get();
  
  for($j=0; $j<count($products); $j++){
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'\ecommerce\public\images\ic_liked.png':'\ecommerce\public\images\ic_liked.png';
            }


 

          return view('Site.WishList',$returned_details,compact('products'));

   }

    public function list()
    { 

           $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;

          $lang = \App::getLocale();
          $Banner = PagesBanner::select("imageen as image","title_$lang as title","body_$lang as body")
                                    ->where('page','wishlist')->first();

          $AuthMember_id = $this->user;
          $ShoppingCart = FavouriteProducts::select('products.id as id','products.price_after as price',
                            "products.title_$lang as name"  ,'products.id as product_id',
                            "at_stock",'products.image as image',
                            \DB::raw("IF(length(details_$lang) > 160,CONCAT( LEFT(details_$lang , 160),'...'),details_$lang)  as description"),
                            \DB::raw("if( cart.product_id , 1,0 ) as in_cart"),
                            \DB::raw("true as is_fav") 
                      )

                      ->join('products','products.id','favourite_products.product_id')
                      ->leftJoin('cart',function($q)use($AuthMember_id){
                          $q->on('cart.product_id','products.id')->where('cart.user_id',$AuthMember_id);
                      })
                      ->groupBy('favourite_products.id')
                      ->where( 'favourite_products.user_id',$AuthMember_id)
                      ->paginate();
         return $ShoppingCart;
    }

    public function addOrRemove(Request $request )
    {

         $returned_details = $this->init();
             $lang = $this->lang;
             $AuthMember_id = $this->user;

      if($AuthMember_id==0){
          return response()->json([
                'status' => 'fail',
                'case' => false,
                'flash_message' => 'please login to continue'
              ]);
      }


      $product_id=$request->product_id;
          $WishList = FavouriteProducts::where( 'user_id',$AuthMember_id )->where('product_id',$product_id)->first();

          if($WishList)
          {
              $WishList->delete();
              return response()->json([
                'status' => 'success',
                'case' => false,
                'flash_message' => 'prouduct removed from Wish List'
              ]);
          }
          else
          {
              FavouriteProducts::create([
                'user_id' => $AuthMember_id,
                'product_id' => $product_id
              ]);
              return response()->json([
                'status' => 'success',
                'case' => true,
                'flash_message' => 'prouduct added to Wish List'
              ]);
          }
    }

}
