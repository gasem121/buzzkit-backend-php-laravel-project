<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\City;
use App\User;
use App\Customer;

use App\MemberAddress;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

class RegistrationController extends Controller
{
    public function create()
    {

        return view('Site.sign_up');
    }

     public function store(Request $request)
    {
    

 
      $validator = \Validator::make($request->all(),[
            'reg-name' => 'required',
            'reg-email' => 'required|email',
            'reg-password' => 'required',
            'reg-phone' => 'required'
        ]);
        
        
        
        $request['second_name'] = $request['reg-first-name'];
        $request['name'] = $request['reg-name'];
        $request['email'] = $request['reg-email'];
        $request['password'] = $request['reg-password'];
        $request['phone'] = $request['reg-phone'];
        
        
        if( strlen($request['phone']) > 18 || strlen($request['phone']) < 5 || !is_numeric($request['phone']) ){
            
               return  response()->json([
             'status' => 'faild',
             'flash_message' => "Sorry entered phone not correct"
           ]);
        }
    
    
       $user =  Customer::where('phone',$request['phone'])->first();
       
        if ($validator->fails()) { 
             return  response()->json([
             'status' => 'faild',
             'flash_message' => $validator->messages()->first()
           ]);
        }
        
       
       if($user){
            return  response()->json([
             'status' => 'faild',
             'flash_message' => 'Sorry this phone is used before'
           ]);
       }
       
       
        $user =  Customer::where('email',$request['email'])->first();
        
        if($user){
           return  response()->json([
             'status' => 'faild',
             'flash_message' => 'Sorry this email is used before'
           ]);
       }
    

        
        
        $request['password'] = md5($request['password']);

        $user = Customer::create(request(['name', 'email','phone', 'password','second_name']));


        Session::put('member_id', $user->id);

        return  response()->json([
             'status' => 'success',
             'flash_message' => 'Sorry this email is used before'
           ]);
    }
}
