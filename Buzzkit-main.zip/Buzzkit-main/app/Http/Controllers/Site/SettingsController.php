<?php

namespace App\Http\Controllers\Site;
 
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Setting;
use App\Suggestion;
use App\User;
use App\Customer;
use App\Order;
use App\Email;
use App\CategoryofProducts;
use App\BrandofProducts;
use App\UserAddress;
use App\Cart;
use Illuminate\Support\Facades\Session; 
use App\VendorsProductNotificationsFromAdmin;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class SettingsController extends BaseController
{
   
   
       public function test_email(Request $request){

    
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
 
 $mail = new PHPMailer();
 $mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'tls'; // secure transfer enabled REQUIRED for Gmail
$mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;       
$mail->Port = 587; // or 587
$mail->IsHTML(true);
$mail->Username = "atef7374@gmail.com";
$mail->Password = "tpta prdt kfla puub";
$mail->SetFrom("atef7374@gmail.com");
$mail->Subject = "Application for Programmer Registration";
$mail->Body = "Hello";
$mail->AddAddress("atef737475@gmail.com", "HR");
 


$headers = "From: Sender\n";
$headers .= 'Content-Type:text/calendar; Content-Disposition: inline; charset=utf-8;\r\n';
$headers .= "Content-Type: text/plain;charset=\"utf-8\"\r\n"; #EDIT: TYPO

if (!$mail->Send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
     die("eror");
} else {
    echo "Message has been sent";
     die("Sss");
}
 



 $mail = new PHPMailer();
    
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp-mail.outlook.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'hello@vonnn.com';                     //SMTP username
    $mail->Password   = 'Rfv/tgb/852';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('hello@vonnn.com', 'Mailer');
    $mail->addAddress('atef7374@gmail.com', 'Joe User');     //Add a recipient
 

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();

         return $this->apiResponse(200 ,'email is sent',null);
    }
    
    
    public function index()
    {

         $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;

       $user = $this->user;
        $lang = \App::getLocale();
          $settings = Setting::select("id",'title','value')->get();
        
          $setting =  array();

          foreach($settings as $item){

              if($lang=="ar"&&$item['title']=="about_title_ar"){
                $setting['about_title']=$item['value'];
              }
        
        if($lang=="ar"&&$item['title']=="about_details_ar"){
                $setting['about_details']=$item['value'];
              }



              if($lang=="en"&&$item['title']=="about_title_en"){
                $setting['about_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="about_details_en"){
                $setting['about_details']=$item['value'];
              }



          if($lang=="ar"&&$item['title']=="what_we_do_title_ar"){
                $setting['what_we_do_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="what_we_do_title_en"){
                $setting['what_we_do_title']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="what_we_do_details_ar"){
                $setting['what_we_do_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="what_we_do_details_en"){
                $setting['what_we_do_details']=$item['value'];
              }


          if($lang=="ar"&&$item['title']=="our_vision_details_ar"){
                $setting['our_vision_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_vision_details_en"){
                $setting['our_vision_details']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="our_vision_title_ar"){
                $setting['our_vision_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_vision_title_en"){
                $setting['our_vision_title']=$item['value'];
              }


          if($lang=="ar"&&$item['title']=="our_mission_details_ar"){
                $setting['our_mission_details']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_mission_details_en"){
                $setting['our_mission_details']=$item['value'];
              }


         if($lang=="ar"&&$item['title']=="our_mission_title_ar"){
                $setting['our_mission_title']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="our_mission_title_en"){
                $setting['our_mission_title']=$item['value'];
              }
              
              
               if($lang=="ar"&&$item['title']=="fotter_description_ar"){
                $setting['fotter_description']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="fotter_description_en"){
                $setting['fotter_description']=$item['value'];
              }


             if($item['title']=="logo"){
               
                  $setting['logo']=asset('public/images/Settings/'.$item['value']);
              }
              
              if($item['title']=="about_us_image"){
               
                  $setting['about_us_image']=asset('/images/Settings/'.$item['value']);
              }
              
              if($item['title']=="what_we_do_image"){
               
                  $setting['what_we_do_image']=asset('/images/Settings/'.$item['value']);
              }
              
              if($item['title']=="our_vision_image"){
               
                  $setting['our_vision_image']=asset('/images/Settings/'.$item['value']);
              }
              
              if($item['title']=="our_mission_image"){
               
                  $setting['our_mission_image']=asset('/images/Settings/'.$item['value']);
              }

              
          } 
          
          
              $returned_details['index']=3;
 

         return view('Site.about',$returned_details,compact('setting','user'));
    }


    public function contact()
    {
    

          $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;

             
          $settings = Setting::select("id",'title','value')->get();
        
          $setting =  array();

          foreach($settings as $item){

              if($lang=="ar"&&$item['title']=="contact_us_ar"){
                $setting['contact_us']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="contact_us_en"){
                $setting['contact_us']=$item['value'];
              } 




        if($item['title']=="email"){
                $setting['email']=$item['value'];
              }
             
        
               if($item['title']=="phone"){
                $setting['phone']=$item['value'];
              }


              if($lang=="ar"&&$item['title']=="address_ar"){
                $setting['address']=$item['value'];
              }
        
        if($lang=="en"&&$item['title']=="address_en"){
                $setting['address']=$item['value'];
              }


                if($item['title']=="map"){
                $setting['map']=$item['value'];
              }




              
          }
    
            $returned_details['index']=4;

         return view('Site.contact',$returned_details,compact('setting'));
    }
    
    
   


      public function account_details()
    { 


               $Date = now();
             $returned_details = $this->init();
             $lang = $this->lang;


          $user_id = $this->user;
          
          $user_details = Customer::where('id',$user_id)->first();
          $orders = Order::where('user_id',$user_id)->latest()->get();

          foreach ($orders as $order) {
             //$order['created_at'] = date("M d, Y", strtotime($order['created_at'])); 
             $order['quantity']=  Cart::where('order_id',$order->id)->count();
             
             $address = UserAddress::where('id',$order->location_id)->first();
             if($address){
                 $address = $address->address;
                 $order['address'] = $address;
             }else {
                   $order['address'] = '';
             }
            
             
        
          }
          
           
          
              $returned_details['index']=5;

         return view('Site.MyAccount',$returned_details,compact('user_details','orders'));
    }


    public function update_details(Request $request)
    {


              $returned_details = $this->init();
             $lang = $this->lang;
         
          $user_id = $this->user;
          $user = Customer::where('id',$user_id)->first();


          if($request->current_pwd&&$request->new_pwd&&$request->confirm_pwd){



              if(md5($request->current_pwd)!=$user['password']){
                  redirect()->back()->with('alert_error', "Sorry your current password not correct");  
              }


              if($request->new_pwd != $request->confirm_pwd){
                  redirect()->back()->with('alert_error', "Sorry passwords not matches");  
              }


          $user->password = md5($request->new_pwd);
          $user->save();

            }



          if($request->acc_name){
          $user->name = $request->acc_name;
          $user->save();
          }
       
     

         return  redirect()->back()->with('alert', 'Data has been updated successfully');
    }


   public function add_message(Request $request)
    {
           $this->validate(request(), [
            'user_name' => 'required',
            'subject' => 'required',
            'phone_email' => 'required',
            'message' => 'required'
        ]);
        

         Suggestion::create(request(['user_name', 'subject','phone_email', 'message']));
         return redirect()->back()->with('alert', 'Message Sent successfully and we will call you as fast as possible!');
      
    }
    
    
    public function add_email(Request $request)
    {       
        $email = Email::where('email',$request->email)->first();
        
            if(!$email){
            Email::create(request(['email']));
            }
            
           return response()->json([
                'status' => 'success',
                'flash_message' => 'E-mail signed up succssefully'
               ]);
      
    }
    

}
