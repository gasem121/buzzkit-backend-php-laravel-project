<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Str;
use App\PagesBanner;
use App\Category;
use App\Product;
use App\Customer;
use App\Ads;  
use App\BrandofProducts;
use App\ProductOffer;
use App\Variation;
use App\ProductAttribute;
use App\ProductImage;
use App\FavouriteProducts;
 use Illuminate\Support\Facades\Session;  

class ProductController  extends BaseController
{

   public function index()
      { 
          
     
            $id=5;
           $Date = now();

           $returned_details = $this->init();
           $lang = $this->lang;

          
          $all_categories = Category::select('id','name_'.$lang.' as title')->orderBy('position')->where('category_id',0)->where('status',1)->where('deleted_at',NULL)->get();
          
         
       for($i=0; $i<count($all_categories); $i++){
           
          $products_temp = array();

            if($i==0){
             $products = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('deleted_at',NULL)->where('status',1)->get();
            }else {
      
          $is_found = false;
          $all_products = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','product_categories','at_stock')->where('deleted_at',NULL)->where('status',1)->get();
          
          foreach($all_products as $single_product){
              
                  $product_categories =   explode("," , $single_product->product_categories);
                  
                  foreach($product_categories as $product_category){
                      
                      if($product_category == $all_categories[$i]->id){
                      
                          array_push($products_temp,$single_product);
                          
                          //dd($products);
                      }
                  }
            }
            
            
            $products = $products_temp;
            
            
        
            }
            
            //dd($this->user);
           for($j=0; $j<count($products); $j++){
               
            //   $products[$j]['at_stock'] = ProductAttribute::where('product_id',$products[$j]->id)->sum('store_quantity');
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
                
                                 $products[$j]['off'] = ( ($products[$j]['price_before']  - $products[$j]['price_after'])/ $products[$j]['price_before']) * 100;
            }

            $all_categories[$i]['products'] = $products;

          }


 
            $returned_details['index']=2;

          $ads_count=-1;

          return view('Site.Shop',$returned_details,compact('all_categories'));

       
      }


   public function search(Request $request)
      { 

 
            $id=5;
           $Date = now();
           
           $returned_details = $this->init();
           $lang = $this->lang;

          $products = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->where(function ($query) use ($request) {
              
            $query->orWhere(DB::raw('lower(`name_en`)'), 'like', '%' . strtolower($request->search_text) . '%')
            ->orWhere(DB::raw('lower(`name_ar`)'), 'like', '%' . strtolower($request->search_text) . '%')->
           orWhere(DB::raw('lower(`details_en`)'), 'like', '%' .strtolower($request->search_text) . '%')
           ->orWhere(DB::raw('lower(`details_ar`)'), 'like', '%' . strtolower($request->search_text) . '%');
          })
           ->where('deleted_at',NULL)->where('status',1)->get();
           for($j=0; $j<count($products); $j++){
               
            //   $products[$j]['at_stock'] = ProductAttribute::where('product_id',$products[$j]->id)->sum('store_quantity');
               
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
                
                                 $products[$j]['off'] = ( ($products[$j]['price_before']  - $products[$j]['price_after'])/ $products[$j]['price_before']) * 100;
                                 
                                 
            }

          $ads_count=-1;

          return view('Site.SearchProducts',$returned_details,compact('products'));

       
      }


 public function shop_by_sub_categry($id)
      { 
   
            //$id=5;
            
 
           $Date = now();

           $returned_details = $this->init();
           $lang = $this->lang;

          
         $all_categories = Category::select('id','name_'.$lang.' as title','category_id')->orderBy('position')->where('category_id',$id)->where('status',1)->orWhere('id',33)->where('deleted_at',NULL)->get();
         

            if($id==24){
            $returned_details['index']=8;
            }else if($id==25){
                         $all_categories = Category::select('id','name_'.$lang.' as title','category_id')->orderBy('position')->where('category_id',24)->where('status',1)->orWhere('id',33)->where('deleted_at',NULL)->get();

            $returned_details['index']=9; 
            }else if($id==27){
                
            $returned_details['index']=10; 
            }else if($id==26){
                
            $returned_details['index']=11; 
            }else if($id==28){
                
            $returned_details['index']=12; 
            }
            
            
            $merged_products = array();
        
            
       for($i=0; $i<count($all_categories); $i++){
           
           $products_temp = array();
           
           $is_found = false;
           
     
       
          $all_products = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','product_categories','at_stock')->where('category_id',$id)->where('deleted_at',NULL)->where('status',1)->get();
          
          foreach($all_products as $single_product){
              
                  $product_categories =   explode("," , $single_product->product_categories);
                  
                     // dd($product_categories);
                  
                  foreach($product_categories as $product_category){
                      
                      if($product_category == $all_categories[$i]->id){
                      
                          array_push($products_temp,$single_product);
                            array_push($merged_products,$single_product);
                          
                      }
                  
                     
                  }
                     
            }
            
            
            $products = $products_temp;


           for($j=0; $j<count($products); $j++){
               
            //   $products[$j]['at_stock'] = ProductAttribute::where('product_id',$products[$j]->id)->sum('store_quantity');
               
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
                
                                 $products[$j]['off'] = ( ($products[$j]['price_before']  - $products[$j]['price_after'])/ $products[$j]['price_before']) * 100;
                                 
                                 
            }

            $all_categories[$i]['products'] = $products;

          }
          
         $removed = array();
         
         for($i=0; $i<count($all_categories); $i++){
             
             if($all_categories[$i]->products==null||count($all_categories[$i]->products)<1){
                 array_push($removed,$all_categories[$i]->id);
             }
             
         }
         
 
         
         for($i=0; $i<count($removed); $i++){
             
             $id = 0;
            $temp_one = array();
            
              for($j=0; $j<count($all_categories); $j++){
                  if($removed[$i] == $all_categories[$j]->id){
                      $id = $all_categories[$j]->id;
                      break;
                  }
              }
              
               foreach($all_categories as $category){
                        if($category->id != $id){
                          array_push($temp_one,$category);
                        }
                    }
                      
           $all_categories = $temp_one;
             
         }
    
            
          $ads_count=-1;

          return view('Site.Shop',$returned_details,compact('all_categories','merged_products'));
       
      }


   public function shop_by_categories($id)
      { 
          
           $Date = now();
           
           $returned_details = $this->init();
           $lang = $this->lang;
           
           
          $products = Product::select('id','price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('status',1)->where('deleted_at',NULL)->where('category_id',$id)
           ->where('deleted_at',NULL)->get();
           for($j=0; $j<count($products); $j++){
               
            //   $products[$j]['at_stock'] = ProductAttribute::where('product_id',$products[$j]->id)->sum('store_quantity');
               
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
                
                
                                 $products[$j]['off'] = ( ($products[$j]['price_before']  - $products[$j]['price_after'])/ $products[$j]['price_before']) * 100;
                
                
                
            }

          $ads_count=-1;

          return view('Site.SearchProducts',$returned_details,compact('products'));
       
      }

       public function offers()
      {

       // \App::setlocale("ar");
           
           $Date = now();
           
           $returned_details = $this->init();
           $lang = $this->lang;
          $all_categories = array(); 

    $products = Product::where('status',1)->where('deleted_at',NULL)->select("id",'price_before','price_after','name_'.$lang.' as title','image')->where('is_offer','1')->where('status','1')->where('deleted_at',NULL)->get();

            for($j=0; $j<count($products); $j++){
                
                // $products[$j]['at_stock'] = ProductAttribute::where('product_id',$products[$j]->id)->sum('store_quantity');
                
                    $products[$j]['off']  = ( ( $products[$j]['price_before']-$products[$j]['price_after'])/$products[$j]['price_before']) * 100;
           
                
                $products[$j]['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$products[$j]->id)->first())?'https://drcodingsystem.com\kogear.shop\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
            }
                  
           array_push($all_categories,array('id'=>'1','products'=>$products));        
          
          return view('Site.Offer',$returned_details,compact('products','all_categories'));
      }
      

      public function list($Category_id)
      {
          $lang = \App::getLocale();
          $navstatus = 'Products';
          $Banner = PagesBanner::select("imageen as image","title_$lang as title","body_$lang as body")
                                ->where('page','Product')->first();
          $Categories = CategoryofProducts::select('id',"name_$lang as name",'image')
                                ->where('status',1)->find($Category_id);
          $SubCategories = SubCategoryofProducts::select('id',"name_$lang as name",'image',\DB::raw("false as is_selected"))
                               ->where('category_of_product_id',$Category_id)
                               ->where('status',1)->orderBy('position')->latest()
                               ->get();

          return view('Site.products.products_list',compact('navstatus','Banner','Categories','SubCategories')  );
      }

     

      //--Api----
      public function get_list(Request $request)
      {
          $lang = \App::getLocale();
          $category_id = $request->category_id; // category_of_product_id
          $sub_categories = $request->sub_categories; // sub_category_of_product_id -> array()
          $brand_id = $request->brand_id; // brand_of_product_id -> array()
          $search = $request->search; // brand_of_product_id -> array()
          $AuthMember_id = Session::get('member_id');

          return Product::select('products.id as id',"title_$lang as name" ,'image' ,'is_offer',
                  'at_stock' ,'price_before','price_after as price',
                  \DB::raw("IF(length(details_$lang) > 160,CONCAT( LEFT(details_$lang , 160),'...'),details_$lang)  as description"),
                  \DB::raw("if( favourite_products.product_id , 1,0 ) as is_fav"),
                  \DB::raw("if( cart.product_id , 1,0 ) as in_cart")
                               )
             ->where(function($q)use($category_id){
                if($category_id)
                    $q->where('category_of_product_id',$category_id);
             })
             ->where(function($q)use($sub_categories){
                if($sub_categories)
                    $q->whereIn('sub_category_of_product_id',$sub_categories);
             })
             ->where(function($q)use($brand_id){
                if($brand_id)
                    $q->whereIn('brand_of_product_id',$brand_id);
             })
             ->where(function($q)use($search){
                if($search)
                    $q->where('title_en','like','%'.$search.'%')->orWhere('title_ar','like','%'.$search.'%');
             })
             ->where('status',1)->where('accapted_from_admin',1)
             ->leftJoin('favourite_products',function($q)use($AuthMember_id){
                  $q->on('favourite_products.product_id','products.id')->where('favourite_products.user_id',$AuthMember_id);
              })
             ->leftJoin('cart',function($q)use($AuthMember_id){
                  $q->on('cart.product_id','products.id')->where('cart.user_id',$AuthMember_id);
              })->where('status',1)
             ->groupBy('products.id')->where('deleted_at',NULL)
             ->orderBy('products.position')
             ->latest('products.id')
             ->paginate();
      }

      public function show($id)
      { 
            
                      $Date = now();

           $returned_details = $this->init();
           $lang = $this->lang;
           
            
       

         $product_details = Product::select("id",'details_'.$lang.' as details','name_'.$lang.' as title','image' ,
                  'at_stock' ,'price_before','price_after','category_id')->where('deleted_at',NULL)->where('id',$id)->first();

 
          $product_details['category'] = Category::select('name_'.$lang.' as name')->where('id',$product_details->category_id)->first()->name;
          $product_details['saving'] = $product_details->price_before-$product_details->price_after;
          $product_details['images'] = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get();  


           $product_details['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product_details->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           
            
           
            
                 $product_details->variations = Variation::select('id','name_'.$lang.' as name')->orderBy('id', 'DESC')->get();

                $has_attributes=false;
                
               foreach($product_details->variations as $variation){
                   
                         $variation->attributes = ProductAttribute::select('attributes.id','attributes.name_'.$lang.' as name','product_attributes.price','product_attributes.store_quantity' )
                                ->leftJoin('attributes','attributes.id','product_attributes.attribute_id','attributes.value')
                                ->groupBy('product_attributes.id')
                                ->where('product_attributes.product_id',$product_details->id)
                                  ->where('attributes.variation_id',$variation->id)
                                ->get();
                                
                               if(count($variation->attributes)>0){
                                    $has_attributes=true;
                               } 

                      }
                      
 
           $random_products = Product::select("id",'price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('deleted_at',NULL)->where('status',1)->inRandomOrder()->limit(10)->get();


           foreach ($random_products as $product) {
               
            //   $product['at_stock'] = ProductAttribute::where('product_id',$product->id)->sum('store_quantity');
               
               $product['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           }
 
 
        
        $product_details->images = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get(); 
 
 
        foreach($product_details->images as $single_image){
             $single_image->type=0;
            if(Str::endsWith($single_image->image,'.mp4')){
                $single_image->type=1;
            }
            
        }

          $ads_count=-1;
          
          $product_details->off = ( ($product_details->price_before-$product_details->price_after)/$product_details->price_before) * 100;
          
          
       // dd($product_details->variations[0]);
          
         // dd($returned_details);

          return view('Site.product-single2',$returned_details,compact('product_details','random_products'));
      }
      
      public function show2($id)
      { 
            
                      $Date = now();

           $returned_details = $this->init();
           $lang = $this->lang;
           
            
           
        
       // dd("uploading new version");
 

         $product_details = Product::select("id",'details_'.$lang.' as details','name_'.$lang.' as title','image' ,
                  'at_stock' ,'price_before','price_after','category_id')->where('deleted_at',NULL)->where('id',$id)->first();

 
          $product_details['category'] = Category::select('name_'.$lang.' as name')->where('id',$product_details->category_id)->first()->name;
          $product_details['saving'] = $product_details->price_before-$product_details->price_after;
          $product_details['images'] = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get();  


           $product_details['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product_details->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           
            
           
            
                 $product_details->variations = Variation::select('id','name_'.$lang.' as name')->orderBy('id', 'DESC')->get();

                $has_attributes=false;
                
               foreach($product_details->variations as $variation){
                   
                         $variation->attributes = ProductAttribute::select('attributes.id','attributes.name_'.$lang.' as name','product_attributes.price','product_attributes.store_quantity' )
                                ->leftJoin('attributes','attributes.id','product_attributes.attribute_id','attributes.value')
                                ->groupBy('product_attributes.id')
                                ->where('product_attributes.product_id',$product_details->id)
                                  ->where('attributes.variation_id',$variation->id)
                                ->get();
                                
                               if(count($variation->attributes)>0){
                                    $has_attributes=true;
                               } 

                      }
                      
 
           $random_products = Product::select("id",'price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('deleted_at',NULL)->where('status',1)->inRandomOrder()->limit(10)->get();


           foreach ($random_products as $product) {
               
            //   $product['at_stock'] = ProductAttribute::where('product_id',$product->id)->sum('store_quantity');
               
               $product['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           }
 
 
        
        $product_details->images = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get(); 
 
 
        foreach($product_details->images as $single_image){
             $single_image->type=0;
            if(Str::endsWith($single_image->image,'.mp4')){
                $single_image->type=1;
            }
            
        }

          $ads_count=-1;
          
         // dd($returned_details);

          return view('Site.product-single2',$returned_details,compact('product_details','random_products'));
      }
      
      
       public function offer_details($id)
      { 
            
                      $Date = now();

           $returned_details = $this->init();
           $lang = $this->lang;
           
            
       

         $offer_details = Product::select("id",'details_'.$lang.' as details','name_'.$lang.' as title','image' ,
                  'at_stock' ,'price_before','price_after','category_id')->where('deleted_at',NULL)->where('id',$id)->first();
                  
                  $offer_products = ProductOffer::where('offer_id',$offer_details->id)->first();
                  
          
           if($offer_products){
               
               $all_product_details =   Product::select("id",'details_'.$lang.' as details','name_'.$lang.' as title','image' ,
                  'at_stock' ,'price_before','price_after','category_id')->where('deleted_at',NULL)->whereIn('id',explode(",", $offer_products->offer_items))->get();
                  
                foreach($all_product_details as $product_details){
           
           
                    
        //   $product_details['category'] = Category::select('name_'.$lang.' as name')->where('id',$product_details->category_id)->first()->name;
          
          
          
          $product_details['saving'] = $product_details->price_before-$product_details->price_after;
          $product_details['images'] = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get();  


           $product_details['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product_details->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           
                 $product_details->variations = Variation::select('id','name_'.$lang.' as name')->orderBy('id', 'DESC')->get();

                $has_attributes=false;
                
               foreach($product_details->variations as $variation){
                   
                         $variation->attributes = ProductAttribute::select('attributes.id','attributes.name_'.$lang.' as name','product_attributes.price','product_attributes.store_quantity' )
                                ->leftJoin('attributes','attributes.id','product_attributes.attribute_id','attributes.value')
                                ->groupBy('product_attributes.id')
                                ->where('product_attributes.product_id',$product_details->id)
                                  ->where('attributes.variation_id',$variation->id)
                                ->get();
                                
                               if(count($variation->attributes)>0){
                                    $has_attributes=true;
                               } 

                      }
        $product_details->images = ProductImage::select('image')->where('product_id',$product_details->id)->orderBy('position')->get(); 
 
 
        foreach($product_details->images as $single_image){
             $single_image->type=0;
            if(Str::endsWith($single_image->image,'.mp4')){
                $single_image->type=1;
            }
            
        }

          $ads_count=-1;
          
          $product_details->off = ( ($product_details->price_before-$product_details->price_after)/$product_details->price_before) * 100;
                    
                }  
                  
                  
                  
                  }
          
          
          
            $random_products = Product::select("id",'price_before','price_after','name_'.$lang.' as title','image','at_stock')->where('deleted_at',NULL)->where('status',1)->inRandomOrder()->limit(10)->get();


           foreach ($random_products as $product) {
               
            //   $product['at_stock'] = ProductAttribute::where('product_id',$product->id)->sum('store_quantity');
               
               $product['liked'] = empty(FavouriteProducts::select("id")->where('user_id',$this->user)->where('product_id',$product->id)->first())?'\ecommerce\public\images\ic_not_liked.png':'\ecommerce\public\images\ic_liked.png';
           }
 

          return view('Site.offer-single',$returned_details,compact('all_product_details','random_products','offer_details'));
      }
      




}
