<?php

namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Order;
use App\OrderProduct;

class HistoryController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth:Member');
    }

      public function index()
      {
          $lang = \App::getLocale();
          $AuthMember_id = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
           $history = Order::select('*' ,'type_product_delivery_status as delivery' )
                        ->where('user_id',$AuthMember_id)->orderBy('id','desc')
                        ->limit(25)->latest()->get();
          return view('Site.History.history_list',compact('history') );
      }


      public function show($id)
      {
         $lang = \App::getLocale();

         $order = Order::select('*', \DB::raw("DATE(created_at) as created_date") ,'type_product_delivery_status as delivery' )
                         ->where('user_id',auth('Member')->id() )->findOrFail($id);  //return $order;
         $orderProducts = OrderProduct::select('order_products.*',"products.title_$lang as product_name",'image' )
                                ->leftJoin('products','products.id','order_products.product_id')
                                ->groupBy('order_products.id')
                                ->where('order_products.order_id',$id)
                                ->limit(80)
                                ->get();
     

         return view('Site.History.history_details',compact('order','orderProducts') );
      }

      public function cancle_order($order_id)
      {
          $order = Order::where('user_id',auth('Member')->id())->findOrFail($order_id);
          if($order->type_product_delivery_status == 'processing' || $order->type_product_delivery_status == 'canceled')
          {
             $order->update(['type_product_delivery_status' => 'canceled' ]);
                return response()->json([
                 'status' => 'success',
                 'delivery' => $order->type_product_delivery_status,
                 'flash_message' => 'Order has cancled'
               ]);
          }
          else
          {
                return response()->json([
                 'status' => 'cant cancle',
                 'delivery' => $order->type_product_delivery_status,
                 'flash_message' => 'sorry cant cancle the order now'
               ]);
          }
      }


}
