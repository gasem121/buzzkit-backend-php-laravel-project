<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\SinglePageAdminController;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Event;
use App\BookedEvent;

class EventController extends Controller
{

     public function index()
    {
          
                 $lang = \App::getLocale();
          $events = Event::select("id",'title_'.$lang.' as title','details_'.$lang.' as description','image','created_at')->where('status','1')->get();
        $user = ( auth('Member')->check() )? auth('Member')->id() : 0 ;
         // dd($events[0]->image);
         return view('Site.blog',compact('events','user'));
    }


      public function show($id)
      {
          $lang = \App::getLocale();
          $navActive = 'New';
          $AuthMember_id = ( auth('Member')->check() )? auth('Member')->id() : 0 ;

          $Product = Event::select("id",'title_'.$lang.' as title','details_'.$lang.' as description','image','created_at') ->where('events.id',$id)
             ->first();

            // dd($Product);

            

          return view('Site.news-single',compact('navActive','Product','related_products') );
      }



}
