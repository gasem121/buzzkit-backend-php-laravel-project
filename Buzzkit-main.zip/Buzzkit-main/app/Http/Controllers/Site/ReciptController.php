<?php
namespace App\Http\Controllers\Site;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Product;
use App\ShoppingCart;
use App\Order;
use App\OrderProduct;

class ReciptController extends Controller
{
    public function __construct()
    {
       $this->middleware('auth:Member');
    }

    public function get_totalPrice($ShoppingCart)
    {
        $total_price = 0;
        foreach ($ShoppingCart as $key => $Cart)
        {
            $price = 0;

            $this_product = Product::find($Cart->product_id);

            if( $this_product ){
               $total_price += $this_product->price_after * $Cart->quantity;
            }
        }
        return $total_price;
    }

      // public function get_discount($member_id)
      // {
      //     $chekPromo = MemberPromo::where( 'member_id',$member_id )->where('is_used',0)->first();
      //     if($chekPromo)
      //     {
      //         $promo = PromoCodes::find($chekPromo->promo_id);
      //         $promo_discount_percentage = $promo->discount_percentage??0;
      //     }
      //     else {
      //         $promo_discount_percentage = 0;
      //     }
      //     return $promo_discount_percentage;
      // }


      public function checkout(Request $request)
      {


            // return $request->all()  ;
              $data = $request->validate([
                'address' => 'required',
              ]);

            $ShoppingCart = ShoppingCart::where( 'user_id',auth('Member')->id() )->get();

            $setting = [];
            $setting['shipping_price'] = 50 ;
            $setting['vat'] = 5 ;

            $subTotalPrice = 0;
            $is_subTotal_calcalated_wrong = true;

            $subTotalPrice = $this->get_totalPrice( $ShoppingCart );

            // $discount = $this->get_discount( auth('Member')->id() );
            //--promo code
            // $final_price = $subTotalPrice - ( ($subTotalPrice * $discount) / 100 );
            //--Shipping
            $final_price = $subTotalPrice + $setting['shipping_price'];
            //--tax
            $final_price = $final_price + ( ($final_price * $setting['vat']) / 100 );

            $Recipt = Order::create([
                'user_id' => auth('Member')->id(),
                'address' => $request->address,
                'final_price' => $final_price,
                'lab_id' => 1,
            ]);

            return $this->continue_checkout($Recipt,$ShoppingCart);
      }

      /*
      * cut ShoppingCart to ReciptProducts
      * insert discount
      */
      public function continue_checkout($Recipt,$ShoppingCart)
      {
            //--for create Recipt Products--
            foreach ($ShoppingCart as $key => $Cart)
            {
                 $this_product = Product::find($Cart->product_id);
                 OrderProduct::create([
                     'order_id' => $Recipt->id,
                     'quantity' => $Cart->quantity ,
                     'product_id' => $Cart->product_id ,
                     'price' => $this_product->price_after,
                 ]);
            }//End foreach
            ShoppingCart::where( 'user_id',$Recipt->user_id )->delete();

            //----- send Mail ------
            app('App\Http\Controllers\Api\EmailsController')->send_order_confiramtion_mail($Recipt->id);

            \Session::flash('flash_message', 'The order has been confirmed, Our representative will contact you soon for delivery');

            return redirect('/History');
      }

}
